import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ArtifactLibraryEditor = () => {
  const [step, setStep] = useState(1);
  const [mode, setMode] = useState('edit'); 
  const [tCodes, setTCodes] = useState([]);
  const [selectedTCode, setSelectedTCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState('');
  const [testData, setTestData] = useState([]);
  const [activePayloadTab, setActivePayloadTab] = useState('RAW'); 
  
  const [formData, setFormData] = useState({
    live_analysis: '',
    dead_disk_analysis: '',
    collection_strategy: '',
    custom_vql: '',
    surgical_yaml: ''
  });

  const API_BASE = 'https://10.11.110.60:8000/api/mitre';

  // Helper to get auth header
  const getAuthHeader = () => ({
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('orca_token')}`,
      'Content-Type': 'application/json'
    }
  });

  useEffect(() => {
    const fetchCodes = async () => {
      try {
        const res = await axios.get(`${API_BASE}/techniques`, getAuthHeader());
        const data = Array.isArray(res.data) ? res.data : (res.data.techniques || []);
        setTCodes(data);
      } catch (err) {
        console.error("TECH_FETCH_ERR:", err);
        setTCodes([]);
      }
    };
    fetchCodes();
  }, []);

  const handleNextToEdit = async () => {
    if (mode === 'edit' && selectedTCode) {
      setLoading(true);
      try {
        const res = await axios.get(`${API_BASE}/library/${selectedTCode}`, getAuthHeader());
        setFormData({
          live_analysis: res.data.live_analysis || '',
          dead_disk_analysis: res.data.dead_disk_analysis || '',
          collection_strategy: res.data.collection_strategy || '',
          custom_vql: res.data.custom_vql || '',
          surgical_yaml: res.data.surgical_yaml || ''
        });
        if (res.data.surgical_yaml) setActivePayloadTab('YAML');
        setStep(2);
      } catch (err) {
        alert("CRITICAL_ERR: TECHNIQUE_DATA_UNREACHABLE");
      } finally {
        setLoading(false);
      }
    } else {
      setStep(2);
    }
  };

  const handleSave = async () => {
    const submissionData = { ...formData };
    if (activePayloadTab === 'RAW') {
      submissionData.surgical_yaml = '';
    } else {
      submissionData.custom_vql = '';
    }

    try {
      await axios.post(`${API_BASE}/library/${selectedTCode}/update`, submissionData, getAuthHeader());
      alert("SUCCESS: GLOBAL_LIBRARY_SYNCHRONIZED");
      setStep(1);
    } catch (err) {
      alert("ERR: COMMIT_FAILED");
    }
  };

  const handleTestVQL = async () => {
    setTesting(true);
    setConsoleOutput("[*] INITIALIZING SANDBOX... EXECUTING VELOCIRAPTOR\n");
    setTestData([]);
    
    const payload = activePayloadTab === 'RAW' ? formData.custom_vql : formData.surgical_yaml;
    
    try {
      const res = await axios.post(`${API_BASE}/library/test`, { 
        vql: payload,
        is_yaml: activePayloadTab === 'YAML'
      }, getAuthHeader());
      
      if (res.data.success) {
        setConsoleOutput(prev => prev + `[+] SUCCESS: Query returned ${res.data.total_count} rows.\n`);
        setTestData(res.data.data);
      } else {
        setConsoleOutput(prev => prev + `[!] VR ERROR: ${res.data.error}`);
      }
    } catch (err) {
      setConsoleOutput(prev => prev + `[!] CONNECTION ERROR: ${err.message}`);
    } finally {
      setTesting(false);
    }
  };

  const TerminalInput = ({ label, value, onChange, isCode = false }) => (
    <div style={{ marginBottom: '30px' }}>
      <label style={{ display: 'block', fontSize: '10px', color: isCode ? '#00ff41' : '#444', marginBottom: '10px', letterSpacing: '2px', fontWeight: 'bold' }}>
        [ {label.toUpperCase()} ]
      </label>
      <textarea 
        style={{ 
          width: '100%', 
          height: isCode ? '300px' : '120px', 
          background: isCode ? '#020202' : '#050505', 
          border: `1px solid ${isCode ? '#003300' : '#111'}`, 
          color: isCode ? '#00ff41' : '#eee', 
          padding: '15px', 
          fontFamily: 'monospace', 
          fontSize: '13px', 
          outline: 'none',
          resize: 'vertical'
        }}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );

  if (step === 1) {
    return (
      <div style={{ animation: 'fadeIn 0.5s ease' }}>
        <h2 style={{ fontSize: '24px', fontWeight: '900', color: '#00ff41', marginBottom: '30px' }}>ARTIFACT_LIBRARY_EDITOR</h2>
        <div style={{ maxWidth: '600px', border: '1px solid #111', padding: '30px', background: '#080808' }}>
          <div style={{ marginBottom: '25px' }}>
            <label style={{ display: 'block', fontSize: '10px', color: '#444', marginBottom: '10px' }}>INTENT_MODE</label>
            <select 
              style={{ width: '100%', padding: '12px', background: '#000', border: '1px solid #222', color: '#eee', fontFamily: 'monospace' }}
              value={mode} 
              onChange={(e) => setMode(e.target.value)}
            >
              <option value="edit">UPDATE_EXISTING_MAPPING</option>
              <option value="add">INITIALIZE_NEW_MAPPING</option>
            </select>
          </div>
          <div style={{ marginBottom: '30px' }}>
            <label style={{ display: 'block', fontSize: '10px', color: '#444', marginBottom: '10px' }}>TECHNIQUE_SELECTION</label>
            <select 
              style={{ width: '100%', padding: '12px', background: '#000', border: '1px solid #222', color: '#eee', fontFamily: 'monospace' }}
              value={selectedTCode} 
              onChange={(e) => setSelectedTCode(e.target.value)}
            >
              <option value="">-- SELECT_T_CODE --</option>
              {tCodes.map(t => (
                <option key={t.t_code} value={t.t_code}>{t.t_code} | {t.name || t.technique_name}</option>
              ))}
            </select>
          </div>
          <button 
            onClick={handleNextToEdit} 
            disabled={!selectedTCode || loading}
            style={{ width: '100%', padding: '15px', background: 'transparent', border: '1px solid #00ff41', color: '#00ff41', cursor: 'pointer', fontFamily: 'monospace', fontWeight: 'bold' }}
          >
            {loading ? "FETCHING_DATA..." : "ACCESS_LOGIC_CORE"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ animation: 'fadeIn 0.5s ease', paddingBottom: '100px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px', borderBottom: '1px solid #111', paddingBottom: '20px' }}>
        <div>
          <h2 style={{ fontSize: '24px', fontWeight: '900', color: '#00ff41', margin: 0 }}>LOGIC_CONFIG: {selectedTCode}</h2>
          <div style={{ fontSize: '10px', color: '#444', marginTop: '5px' }}>GLOBAL_LIBRARY_UPLINK_ACTIVE</div>
        </div>
        <div style={{ display: 'flex', gap: '15px' }}>
          <button onClick={() => setStep(1)} style={{ background: 'none', border: '1px solid #222', color: '#555', padding: '8px 20px', cursor: 'pointer', fontFamily: 'monospace' }}>ABORT</button>
          <button onClick={handleSave} style={{ background: '#00ff41', border: 'none', color: '#000', padding: '8px 25px', cursor: 'pointer', fontFamily: 'monospace', fontWeight: 'bold' }}>COMMIT_CHANGES</button>
        </div>
      </div>

      <div style={{ maxWidth: '1000px' }}>
        <TerminalInput label="Live Analysis Logic" value={formData.live_analysis} onChange={(v) => setFormData({...formData, live_analysis: v})} />
        <TerminalInput label="Dead Disk Strategy" value={formData.dead_disk_analysis} onChange={(v) => setFormData({...formData, dead_disk_analysis: v})} />
        <TerminalInput label="Collection Parameters" value={formData.collection_strategy} onChange={(v) => setFormData({...formData, collection_strategy: v})} />
        
        <div style={{ display: 'flex', gap: '2px', marginBottom: '-1px' }}>
          <button 
            onClick={() => setActivePayloadTab('RAW')}
            style={{ 
              padding: '10px 20px', fontSize: '10px', fontFamily: 'monospace', cursor: 'pointer',
              background: activePayloadTab === 'RAW' ? '#020202' : '#000',
              color: activePayloadTab === 'RAW' ? '#00ff41' : '#444',
              border: `1px solid ${activePayloadTab === 'RAW' ? '#003300' : '#111'}`,
              borderBottom: activePayloadTab === 'RAW' ? '1px solid #020202' : '1px solid #111'
            }}
          >
            [SURGICAL_VQL_PAYLOAD_RAW]
          </button>
          <button 
            onClick={() => setActivePayloadTab('YAML')}
            style={{ 
              padding: '10px 20px', fontSize: '10px', fontFamily: 'monospace', cursor: 'pointer',
              background: activePayloadTab === 'YAML' ? '#020202' : '#000',
              color: activePayloadTab === 'YAML' ? '#00ff41' : '#444',
              border: `1px solid ${activePayloadTab === 'YAML' ? '#003300' : '#111'}`,
              borderBottom: activePayloadTab === 'YAML' ? '1px solid #020202' : '1px solid #111'
            }}
          >
            [SURGICAL_VQL_PAYLOAD_YAML]
          </button>
        </div>

        <div style={{ position: 'relative' }}>
          {activePayloadTab === 'RAW' ? (
            <TerminalInput label="VQL_RAW" value={formData.custom_vql} onChange={(v) => setFormData({...formData, custom_vql: v})} isCode={true} />
          ) : (
            <TerminalInput label="VQL_YAML_ARTIFACT" value={formData.surgical_yaml} onChange={(v) => setFormData({...formData, surgical_yaml: v})} isCode={true} />
          )}
          
          <button 
            onClick={handleTestVQL}
            disabled={testing}
            style={{ 
              position: 'absolute', top: '10px', right: '10px', 
              background: '#00ff41', color: '#000', border: 'none', 
              padding: '5px 15px', fontSize: '10px', fontFamily: 'monospace', 
              fontWeight: 'bold', cursor: 'pointer', zIndex: 10
            }}
          >
            {testing ? "RUNNING_SANDBOX..." : "TEST_VQL_PAYLOAD"}
          </button>
        </div>

        <div style={{ marginTop: '20px', background: '#050505', border: '1px solid #111', padding: '20px', fontFamily: 'monospace', fontSize: '12px' }}>
          <div style={{ color: '#555', marginBottom: '10px', fontSize: '10px' }}>DEBUG_CONSOLE_FEEDBACK</div>
          <pre style={{ color: '#00ff41', whiteSpace: 'pre-wrap', margin: 0 }}>{consoleOutput || "READY_FOR_VALIDATION..."}</pre>
          
          {testData.length > 0 && (
            <div style={{ marginTop: '20px', maxHeight: '400px', overflow: 'auto', borderTop: '1px solid #111', paddingTop: '10px' }}>
              <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse', fontSize: '11px', color: '#888' }}>
                <thead>
                  <tr style={{ color: '#eee' }}>
                    {Object.keys(testData[0]).map(key => <th key={key} style={{ padding: '5px', borderBottom: '1px solid #222' }}>{key}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {testData.map((row, i) => (
                    <tr key={i}>
                      {Object.values(row).map((val, j) => (
                        <td key={j} style={{ padding: '5px', borderBottom: '1px solid #111' }}>
                          {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ArtifactLibraryEditor;