import { useState, useEffect, useRef, useCallback } from "react";

// ─── constants ────────────────────────────────────────────────────────────────
const GREEN  = "#00ff41";
const AMBER  = "#ffaa00";
const RED    = "#ff4141";
const DIM    = "#444";
const DIM2   = "#666";
const BG     = "#000";
const PANEL  = "#0a0a0a";
const BORDER = "#1a1a1a";
const BORDER2= "#222";

const DEFAULT_SECTIONS = [
  { id: "summary",   label: "INVESTIGATION SUMMARY",  enabled: true,  detail: false },
  { id: "daily",     label: "DAILY UPDATE",            enabled: true,  detail: false },
  { id: "assets",    label: "ASSET BREAKDOWN",         enabled: true,  detail: false },
  { id: "network",   label: "NETWORK MAP",             enabled: true,  detail: false },
  { id: "bluf",      label: "BLUF NOTES",              enabled: true,  detail: false },
  { id: "timeline",  label: "ANALYST TIMELINE",        enabled: true,  detail: true  },
  { id: "verdicts",  label: "TECHNIQUE VERDICTS",      enabled: true,  detail: false },
];

const token = () => localStorage.getItem("orca_token");
const authHdr = () => ({ Authorization: `Bearer ${token()}` });

// ─── helpers ──────────────────────────────────────────────────────────────────
function fmt(n) { return (n ?? 0).toLocaleString(); }
function pct(a, b) { return b ? ((a / b) * 100).toFixed(1) + "%" : "0%"; }

function verdictColor(v) {
  if (!v) return DIM2;
  const u = v.toUpperCase();
  if (u === "MALICIOUS")     return RED;
  if (u === "NON_MALICIOUS") return GREEN;
  return DIM2;
}

function statusColor(s) {
  const u = (s || "").toUpperCase();
  if (u === "CLOSED")          return GREEN;
  if (u === "PENDING_REVIEW")  return AMBER;
  if (u === "IN_PROGRESS")     return "#4af";
  return DIM2;
}

// ─── sub-components ───────────────────────────────────────────────────────────

function MetricTile({ label, value, color }) {
  return (
    <div style={{
      background: PANEL, border: `1px solid ${BORDER2}`,
      padding: "14px 18px", minWidth: 110,
    }}>
      <div style={{ color: DIM2, fontFamily: "monospace", fontSize: 10, marginBottom: 6, letterSpacing: 2 }}>
        {label}
      </div>
      <div style={{ color: color || GREEN, fontFamily: "monospace", fontSize: 28, fontWeight: "bold" }}>
        {value}
      </div>
    </div>
  );
}

function SectionToggle({ section, onToggle, onToggleDetail, onDragStart, onDragOver, onDrop, isDragging }) {
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      style={{
        display: "flex", alignItems: "center", gap: 10,
        padding: "8px 10px",
        background: isDragging ? "#111" : "transparent",
        border: `1px solid ${isDragging ? GREEN : BORDER}`,
        cursor: "grab", marginBottom: 4,
        opacity: section.enabled ? 1 : 0.4,
        transition: "all 0.15s",
      }}
    >
      {/* drag handle */}
      <span style={{ color: DIM, fontSize: 12, userSelect: "none", cursor: "grab" }}>⠿</span>

      {/* enable toggle */}
      <div
        onClick={() => onToggle(section.id)}
        style={{
          width: 28, height: 14, background: section.enabled ? GREEN : "#1a1a1a",
          border: `1px solid ${section.enabled ? GREEN : DIM}`,
          cursor: "pointer", position: "relative", flexShrink: 0,
        }}
      >
        <div style={{
          position: "absolute", top: 2,
          left: section.enabled ? 14 : 2,
          width: 8, height: 8,
          background: section.enabled ? BG : DIM,
          transition: "left 0.15s",
        }} />
      </div>

      <span style={{ fontFamily: "monospace", fontSize: 11, color: section.enabled ? GREEN : DIM, flex: 1, letterSpacing: 1 }}>
        {section.label}
      </span>

      {/* detail toggle — only for sections that support it */}
      {["timeline", "verdicts", "daily"].includes(section.id) && section.enabled && (
        <div
          onClick={() => onToggleDetail(section.id)}
          style={{
            fontFamily: "monospace", fontSize: 9, padding: "2px 6px",
            border: `1px solid ${section.detail ? AMBER : DIM}`,
            color: section.detail ? AMBER : DIM, cursor: "pointer",
            letterSpacing: 1,
          }}
        >
          {section.detail ? "DETAIL ON" : "DETAIL OFF"}
        </div>
      )}
    </div>
  );
}

function SectionHeader({ label }) {
  return (
    <div style={{
      fontFamily: "monospace", fontSize: 11, color: GREEN,
      letterSpacing: 3, borderBottom: `1px solid ${GREEN}`,
      paddingBottom: 6, marginBottom: 16, marginTop: 28,
    }}>
      {label}
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────
export default function ReportsView() {
  const [cases, setCases]         = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);
  const [reportData, setReportData]     = useState(null);
  const [loading, setLoading]           = useState(false);
  const [exporting, setExporting]       = useState(null); // 'docx' | 'pdf'
  const [sections, setSections]         = useState(DEFAULT_SECTIONS);
  const [dragIdx, setDragIdx]           = useState(null);

  // daily update range
  const now = new Date();
  const yesterday = new Date(now - 86400000);
  const toLocal = (d) => d.toISOString().slice(0, 16);
  const [rangeFrom, setRangeFrom] = useState(toLocal(yesterday));
  const [rangeTo,   setRangeTo]   = useState(toLocal(now));

  // load case list
  useEffect(() => {
    fetch("https://10.11.110.60:8000/api/mitre/cases", { headers: authHdr() })
      .then(r => r.json())
      .then(d => setCases(Array.isArray(d) ? d : d.cases || []))
      .catch(() => {});
  }, []);

  // load report when case selected
  useEffect(() => {
    if (!selectedCase) return;
    setLoading(true);
    setReportData(null);
    fetch(`https://10.11.110.60:8000/api/reports/${encodeURIComponent(selectedCase)}`, { headers: authHdr() })
      .then(r => r.json())
      .then(d => { setReportData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [selectedCase]);

  // ── drag reorder ────────────────────────────────────────────
  const handleDragStart = (i) => setDragIdx(i);
  const handleDragOver  = (e) => e.preventDefault();
  const handleDrop      = (i) => {
    if (dragIdx === null || dragIdx === i) return;
    const next = [...sections];
    const [moved] = next.splice(dragIdx, 1);
    next.splice(i, 0, moved);
    setSections(next);
    setDragIdx(null);
  };

  const toggleSection = (id) =>
    setSections(s => s.map(x => x.id === id ? { ...x, enabled: !x.enabled } : x));
  const toggleDetail  = (id) =>
    setSections(s => s.map(x => x.id === id ? { ...x, detail: !x.detail } : x));

  // ── export ──────────────────────────────────────────────────
  const handleExport = async (format) => {
    if (!selectedCase || !reportData) return;
    setExporting(format);
    try {
      const body = { sections: sections.filter(s => s.enabled).map(s => ({ id: s.id, detail: s.detail })), range_from: rangeFrom, range_to: rangeTo };
      const res = await fetch(
        `https://10.11.110.60:8000/api/reports/${encodeURIComponent(selectedCase)}/export?format=${format}`,
        { method: "POST", headers: { ...authHdr(), "Content-Type": "application/json" }, body: JSON.stringify(body) }
      );
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url;
      a.download = `orca_report_${selectedCase.replace(/\s+/g, "_")}.${format === "docx" ? "docx" : "pdf"}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    } finally {
      setExporting(null);
    }
  };

  // ── daily delta from report data ────────────────────────────
  const getDailyData = useCallback(() => {
    if (!reportData) return null;
    const from = new Date(rangeFrom).getTime();
    const to   = new Date(rangeTo).getTime();

    const closedInRange = (reportData.techniques || []).filter(t => {
      if (!t.closed_at) return false;
      const ts = new Date(t.closed_at).getTime();
      return ts >= from && ts <= to;
    });

    const notesInRange = (reportData.timeline || []).filter(n => {
      const ts = new Date(n.created_at).getTime();
      return ts >= from && ts <= to;
    });

    // per-asset breakdown
    const byAsset = {};
    for (const t of closedInRange) {
      const aid = t.asset_id || "unknown";
      if (!byAsset[aid]) byAsset[aid] = { hostname: t.hostname || aid, closed: 0, malicious: 0, non_malicious: 0 };
      byAsset[aid].closed++;
      if ((t.verdict || "").toUpperCase() === "MALICIOUS")     byAsset[aid].malicious++;
      if ((t.verdict || "").toUpperCase() === "NON_MALICIOUS") byAsset[aid].non_malicious++;
    }

    return { closedInRange, notesInRange, byAsset: Object.values(byAsset) };
  }, [reportData, rangeFrom, rangeTo]);

  // ─────────────────────────────────────────────────────────────
  //  Render sections
  // ─────────────────────────────────────────────────────────────
  const renderSection = (sec) => {
    if (!reportData) return null;
    const s = reportData.summary || {};

    switch (sec.id) {

      case "summary":
        return (
          <div key="summary">
            <SectionHeader label="INVESTIGATION SUMMARY" />
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
              <MetricTile label="TOTAL TECHNIQUES" value={fmt(s.total_techniques)} />
              <MetricTile label="CLOSED"           value={fmt(s.closed)} />
              <MetricTile label="WITH EVIDENCE"    value={fmt(s.with_evidence)} />
              <MetricTile label="NO ARTIFACTS"     value={fmt(s.no_artifacts)} color={DIM2} />
              <MetricTile label="PENDING"          value={fmt(s.pending)}       color={AMBER} />
              <MetricTile label="COMPLETION"       value={pct(s.closed, s.total_techniques)} />
              <MetricTile label="MALICIOUS"        value={fmt(s.malicious)}     color={RED} />
              <MetricTile label="NON-MALICIOUS"    value={fmt(s.non_malicious)} color={GREEN} />
              <MetricTile label="UNDETERMINED"     value={fmt(s.undetermined)}  color={DIM2} />
            </div>
          </div>
        );

      case "daily": {
        const dd = getDailyData();
        return (
          <div key="daily">
            <SectionHeader label="DAILY UPDATE" />
            {/* range picker */}
            <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 16, flexWrap: "wrap" }}>
              <span style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>FROM</span>
              <input type="datetime-local" value={rangeFrom} onChange={e => setRangeFrom(e.target.value)}
                style={{ background: PANEL, border: `1px solid ${BORDER2}`, color: GREEN, fontFamily: "monospace", fontSize: 11, padding: "4px 8px" }} />
              <span style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>TO</span>
              <input type="datetime-local" value={rangeTo} onChange={e => setRangeTo(e.target.value)}
                style={{ background: PANEL, border: `1px solid ${BORDER2}`, color: GREEN, fontFamily: "monospace", fontSize: 11, padding: "4px 8px" }} />
            </div>
            {dd && (
              <>
                {/* headline numbers */}
                <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
                  <MetricTile label="TECHNIQUES CLOSED" value={fmt(dd.closedInRange.length)} />
                  <MetricTile label="ANALYST ENTRIES"   value={fmt(dd.notesInRange.length)} color={AMBER} />
                  <MetricTile label="MALICIOUS FINDS"   value={fmt(dd.closedInRange.filter(t => (t.verdict||'').toUpperCase()==='MALICIOUS').length)} color={RED} />
                </div>

                {/* per-asset progress */}
                {dd.byAsset.length > 0 && (
                  <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: 16 }}>
                    <thead>
                      <tr>
                        {["ASSET","CLOSED","MALICIOUS","NON-MALICIOUS"].map(h => (
                          <th key={h} style={{ fontFamily: "monospace", fontSize: 10, color: GREEN, textAlign: "left", padding: "6px 10px", borderBottom: `1px solid ${BORDER2}`, letterSpacing: 1 }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {dd.byAsset.map((a, i) => (
                        <tr key={i} style={{ background: i % 2 ? "#0d0d0d" : "transparent" }}>
                          <td style={{ fontFamily: "monospace", fontSize: 11, color: "#aaa", padding: "5px 10px" }}>{a.hostname}</td>
                          <td style={{ fontFamily: "monospace", fontSize: 11, color: GREEN,   padding: "5px 10px" }}>{a.closed}</td>
                          <td style={{ fontFamily: "monospace", fontSize: 11, color: RED,     padding: "5px 10px" }}>{a.malicious}</td>
                          <td style={{ fontFamily: "monospace", fontSize: 11, color: GREEN,   padding: "5px 10px" }}>{a.non_malicious}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {/* analyst notes in range — detail toggle */}
                {sec.detail && dd.notesInRange.length > 0 && (
                  <div style={{ borderLeft: `2px solid ${BORDER2}`, paddingLeft: 12 }}>
                    {dd.notesInRange.map((n, i) => (
                      <div key={i} style={{ marginBottom: 12 }}>
                        <div style={{ fontFamily: "monospace", fontSize: 10, color: AMBER, marginBottom: 4 }}>
                          [{(n.initials || n.author || "??").toUpperCase()}] [{n.t_code || "CASE"}]  {new Date(n.created_at).toLocaleString()}
                        </div>
                        <div style={{ fontFamily: "monospace", fontSize: 11, color: "#ccc" }}>{n.text}</div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        );
      }

      case "assets":
        return (
          <div key="assets">
            <SectionHeader label="ASSET BREAKDOWN" />
            {(reportData.assets || []).map((asset, i) => {
              const techsForAsset = (reportData.techniques || []).filter(t => t.asset_id === asset.id);
              const closed    = techsForAsset.filter(t => (t.technique_status||'').toUpperCase() === 'CLOSED').length;
              const malicious = techsForAsset.filter(t => (t.verdict||'').toUpperCase() === 'MALICIOUS').length;
              const total     = techsForAsset.length || s.total_techniques || 1;
              const pctDone   = ((closed / total) * 100).toFixed(0);

              return (
                <div key={asset.id} style={{ marginBottom: 16, padding: 14, background: PANEL, border: `1px solid ${BORDER2}` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                    <span style={{ fontFamily: "monospace", fontSize: 13, color: GREEN, fontWeight: "bold" }}>{asset.hostname}</span>
                    <span style={{ fontFamily: "monospace", fontSize: 10, color: DIM2 }}>{asset.os}  ·  {asset.asset_type}  ·  {asset.analysis_mode}</span>
                  </div>
                  {/* progress bar */}
                  <div style={{ height: 4, background: "#111", marginBottom: 10 }}>
                    <div style={{ height: 4, width: `${pctDone}%`, background: malicious > 0 ? RED : GREEN, transition: "width 0.3s" }} />
                  </div>
                  <div style={{ display: "flex", gap: 20 }}>
                    <span style={{ fontFamily: "monospace", fontSize: 11, color: "#aaa" }}>CLOSED <span style={{ color: GREEN }}>{closed}</span> / {total}</span>
                    <span style={{ fontFamily: "monospace", fontSize: 11, color: RED }}>{malicious} MALICIOUS</span>
                    <span style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>{pctDone}% COMPLETE</span>
                  </div>
                </div>
              );
            })}
          </div>
        );

      case "network":
        return (
          <div key="network">
            <SectionHeader label="NETWORK MAP" />
            <div style={{ background: PANEL, border: `1px solid ${BORDER2}`, padding: 20, textAlign: "center" }}>
              <div style={{ fontFamily: "monospace", fontSize: 11, color: DIM2, marginBottom: 12 }}>
                Network map snapshot — open the case to generate a live view for export.
              </div>
              <button
                onClick={() => window.open(`/investigation?print_map=true&case=${selectedCase}`, "_blank")}
                style={{ fontFamily: "monospace", fontSize: 11, background: "transparent", border: `1px solid ${GREEN}`, color: GREEN, padding: "6px 18px", cursor: "pointer" }}
              >
                OPEN PRINTABLE MAP ↗
              </button>
            </div>
          </div>
        );

      case "bluf":
        return (
          <div key="bluf">
            <SectionHeader label="BLUF NOTES" />
            {!(reportData.bluf_notes || []).length
              ? <div style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>No BLUF notes recorded.</div>
              : (reportData.bluf_notes || []).map((n, i) => (
                <div key={i} style={{ marginBottom: 14, borderLeft: `2px solid ${AMBER}`, paddingLeft: 12 }}>
                  <div style={{ fontFamily: "monospace", fontSize: 10, color: AMBER, marginBottom: 4 }}>
                    [{(n.author || "ANALYST").toUpperCase()}]  {new Date(n.created_at).toLocaleString()}
                  </div>
                  <div style={{ fontFamily: "monospace", fontSize: 12, color: "#ccc", lineHeight: 1.6 }}>{n.text}</div>
                </div>
              ))
            }
          </div>
        );

      case "timeline":
        return (
          <div key="timeline">
            <SectionHeader label="ANALYST TIMELINE" />
            {!(reportData.timeline || []).length
              ? <div style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>No timeline entries.</div>
              : (reportData.timeline || []).map((e, i) => (
                <div key={i} style={{ marginBottom: sec.detail ? 16 : 8, display: "flex", gap: 12, alignItems: sec.detail ? "flex-start" : "center" }}>
                  <span style={{ fontFamily: "monospace", fontSize: 10, color: DIM2, whiteSpace: "nowrap", minWidth: 130 }}>
                    {new Date(e.created_at).toLocaleString()}
                  </span>
                  <span style={{ fontFamily: "monospace", fontSize: 10, color: GREEN, minWidth: 80 }}>
                    [{(e.initials || "??").toUpperCase()}]
                  </span>
                  <span style={{ fontFamily: "monospace", fontSize: 10, color: AMBER, minWidth: 90 }}>
                    {e.t_code || "CASE"}
                  </span>
                  {sec.detail && (
                    <span style={{ fontFamily: "monospace", fontSize: 11, color: "#ccc" }}>{e.text}</span>
                  )}
                </div>
              ))
            }
          </div>
        );

      case "verdicts":
        return (
          <div key="verdicts">
            <SectionHeader label="TECHNIQUE VERDICTS" />
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {["T-CODE","TECHNIQUE","VERDICT","STATUS","EVIDENCE"].map(h => (
                    <th key={h} style={{ fontFamily: "monospace", fontSize: 10, color: GREEN, textAlign: "left", padding: "6px 10px", borderBottom: `1px solid ${BORDER2}`, letterSpacing: 1 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(reportData.techniques || []).map((t, i) => (
                  <tr key={i} style={{ background: i % 2 ? "#0d0d0d" : "transparent" }}>
                    <td style={{ fontFamily: "monospace", fontSize: 11, color: GREEN,    padding: "5px 10px", whiteSpace: "nowrap" }}>{t.t_code}</td>
                    <td style={{ fontFamily: "monospace", fontSize: 11, color: "#aaa",   padding: "5px 10px" }}>{t.technique_name}</td>
                    <td style={{ fontFamily: "monospace", fontSize: 11, color: verdictColor(t.verdict), padding: "5px 10px", fontWeight: "bold" }}>{t.verdict || "—"}</td>
                    <td style={{ fontFamily: "monospace", fontSize: 11, color: statusColor(t.technique_status), padding: "5px 10px" }}>{t.technique_status || "—"}</td>
                    <td style={{ fontFamily: "monospace", fontSize: 11, color: t.evidence_imported ? GREEN : DIM2, padding: "5px 10px", textAlign: "center" }}>
                      {t.evidence_imported ? "✓" : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      default:
        return null;
    }
  };

  // ─────────────────────────────────────────────────────────────
  //  Layout
  // ─────────────────────────────────────────────────────────────
  return (
    <div style={{ display: "flex", height: "100vh", background: BG, overflow: "hidden" }}>

      {/* ── LEFT: case list + builder ─────────────────────────── */}
      <div style={{
        width: 260, flexShrink: 0, borderRight: `1px solid ${BORDER}`,
        display: "flex", flexDirection: "column", overflow: "hidden",
      }}>

        {/* case selector */}
        <div style={{ padding: "16px 14px 12px", borderBottom: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: "monospace", fontSize: 10, color: DIM2, letterSpacing: 2, marginBottom: 8 }}>
            SELECT INVESTIGATION
          </div>
          <div style={{ maxHeight: 200, overflowY: "auto" }}>
            {cases.length === 0
              ? <div style={{ fontFamily: "monospace", fontSize: 11, color: DIM }}>No cases found.</div>
              : cases.map(c => {
                const name = typeof c === "string" ? c : c.case_name || c.name;
                return (
                  <div key={name}
                    onClick={() => setSelectedCase(name)}
                    style={{
                      fontFamily: "monospace", fontSize: 11, padding: "6px 8px",
                      cursor: "pointer", marginBottom: 2,
                      color: selectedCase === name ? BG : GREEN,
                      background: selectedCase === name ? GREEN : "transparent",
                      border: `1px solid ${selectedCase === name ? GREEN : BORDER}`,
                    }}
                  >
                    {name}
                  </div>
                );
              })
            }
          </div>
        </div>

        {/* report builder */}
        <div style={{ padding: "14px", borderBottom: `1px solid ${BORDER}`, flex: 1, overflowY: "auto" }}>
          <div style={{ fontFamily: "monospace", fontSize: 10, color: DIM2, letterSpacing: 2, marginBottom: 10 }}>
            REPORT BUILDER
          </div>
          <div style={{ fontFamily: "monospace", fontSize: 9, color: DIM, marginBottom: 10, lineHeight: 1.6 }}>
            DRAG TO REORDER · TOGGLE SECTIONS · DETAIL ADDS ANALYST NOTES
          </div>
          {sections.map((sec, i) => (
            <SectionToggle
              key={sec.id}
              section={sec}
              onToggle={toggleSection}
              onToggleDetail={toggleDetail}
              onDragStart={() => handleDragStart(i)}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(i)}
              isDragging={dragIdx === i}
            />
          ))}
        </div>

        {/* export buttons */}
        <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
          {[["docx", "EXPORT WORD (.docx)"], ["pdf", "EXPORT PDF (.pdf)"]].map(([fmt, label]) => (
            <button key={fmt} onClick={() => handleExport(fmt)}
              disabled={!selectedCase || !reportData || !!exporting}
              style={{
                fontFamily: "monospace", fontSize: 11, padding: "9px 0",
                background: "transparent",
                border: `1px solid ${!selectedCase || !reportData ? DIM : GREEN}`,
                color: !selectedCase || !reportData ? DIM : GREEN,
                cursor: !selectedCase || !reportData ? "not-allowed" : "pointer",
                letterSpacing: 1,
              }}
            >
              {exporting === fmt ? "GENERATING..." : label}
            </button>
          ))}
        </div>
      </div>

      {/* ── RIGHT: report preview ─────────────────────────────── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "24px 32px" }}>

        {!selectedCase && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: DIM, fontFamily: "monospace", fontSize: 12 }}>
            SELECT AN INVESTIGATION TO GENERATE REPORT
          </div>
        )}

        {selectedCase && loading && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: DIM2, fontFamily: "monospace", fontSize: 11 }}>
            LOADING...
          </div>
        )}

        {selectedCase && !loading && reportData && (
          <>
            {/* report header */}
            <div style={{ marginBottom: 24, borderBottom: `1px solid ${BORDER2}`, paddingBottom: 16 }}>
              <div style={{ fontFamily: "monospace", fontSize: 20, color: GREEN, fontWeight: "bold", marginBottom: 4 }}>
                {selectedCase.toUpperCase()}
              </div>
              <div style={{ fontFamily: "monospace", fontSize: 11, color: DIM2 }}>
                FOCUS: {(reportData.focus_country || "UNKNOWN").toUpperCase()}
                {"  ·  "}GENERATED: {new Date(reportData.generated_at || Date.now()).toLocaleString()}
              </div>
            </div>

            {/* render enabled sections in order */}
            {sections.filter(s => s.enabled).map(sec => renderSection(sec))}
          </>
        )}
      </div>
    </div>
  );
}
