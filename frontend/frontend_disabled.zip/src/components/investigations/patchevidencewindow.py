"""
patch_evidence_window.py — Patches EvidenceWindow.jsx with DETECTION_ANALYTICS card

Adds:
  1. analytics state + fetch alongside protocol fetch
  2. analyticsTab state for platform switching
  3. DETECTION_ANALYTICS card between DETECTION_STRATEGY_PROTOCOL and ANALYST_NOTES

Run from the ORCA frontend/src directory (same level as EvidenceWindow.jsx):
    python patch_evidence_window.py
"""

import shutil
from pathlib import Path

TARGET = Path("EvidenceWindow.jsx")

def patch(content, old, new, label):
    if old not in content:
        print(f"  [SKIP] {label} — pattern not found (may already be applied)")
        return content
    result = content.replace(old, new, 1)
    print(f"  [OK]   {label}")
    return result

def apply():
    if not TARGET.exists():
        print(f"ERROR: {TARGET} not found. Run from the directory containing EvidenceWindow.jsx")
        exit(1)

    content = TARGET.read_text(encoding="utf-8")
    shutil.copy(TARGET, TARGET.with_suffix(".jsx.bak"))
    print(f"Backup saved to {TARGET.with_suffix('.jsx.bak')}")

    # ── Patch 1: Add analytics + analyticsTab state after protocol state ──
    old_state = "  const [protocol, setProtocol]         = useState(null);"
    new_state = (
        "  const [protocol, setProtocol]         = useState(null);\n"
        "  const [analytics, setAnalytics]       = useState(null);\n"
        "  const [analyticsTab, setAnalyticsTab] = useState(null);"
    )
    content = patch(content, old_state, new_state, "analytics state added")

    # ── Patch 2: Fetch analytics alongside protocol fetch ─────────────────
    old_fetch = (
        "    fetch(`http://localhost:8000/api/mitre/library/${sel}`, { headers: getAuth() })\n"
        "      .then(r => r.json()).then(setProtocol).catch(() => setProtocol(null));\n"
        "    loadEvidence(sel);\n"
        "    loadNotes(sel);"
    )
    new_fetch = (
        "    fetch(`http://localhost:8000/api/mitre/library/${sel}`, { headers: getAuth() })\n"
        "      .then(r => r.json()).then(setProtocol).catch(() => setProtocol(null));\n"
        "    fetch(`http://localhost:8000/api/mitre/analytics/${sel}`, { headers: getAuth() })\n"
        "      .then(r => r.json()).then(data => {\n"
        "        setAnalytics(data?.analytics_by_platform && Object.keys(data.analytics_by_platform).length > 0 ? data : null);\n"
        "        setAnalyticsTab(data?.platforms?.[0] || null);\n"
        "      }).catch(() => setAnalytics(null));\n"
        "    loadEvidence(sel);\n"
        "    loadNotes(sel);"
    )
    content = patch(content, old_fetch, new_fetch, "analytics fetch added")

    # ── Patch 3: Insert DETECTION_ANALYTICS card after protocol card ──────
    old_card = (
        "          {protocol && (\n"
        "            <Card title=\"DETECTION_STRATEGY_PROTOCOL\">\n"
        "              <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>\n"
        "                {[['LIVE_ANALYSIS', protocol.live_analysis], ['DEAD_DISK_ANALYSIS', protocol.dead_disk_analysis],\n"
        "                  ['COLLECTION_STRATEGY', protocol.bluf_text || protocol.collection_strategy]].map(([l, txt]) => (\n"
        "                  <div key={l}>\n"
        "                    <div style={{ color: C.green, fontSize: 10, fontWeight: 'bold', marginBottom: 3 }}>&gt; {l}</div>\n"
        "                    <div style={{ color: C.grey, fontSize: 12, lineHeight: 1.5 }}>{txt || '---'}</div>\n"
        "                  </div>\n"
        "                ))}\n"
        "              </div>\n"
        "            </Card>\n"
        "          )}\n"
        "\n"
        "          {/* Notes — v2, author-aware, no BLUF input here (BLUF is case-level) */}"
    )

    new_card = (
        "          {protocol && (\n"
        "            <Card title=\"DETECTION_STRATEGY_PROTOCOL\">\n"
        "              <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>\n"
        "                {[['LIVE_ANALYSIS', protocol.live_analysis], ['DEAD_DISK_ANALYSIS', protocol.dead_disk_analysis],\n"
        "                  ['COLLECTION_STRATEGY', protocol.bluf_text || protocol.collection_strategy]].map(([l, txt]) => (\n"
        "                  <div key={l}>\n"
        "                    <div style={{ color: C.green, fontSize: 10, fontWeight: 'bold', marginBottom: 3 }}>&gt; {l}</div>\n"
        "                    <div style={{ color: C.grey, fontSize: 12, lineHeight: 1.5 }}>{txt || '---'}</div>\n"
        "                  </div>\n"
        "                ))}\n"
        "              </div>\n"
        "            </Card>\n"
        "          )}\n"
        "\n"
        "          {/* ── MITRE Detection Analytics ── */}\n"
        "          {analytics && (\n"
        "            <Card title={`MITRE_DETECTION_ANALYTICS — ${analytics.strategy_name || analytics.t_code}`}>\n"
        "              <div style={{ padding: '0 14px 14px' }}>\n"
        "\n"
        "                {/* Platform tabs */}\n"
        "                <div style={{ display: 'flex', gap: 4, marginBottom: 12, borderBottom: `1px solid ${C.border}`, paddingBottom: 8 }}>\n"
        "                  {analytics.platforms.map(plat => (\n"
        "                    <button key={plat} onClick={() => setAnalyticsTab(plat)}\n"
        "                      style={{\n"
        "                        background: analyticsTab === plat ? 'rgba(0,255,65,0.1)' : 'transparent',\n"
        "                        border: `1px solid ${analyticsTab === plat ? C.green : C.border}`,\n"
        "                        color: analyticsTab === plat ? C.green : C.greyDim,\n"
        "                        padding: '3px 10px', fontSize: 10, fontFamily: 'monospace',\n"
        "                        cursor: 'pointer', letterSpacing: 1,\n"
        "                      }}>\n"
        "                      {plat.toUpperCase()}\n"
        "                    </button>\n"
        "                  ))}\n"
        "                </div>\n"
        "\n"
        "                {/* Analytics for selected platform */}\n"
        "                {analyticsTab && (analytics.analytics_by_platform[analyticsTab] || []).map((a, idx) => (\n"
        "                  <div key={a.analytic_code} style={{\n"
        "                    borderLeft: `2px solid ${C.border}`, paddingLeft: 12, marginBottom: 16,\n"
        "                    paddingBottom: idx < analytics.analytics_by_platform[analyticsTab].length - 1 ? 16 : 0,\n"
        "                    borderBottom: idx < analytics.analytics_by_platform[analyticsTab].length - 1 ? `1px solid #0a0a0a` : 'none',\n"
        "                  }}>\n"
        "\n"
        "                    {/* Analytic code + narrative */}\n"
        "                    <div style={{ color: C.greyDim, fontSize: 9, marginBottom: 6, letterSpacing: 1 }}>\n"
        "                      {a.analytic_code}\n"
        "                    </div>\n"
        "                    <div style={{ color: C.grey, fontSize: 12, lineHeight: 1.6, marginBottom: 10 }}>\n"
        "                      {a.detection_narrative}\n"
        "                    </div>\n"
        "\n"
        "                    {/* Log sources */}\n"
        "                    {a.log_sources?.length > 0 && (\n"
        "                      <div style={{ marginBottom: 8 }}>\n"
        "                        <div style={{ color: C.green, fontSize: 9, fontWeight: 'bold', marginBottom: 4, letterSpacing: 1 }}>\n"
        "                          &gt; LOG_SOURCES\n"
        "                        </div>\n"
        "                        {a.log_sources.map((ls, i) => (\n"
        "                          <div key={i} style={{\n"
        "                            display: 'flex', gap: 8, fontSize: 11, fontFamily: 'monospace',\n"
        "                            padding: '3px 0', borderBottom: `1px solid #0a0a0a`,\n"
        "                          }}>\n"
        "                            <span style={{ color: C.green, minWidth: 180, flexShrink: 0 }}>{ls.name}</span>\n"
        "                            <span style={{ color: C.greyDim }}>{ls.channel}</span>\n"
        "                          </div>\n"
        "                        ))}\n"
        "                      </div>\n"
        "                    )}\n"
        "\n"
        "                    {/* Tuning parameters */}\n"
        "                    {a.tuning_parameters?.length > 0 && (\n"
        "                      <div>\n"
        "                        <div style={{ color: C.amber, fontSize: 9, fontWeight: 'bold', marginBottom: 4, letterSpacing: 1 }}>\n"
        "                          &gt; TUNING_PARAMETERS\n"
        "                        </div>\n"
        "                        {a.tuning_parameters.map((tp, i) => (\n"
        "                          <div key={i} style={{ marginBottom: 4, paddingLeft: 8 }}>\n"
        "                            <span style={{ color: C.amber, fontSize: 10, fontFamily: 'monospace' }}>\n"
        "                              {tp.field}\n"
        "                            </span>\n"
        "                            <span style={{ color: C.greyDim, fontSize: 11 }}> — {tp.description}</span>\n"
        "                          </div>\n"
        "                        ))}\n"
        "                      </div>\n"
        "                    )}\n"
        "                  </div>\n"
        "                ))}\n"
        "              </div>\n"
        "            </Card>\n"
        "          )}\n"
        "\n"
        "          {/* Notes — v2, author-aware, no BLUF input here (BLUF is case-level) */}"
    )

    content = patch(content, old_card, new_card, "DETECTION_ANALYTICS card inserted")

    TARGET.write_text(content, encoding="utf-8")
    print(f"\n{TARGET} written.")
    print("\nNext: rebuild frontend (npm run build or dev server hot-reload)")

if __name__ == "__main__":
    apply()