import React, { useState, useEffect, useMemo } from 'react';

export default function InvestigationGallery({ cases = [], onSelectCase, onAddCase, onDeleteCase, mitreData = [] }) {
  const [showModal, setShowModal] = useState(false);
  
  // --- FORM STATE ---
  const [caseName, setCaseName] = useState("");
  const [teamName, setTeamName] = useState("");
  const [missionLead, setMissionLead] = useState("");
  const [staffInput, setStaffInput] = useState(""); 
  const [personnelList, setPersonnelList] = useState([]); 
  const [focusCountry, setFocusCountry] = useState("");
  const [selectedGroups, setSelectedGroups] = useState([]);

  // --- DATA EXTRACTION ---
  const allGroups = useMemo(() => {
    if (Array.isArray(mitreData)) return mitreData;
    if (mitreData && mitreData.objects) return mitreData.objects;
    return [];
  }, [mitreData]);

  const attributedCountries = useMemo(() => {
    const countries = allGroups
      .map(g => g.country || g.x_mitre_origins || g.origin) 
      .filter(Boolean);
    return [...new Set(countries)].sort();
  }, [allGroups]);

  // --- AUTOMAGIC SELECTION LOGIC ---
  useEffect(() => {
    if (focusCountry) {
      const groupsInCountry = allGroups
        .filter(g => (g.country === focusCountry || g.x_mitre_origins === focusCountry || g.origin === focusCountry))
        .map(g => g.name || g.group_name);
      
      setSelectedGroups(groupsInCountry);
    } else {
      setSelectedGroups([]);
    }
  }, [focusCountry, allGroups]);

  const handleStaffCommit = (e) => {
    if (e.key === 'Enter' && staffInput.trim()) {
      e.preventDefault();
      if (!personnelList.includes(staffInput.trim())) {
        setPersonnelList([...personnelList, staffInput.trim()]);
      }
      setStaffInput("");
    }
  };

  const resetForm = () => {
    setCaseName(""); setTeamName(""); setMissionLead("");
    setPersonnelList([]); setFocusCountry(""); setSelectedGroups([]);
  };

  const handleCommitInvestigation = () => {
    if (!caseName.trim()) {
      alert("CRITICAL_ERROR: CASE_IDENTIFIER_REQUIRED");
      return;
    }
    
    // Mapping internal state to backend expectation (case_name)
    onAddCase({ 
      name: caseName, 
      case_name: caseName, 
      teamName, 
      missionLead, 
      personnel: personnelList, 
      country: focusCountry, 
      groups: selectedGroups 
    });
    
    setShowModal(false);
    resetForm();
  };

  return (
    <div style={{ padding: '40px', background: '#000', minHeight: '100vh', color: '#fff', fontFamily: 'monospace' }}>
      
      <div style={headerFlex}>
        <h2 style={titleGlow}>INVESTIGATION_ORCHESTRATOR</h2>
        <button onClick={() => setShowModal(true)} style={btnDeploy}>NEW_INVESTIGATION +</button>
      </div>

      {showModal && (
        <div style={modalOverlay}>
          <div style={modalContent}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
                <div style={modalHeader}>INIT_CASE_FILE</div>
                <div style={{color: '#222', fontSize: '10px'}}>ORCA_PROTOCOL_v4.2</div>
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: '40px' }}>
              
              <div>
                <label style={labelStyle}>CASE_IDENTIFIER</label>
                <input value={caseName} onChange={(e) => setCaseName(e.target.value)} style={inputStyle} placeholder="e.g. OPERATION_SILENT_WHALE" />
                
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
                  <div>
                    <label style={labelStyle}>TEAM_NAME</label>
                    <input value={teamName} onChange={(e) => setTeamName(e.target.value)} style={inputStyle} />
                  </div>
                  <div>
                    <label style={labelStyle}>MISSION_LEAD</label>
                    <input value={missionLead} onChange={(e) => setMissionLead(e.target.value)} style={inputStyle} />
                  </div>
                </div>

                <label style={labelStyle}>SUPPORT_PERSONNEL (PRESS_ENTER_TO_ADD)</label>
                <input value={staffInput} onChange={(e) => setStaffInput(e.target.value)} onKeyDown={handleStaffCommit} style={inputStyle} />
                
                <div style={staffStorageBox}>
                  {personnelList.length === 0 && <div style={{color: '#1a1a1a', fontSize: '10px'}}>NO_PERSONNEL_ASSIGNED</div>}
                  {personnelList.map(p => (
                    <div key={p} style={staffChip}>
                      {p} <span onClick={() => setPersonnelList(personnelList.filter(x => x !== p))} style={removeX}>×</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label style={labelStyle}>GEOPOLITICAL_FOCUS (POSTGRES_FILTER)</label>
                <select value={focusCountry} onChange={(e) => setFocusCountry(e.target.value)} style={inputStyle}>
                  <option value="">SELECT_COUNTRY_FROM_DB...</option>
                  {attributedCountries.map(c => <option key={c} value={c}>{c}</option>)}
                </select>

                <label style={labelStyle}>THREAT_GROUP_MATRIX (AUTO_SELECTED)</label>
                <div style={scrollBox}>
                  {allGroups.length > 0 ? allGroups.map(g => {
                    const isSelected = selectedGroups.includes(g.name || g.group_name);
                    return (
                      <div 
                        key={g.id || g.name} 
                        onClick={() => setSelectedGroups(prev => isSelected ? prev.filter(x => x !== (g.name || g.group_name)) : [...prev, (g.name || g.group_name)])}
                        style={{
                          ...itemStyle,
                          color: isSelected ? '#00ff41' : '#333',
                          borderColor: isSelected ? '#00ff41' : '#111',
                          background: isSelected ? 'rgba(0,255,65,0.02)' : 'transparent'
                        }}
                      >
                        <div style={{display: 'flex', justifyContent: 'space-between'}}>
                            <span>{g.name || g.group_name}</span>
                            {(g.country === focusCountry || g.origin === focusCountry) && <span style={{fontSize: '9px'}}>📍 ORIGIN_MATCH</span>}
                        </div>
                      </div>
                    );
                  }) : <div style={{color: '#ff4444', fontSize: '10px', padding: '20px', textAlign: 'center', border: '1px dashed #222'}}>CRITICAL: NO_DATA_STREAM_DETECTED</div>}
                </div>
              </div>
            </div>

            <div style={footerRow}>
              <button onClick={() => { setShowModal(false); resetForm(); }} style={btnAbort}>ABORT_SESSION</button>
              <button onClick={handleCommitInvestigation} style={btnDeploy}>COMMIT_INVESTIGATION</button>
            </div>
          </div>
        </div>
      )}

      {/* GALLERY VIEW */}
      <div style={gridStyle}>
        {cases.length === 0 && <div style={{color: '#111', gridColumn: '1/-1', textAlign: 'center', marginTop: '100px', fontSize: '20px', letterSpacing: '10px'}}>NO_ACTIVE_INVESTIGATIONS</div>}
        {cases.map((c, i) => (
          <div key={i} style={{ position: 'relative' }}>
            <button 
                onClick={(e) => { e.stopPropagation(); onDeleteCase(c.name || c.case_name); }}
                style={btnTerminate}
                title="TERMINATE_CASE"
            >
              ×
            </button>
            <div onClick={() => onSelectCase && onSelectCase(c)} style={caseCardStyle}>
                <div style={cardTop}>{(c.country || "GLOBAL").toUpperCase()} // {c.teamName || "UNASSIGNED"}</div>
                <div style={cardTitle}>{c.name || c.case_name || "UNTITLED_CASE"}</div>
                <div style={{marginTop: '20px', display: 'flex', gap: '5px', flexWrap: 'wrap'}}>
                    {c.groups?.slice(0, 3).map(g => <span key={g} style={{fontSize: '8px', color: '#444', border: '1px solid #111', padding: '2px 5px'}}>{g}</span>)}
                    {c.groups?.length > 3 && <span style={{fontSize: '8px', color: '#444'}}>+{c.groups.length - 3} MORE</span>}
                </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// STYLES
const modalOverlay = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.99)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 };
const modalContent = { background: '#000', border: '1px solid #111', padding: '60px', width: '1100px', maxHeight: '95vh', overflowY: 'auto' };
const inputStyle = { width: '100%', background: '#050505', border: '1px solid #1a1a1a', color: '#eee', padding: '15px', marginBottom: '25px', fontSize: '13px', outline: 'none' };
const staffStorageBox = { background: '#050505', border: '1px solid #111', minHeight: '140px', padding: '15px', display: 'flex', flexWrap: 'wrap', gap: '10px' };
const scrollBox = { height: '380px', overflowY: 'auto', background: '#050505', border: '1px solid #111', padding: '15px' };
const itemStyle = { padding: '12px', border: '1px solid #111', fontSize: '11px', cursor: 'pointer', marginBottom: '8px', transition: 'all 0.2s' };
const labelStyle = { color: '#222', fontSize: '10px', fontWeight: 'bold', display: 'block', marginBottom: '10px', letterSpacing: '1px' };
const headerFlex = { display: 'flex', justifyContent: 'space-between', marginBottom: '80px', alignItems: 'center' };
const titleGlow = { color: '#00ff41', letterSpacing: '8px', fontSize: '24px', margin: 0 };
const btnDeploy = { background: '#00ff41', color: '#000', border: 'none', padding: '18px 40px', fontWeight: 900, cursor: 'pointer', letterSpacing: '1px' };
const btnAbort = { background: 'none', color: '#333', border: '1px solid #222', padding: '18px 40px', cursor: 'pointer' };
const btnTerminate = { position: 'absolute', top: '20px', right: '20px', background: 'none', border: 'none', color: '#ff4444', fontSize: '24px', cursor: 'pointer', zIndex: 10, fontWeight: 'bold' };
const footerRow = { display: 'flex', gap: '20px', marginTop: '50px' };
const gridStyle = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '30px' };
const caseCardStyle = { background: '#050505', border: '1px solid #111', padding: '40px', cursor: 'pointer', transition: 'border 0.3s' };
const cardTop = { color: '#00ff41', fontSize: '10px', marginBottom: '15px', letterSpacing: '2px' };
const cardTitle = { color: '#fff', fontSize: '24px', fontWeight: 900 };
const staffChip = { background: '#0a0a0a', border: '1px solid #222', padding: '8px 15px', fontSize: '11px', color: '#eee' };
const removeX = { marginLeft: '12px', color: '#ff4444', cursor: 'pointer', fontWeight: 'bold' };
const modalHeader = { color: '#00ff41', marginBottom: '40px', fontSize: '18px', fontWeight: 900, letterSpacing: '2px' };