import React, { useState, useEffect, useRef } from 'react';

// ── Palette ────────────────────────────────────────────────────────────────
const C = {
  green:    '#00ff41', greenDim: '#00cc33',
  red:      '#ff4444', amber: '#ffaa00', purple: '#9b59ff',
  white:    '#f0f0f0', grey: '#aaaaaa', greyDim: '#777777',
  border:   '#2a2a2a', borderBright: '#3a3a3a',
  bg:       '#000000', bgCard: '#0d0d0d', bgHover: '#141414', bgHeader: '#111111',
};

const MITRE_NAMES = {
  "T1003":"OS Credential Dumping","T1003.001":"LSASS Memory","T1003.002":"SAM",
  "T1003.004":"LSA Secrets","T1003.005":"Cached Domain Credentials","T1005":"Data from Local System",
  "T1007":"System Service Discovery","T1012":"Query Registry","T1014":"Rootkit",
  "T1016":"System Network Configuration Discovery","T1021":"Remote Services",
  "T1027":"Obfuscated Files","T1027.007":"Dynamic API Resolution",
  "T1036":"Masquerading","T1036.005":"Match Legitimate Name or Location",
  "T1049":"System Network Connections Discovery","T1053.005":"Scheduled Task",
  "T1055":"Process Injection","T1055.001":"DLL Injection","T1055.002":"PE Injection",
  "T1055.003":"Thread Execution Hijacking","T1055.012":"Process Hollowing",
  "T1055.015":"Process Ghosting","T1056.001":"Keylogging","T1057":"Process Discovery",
  "T1059":"Command and Scripting Interpreter","T1059.001":"PowerShell",
  "T1059.003":"Windows Command Shell","T1059.004":"Unix Shell",
  "T1068":"Exploitation for Privilege Escalation","T1069":"Permission Groups Discovery",
  "T1070":"Indicator Removal","T1070.004":"File Deletion","T1071":"Application Layer Protocol",
  "T1078":"Valid Accounts","T1082":"System Information Discovery",
  "T1083":"File and Directory Discovery","T1105":"Ingress Tool Transfer",
  "T1106":"Native API","T1112":"Modify Registry","T1129":"Shared Modules",
  "T1134":"Access Token Manipulation","T1140":"Deobfuscate/Decode Files",
  "T1218":"System Binary Proxy Execution","T1486":"Data Encrypted for Impact",
  "T1518":"Software Discovery","T1542.003":"Pre-OS Boot: Bootkit",
  "T1543.003":"Windows Service","T1546.011":"Application Shimming",
  "T1547.001":"Registry Run Keys / Startup Folder","T1553":"Subvert Trust Controls",
  "T1553.004":"Install Root Certificate","T1556.001":"Modify Authentication Process",
  "T1562.001":"Disable or Modify Tools","T1562.006":"Indicator Blocking",
  "T1563":"Remote Service Session Hijacking","T1564.001":"Hidden Files and Directories",
  "T1564.004":"NTFS File Attributes","T1574":"Hijack Execution Flow",
  "T1574.001":"DLL Search Order Hijacking","T1574.006":"Dynamic Linker Hijacking",
  "T1620":"Reflective Code Loading","T1622":"Debugger Evasion",
};

const THREAT_ACTORS = [
  "APT1 (Comment Crew / Unit 61398)",
  "APT28 (Fancy Bear / Sofacy / Pawn Storm)",
  "APT29 (Cozy Bear / The Dukes)",
  "APT32 (OceanLotus / Cobalt Kitty)",
  "APT38 / Lazarus Group (Hidden Cobra)",
  "APT41 (Winnti / BARIUM / Double Dragon)",
  "BlackCat / ALPHV","Carbanak / FIN7 / Navigator Group",
  "Cl0p Ransomware","Conti Ransomware","DarkHotel (Tapaoux)",
  "Equation Group (NSA / GCHQ-linked)","Gamaredon (Primitive Bear)",
  "Hive Ransomware","Kimsuky (Thallium / Black Banshee)","LockBit Ransomware",
  "MuddyWater (Static Kitten)","NotPetya / Sandworm (GRU Unit 74455)",
  "REvil / Sodinokibi","Ryuk Ransomware","ShadowPad (APT41-linked)",
  "TA505 (Evil Corp-linked)","Turla (Venomous Bear / Waterbug)",
  "WannaCry (Lazarus Group)","Winnti Group (APT41 overlap)",
  "Wizard Spider (Ryuk / TrickBot)",
];

const VOL_PLUGINS = {
  windows: {
    "Process Analysis":  ["windows.pslist","windows.psscan","windows.pstree","windows.malware.psxview","windows.cmdline","windows.cmdscan","windows.consoles","windows.envars","windows.handles","windows.sessions","windows.getsids","windows.getservicesids","windows.privileges","windows.joblinks","windows.kpcrs"],
    "Code Injection":    ["windows.malware.malfind","windows.malware.hollowprocesses","windows.malware.processghosting","windows.vadinfo","windows.vadwalk","windows.vadyarascan","windows.vadregexscan","windows.dlllist","windows.malware.ldrmodules","windows.memmap","windows.pedump","windows.threads","windows.thrdscan","windows.suspended_threads","windows.malware.pebmasquerade","windows.malware.suspicious_threads","windows.orphan_kernel_threads","windows.pe_symbols","windows.virtmap"],
    "Credentials":       ["windows.registry.hashdump","windows.registry.cachedump","windows.registry.lsadump","windows.malware.skeleton_key_check","windows.truecrypt"],
    "Registry":          ["windows.registry.hivelist","windows.registry.hivescan","windows.registry.printkey","windows.registry.userassist","windows.registry.certificates","windows.registry.getcellroutine","windows.registry.amcache","windows.shimcachemem"],
    "Network":           ["windows.netscan","windows.netstat","windows.mutantscan"],
    "Rootkit/Evasion":   ["windows.ssdt","windows.callbacks","windows.modules","windows.modscan","windows.driverscan","windows.driverirp","windows.malware.drivermodule","windows.unloadedmodules","windows.etwpatch","windows.malware.unhooked_system_calls","windows.malware.direct_system_calls","windows.malware.indirect_system_calls","windows.mbrscan","windows.bigpools","windows.timers","windows.devicetree","windows.poolscanner"],
    "DLL/Module":        ["windows.dlllist","windows.malware.ldrmodules","windows.iat","windows.pe_symbols"],
    "Files/MFT":         ["windows.filescan","windows.mftscan","windows.dumpfiles","windows.symlinkscan","windows.strings","windows.verinfo"],
    "Persistence":       ["windows.svcscan","windows.malware.svcdiff","windows.registry.scheduled_tasks","windows.windows","windows.windowstations","windows.statistics"],
    "System Info":       ["windows.info","windows.psxview"],
  },
  linux: {
    "Process Analysis":  ["linux.pslist","linux.psscan","linux.pstree","linux.cmdline","linux.bash","linux.envars","linux.proc","linux.pidhashtable","linux.pscallstack"],
    "Code Injection":    ["linux.malfind","linux.proc_maps","linux.memmap","linux.vadinfo","linux.vmaregexscan","linux.vmayarascan","linux.ptrace","linux.suspicious_threads","linux.orphan_kernel_threads"],
    "Network":           ["linux.sockstat","linux.sockscan","linux.netfilter","linux.ifconfig","linux.ip","linux.lsof"],
    "Rootkit/Evasion":   ["linux.check_afinfo","linux.check_modules","linux.check_syscall","linux.check_sysctl","linux.ebpf","linux.ftrace","linux.hidden_modules","linux.lsmod","linux.kthreads","linux.tracepoints","linux.tty_check","linux.keyboard_notifiers"],
    "Files":             ["linux.filescan","linux.lsof","linux.symlinkscan","linux.mountinfo","linux.mount","linux.list_files","linux.pagecache","linux.regexscan"],
    "Credentials":       ["linux.tty_check","linux.keyboard_notifiers","linux.capabilities"],
    "System Info":       ["linux.dmesg","linux.vmcoreinfo","linux.kallsyms","linux.kmsg","linux.boottime","linux.iomem","linux.yarascan","linux.strings"],
  },
  mac: {
    "Process Analysis":  ["mac.pslist","mac.psscan","mac.pstree","mac.cmdline","mac.bash","mac.envars"],
    "Code Injection":    ["mac.malfind","mac.proc_maps","mac.memmap","mac.vadinfo"],
    "Network":           ["mac.sockstat","mac.sockscan","mac.lsof","mac.ifconfig","mac.ip"],
    "Rootkit/Evasion":   ["mac.check_syscall","mac.hidden_modules","mac.kauth_listeners","mac.kauth_scopes","mac.socket_filters","mac.trustedbsd"],
    "Files":             ["mac.filescan","mac.lsof","mac.symlinkscan","mac.mountinfo","mac.pagecache"],
    "System Info":       ["mac.dmesg","mac.yarascan","mac.strings"],
  },
};

const CONF_COLOR = { H: C.red, M: C.amber, L: C.green };
const getAuth = () => ({ 'Authorization': `Bearer ${localStorage.getItem('orca_token')}`, 'Content-Type': 'application/json' });
const ts = () => new Date().toLocaleTimeString([], { hour12: false });

// ── Shared micro-styles ────────────────────────────────────────────────────
const Inp = { background: C.bg, border: `1px solid ${C.border}`, color: C.white, padding: '5px 8px', fontSize: 11, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box' };
const Btn = { padding: '6px 14px', background: C.green, color: '#000', border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: 11, fontFamily: 'monospace', whiteSpace: 'nowrap', flexShrink: 0 };
const Lbl = { color: C.greyDim, fontSize: 10, minWidth: 115, flexShrink: 0, fontFamily: 'monospace', paddingTop: 3 };
const CtxItem = { padding: '8px 14px', fontSize: 11, color: C.green, cursor: 'pointer', borderBottom: `1px solid #1a1a1a`, fontFamily: 'monospace' };

// ── Reusable ───────────────────────────────────────────────────────────────
const Card = ({ title, children, style }) => (
  <div style={{ border: `1px solid ${C.border}`, background: C.bgCard, ...style }}>
    <div style={{ padding: '5px 12px', background: C.bgHeader, borderBottom: `1px solid ${C.border}`, fontSize: 9, color: C.greyDim, fontWeight: 'bold', letterSpacing: 1 }}>{title}</div>
    {children}
  </div>
);

const LogCol = ({ logs, width = 270 }) => (
  <div style={{ width, borderLeft: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0 }}>
    <div style={{ padding: '5px 10px', background: C.bgHeader, borderBottom: `1px solid ${C.border}`, fontSize: 9, color: C.greyDim, letterSpacing: 1 }}>EXECUTION_LOG</div>
    <div style={{ flex: 1, overflowY: 'auto', padding: 4 }}>
      {logs.map((l, i) => (
        <div key={i} style={{ padding: '2px 5px', fontSize: 10, fontFamily: 'monospace', borderBottom: `1px solid #080808`,
          color: l.type === 'error' ? C.red : l.type === 'success' ? C.green : C.greyDim }}>
          <span style={{ opacity: 0.5, marginRight: 5 }}>[{l.t}]</span>{l.m}
        </div>
      ))}
    </div>
  </div>
);

// ── Collection status bar (top of window) ─────────────────────────────────
const CollectionStatusBar = ({ tacticList }) => {
  if (!tacticList || tacticList.length === 0) return null;
  const total      = tacticList.length;
  const withEvidence = tacticList.filter(t => t.evidence_imported).length;
  const noArtifacts  = tacticList.filter(t => (t.verdict || '').toUpperCase() === 'NO_ARTIFACTS').length;
  const pending      = total - withEvidence - noArtifacts;
  const pct          = Math.round(((withEvidence + noArtifacts) / total) * 100);
  if (pending === 0) return null; // collection complete — hide bar
  return (
    <div style={{ background: '#050f05', borderBottom: `1px solid ${C.green}`, padding: '5px 20px', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 16 }}>
      <span style={{ color: C.green, fontSize: 10, fontFamily: 'monospace', whiteSpace: 'nowrap' }}>
        COLLECTING — {withEvidence + noArtifacts}/{total} COMPLETE
      </span>
      <div style={{ flex: 1, background: '#111', height: 4, overflow: 'hidden' }}>
        <div style={{ height: '100%', background: C.green, width: `${pct}%`, transition: 'width 0.8s ease' }} />
      </div>
      <span style={{ color: C.greyDim, fontSize: 10, whiteSpace: 'nowrap' }}>
        {withEvidence > 0 && <span style={{ color: C.green }}>{withEvidence} HIT </span>}
        {noArtifacts > 0 && <span style={{ color: C.greyDim }}>{noArtifacts} EMPTY </span>}
        <span style={{ color: '#ffaa00' }}>{pending} PENDING</span>
      </span>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// OVERVIEW TAB  — replace the entire OverviewTab component in EvidenceWindow.jsx
// Lines 139-259 in the original file
// ══════════════════════════════════════════════════════════════════════════════
const OverviewTab = ({ tacticList, memSummary, avSummary, vulnSummary }) => {
  const [techExpanded, setTechExpanded] = useState(false);

  const total        = tacticList?.length || 0;
  const withEvidence = tacticList?.filter(t => t.evidence_imported)?.length || 0;
  const noArtifacts  = tacticList?.filter(t => (t.verdict || '').toUpperCase() === 'NO_ARTIFACTS')?.length || 0;
  const pending      = total - withEvidence - noArtifacts;
  const pct          = total > 0 ? Math.round((withEvidence / total) * 100) : 0;

  // VERDICT COUNTS
  // UNDETERMINED = anything that is NOT explicitly MALICIOUS or NON-MALICIOUS
  // (covers null, undefined, 'UNDETERMINED', empty string, or any other value)
  const malicious    = (tacticList || []).filter(t => (t.verdict || '').toUpperCase() === 'MALICIOUS').length;
  const nonMalicious = (tacticList || []).filter(t => (t.verdict || '').toUpperCase() === 'NON-MALICIOUS').length;
  const undetermined = total - malicious - nonMalicious;

  const vCounts = [
    ['UNDETERMINED', undetermined, C.greyDim],
    ['MALICIOUS',    malicious,    C.red],
    ['NON-MALICIOUS',nonMalicious, C.green],
  ];

  const vCol = { MALICIOUS: C.red, 'NON-MALICIOUS': C.green, UNDETERMINED: C.greyDim };

  return (
    <div style={{ padding: 18, overflowY: 'auto', height: '100%', display: 'flex', flexDirection: 'column', gap: 14, boxSizing: 'border-box' }}>

      {/* Collection progress */}
      <Card title="ARTIFACT_COLLECTION_PROGRESS">
        <div style={{ padding: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ color: C.white, fontSize: 12 }}>
              <span style={{ color: C.green, fontWeight: 'bold' }}>{withEvidence}</span> hits &nbsp;·&nbsp;
              <span style={{ color: C.greyDim, fontWeight: 'bold' }}>{noArtifacts}</span> empty &nbsp;·&nbsp;
              <span style={{ color: '#ffaa00', fontWeight: 'bold' }}>{pending}</span> pending
              <span style={{ color: C.greyDim }}> / {total} total</span>
            </span>
            <span style={{ color: C.green, fontWeight: 'bold' }}>{pct}%</span>
          </div>
          <div style={{ background: '#1a1a1a', height: 7, display: 'flex' }}>
            <div style={{ background: C.green,   height: '100%', width: `${total > 0 ? (withEvidence  / total) * 100 : 0}%`, transition: 'width 0.5s ease' }} />
            <div style={{ background: C.greyDim, height: '100%', width: `${total > 0 ? (noArtifacts   / total) * 100 : 0}%`, transition: 'width 0.5s ease' }} />
            <div style={{ background: '#ffaa00', height: '100%', width: `${total > 0 ? (pending       / total) * 100 : 0}%`, transition: 'width 0.5s ease' }} />
          </div>
          <div style={{ display: 'flex', gap: 14, marginTop: 6 }}>
            {[['█ EVIDENCE', C.green], ['█ NO_ARTIFACTS', C.greyDim], ['█ PENDING', '#ffaa00']].map(([l, c]) => (
              <span key={l} style={{ color: c, fontSize: 9 }}>{l}</span>
            ))}
          </div>
        </div>
      </Card>

      {/* Verdict counters + collapsible technique table */}
      <Card title="VERDICT_ANALYSIS">
        {/* Verdict tiles */}
        <div style={{ padding: 14, display: 'flex', gap: 12, flexWrap: 'wrap', borderBottom: `1px solid ${C.border}` }}>
          {total === 0 ? (
            <span style={{ color: C.greyDim, fontSize: 11 }}>NO_VERDICTS_ASSIGNED</span>
          ) : (
            vCounts.map(([label, count, col]) => (
              <div key={label} style={{ border: `1px solid ${col}`, padding: '10px 18px', display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 88 }}>
                <span style={{ color: col, fontSize: 26, fontWeight: 'bold' }}>{count}</span>
                <span style={{ color: col, fontSize: 9, letterSpacing: 1, marginTop: 3 }}>{label}</span>
              </div>
            ))
          )}
        </div>

        {/* Collapsible technique table toggle */}
        <div
          onClick={() => setTechExpanded(p => !p)}
          style={{ padding: '7px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            cursor: 'pointer', userSelect: 'none',
            background: techExpanded ? 'rgba(0,255,65,0.03)' : 'transparent' }}
        >
          <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>
            TECHNIQUE_SUMMARY ({total})
          </span>
          <span style={{ color: C.greyDim, fontSize: 10 }}>{techExpanded ? '▲ COLLAPSE' : '▼ EXPAND'}</span>
        </div>

        {/* Technique table — only rendered when expanded */}
        {techExpanded && (
          <div style={{ maxHeight: 300, overflowY: 'auto', borderTop: `1px solid ${C.border}` }}>
            {total === 0 ? (
              <div style={{ color: C.greyDim, fontSize: 11, padding: 14 }}>NO_TECHNIQUES_LOADED</div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11, fontFamily: 'monospace' }}>
                <thead>
                  <tr style={{ background: C.bgHeader, position: 'sticky', top: 0 }}>
                    {['T_CODE', 'TECHNIQUE', 'EVIDENCE', 'VERDICT'].map(h => (
                      <th key={h} style={{ padding: '6px 10px', textAlign: 'left', color: C.greyDim,
                        borderBottom: `1px solid ${C.border}`, fontWeight: 'bold' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tacticList.map((t, i) => {
                    const v   = (t.verdict || 'UNDETERMINED').toUpperCase();
                    const col = vCol[v] || C.greyDim;
                    return (
                      <tr key={i} style={{ borderBottom: `1px solid #0a0a0a` }}>
                        <td style={{ padding: '5px 10px', color: C.green }}>{t.t_code}</td>
                        <td style={{ padding: '5px 10px', color: C.grey }}>{t.technique_name || t.name}</td>
                        <td style={{ padding: '5px 10px', color: t.evidence_imported ? C.purple : (t.verdict?.toUpperCase() === 'NO_ARTIFACTS' ? C.greyDim : '#ffaa00') }}>
                          {t.evidence_imported ? '✓' : t.verdict?.toUpperCase() === 'NO_ARTIFACTS' ? 'EMPTY' : 'PENDING'}
                        </td>
                        <td style={{ padding: '5px 10px', color: col }}>{v}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}
      </Card>

      {/* Memory summary */}
      <Card title="MEMORY_ANALYSIS_SUMMARY">
        {memSummary ? (
          <div style={{ padding: 14, display: 'flex', gap: 24, flexWrap: 'wrap' }}>
            {[['PLUGINS_RUN', memSummary.pluginsRun], ['TOTAL_ROWS', memSummary.totalRows], ['LAST_PLUGIN', memSummary.lastPlugin || '---']].map(([l, v]) => (
              <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{l}</span>
                <span style={{ color: C.white, fontSize: 15, fontWeight: 'bold', fontFamily: 'monospace' }}>{String(v)}</span>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ padding: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.greyDim, flexShrink: 0 }} />
            <span style={{ color: C.greyDim, fontSize: 11, fontFamily: 'monospace' }}>
              PENDING_ANALYSIS — No results available. Run a plugin in the MEMORY_ANALYSIS tab to populate this section.
            </span>
          </div>
        )}
      </Card>

      {/* AV summary */}
      <Card title="MALWARE_SCAN_SUMMARY">
        {avSummary ? (
          <div style={{ padding: 14, display: 'flex', gap: 0 }}>
            {[['SCANNED', avSummary.scanned, C.white], ['INFECTED', avSummary.infected, avSummary.infected > 0 ? C.red : C.green],
              ['STATUS', avSummary.infected > 0 ? '⚠ THREATS_DETECTED' : '✓ CLEAN', avSummary.infected > 0 ? C.red : C.green]
            ].map(([l, v, col]) => (
              <div key={l} style={{ padding: '8px 18px', borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', gap: 3 }}>
                <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{l}</span>
                <span style={{ color: col, fontSize: typeof v === 'number' ? 20 : 11, fontWeight: 'bold', fontFamily: 'monospace' }}>{String(v)}</span>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ padding: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.greyDim, flexShrink: 0 }} />
            <span style={{ color: C.greyDim, fontSize: 11, fontFamily: 'monospace' }}>
              PENDING_ANALYSIS — No results available. Run ClamAV in the KNOWN_MALWARE_SIGNATURES tab to populate this section.
            </span>
          </div>
        )}
      </Card>

      {/* Vuln summary */}
      <Card title="VULNERABILITY_SCAN_SUMMARY">
        {vulnSummary ? (
          <div style={{ padding: 14, display: 'flex', gap: 0 }}>
            {[
              ['TOTAL',    vulnSummary.total,    C.white],
              ['CRITICAL', vulnSummary.critical, vulnSummary.critical > 0 ? C.red     : C.greyDim],
              ['HIGH',     vulnSummary.high,     vulnSummary.high     > 0 ? '#ff8800' : C.greyDim],
              ['MEDIUM',   vulnSummary.medium,   vulnSummary.medium   > 0 ? C.amber   : C.greyDim],
              ['LOW',      vulnSummary.low,      C.green],
            ].map(([l, v, col]) => (
              <div key={l} style={{ padding: '8px 18px', borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', gap: 3 }}>
                <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{l}</span>
                <span style={{ color: col, fontSize: 20, fontWeight: 'bold', fontFamily: 'monospace' }}>{String(v)}</span>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ padding: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.greyDim, flexShrink: 0 }} />
            <span style={{ color: C.greyDim, fontSize: 11, fontFamily: 'monospace' }}>
              PENDING_ANALYSIS — No results available. Run a vuln scan in the VULN_SCAN tab to populate this section.
            </span>
          </div>
        )}
      </Card>

    </div>
  );
};


// ══════════════════════════════════════════════════════════════════════════════
// ARTIFACT ANALYSIS TAB
// ══════════════════════════════════════════════════════════════════════════════
const ArtifactAnalysisTab = ({ assetId, assetName, tacticList: initTactics, caseName, onCollectionStarted, collab, analysisMode = 'UNKNOWN', assetIp = '' }) => {
  const [tactics, setTactics]           = useState(initTactics || []);
  const [sel, setSel]                   = useState(null);
  const [protocol, setProtocol]         = useState(null);
  const [analytics, setAnalytics]       = useState(null);
  const [analyticsTab, setAnalyticsTab] = useState(null);
  const [guidanceTab, setGuidanceTab]   = useState('CURATED');
  const [guidanceOpen, setGuidanceOpen] = useState(false);
  const [evidenceRows, setEvidenceRows] = useState([]);
  const [activeSource, setActiveSource] = useState(null);
  const [loadingEv, setLoadingEv]       = useState(false);
  const [filter, setFilter]             = useState('');
  const [visibleCount, setVisibleCount] = useState(50);  // virtual scroll page size
  const [isCollecting, setIsCollecting] = useState(false);
  const [drive, setDrive]               = useState('C:');
  const [remapEnabled, setRemapEnabled] = useState(false);
  const [remapMounted, setRemapMounted] = useState('N');
  // Remote execution state
  const [transport, setTransport]       = useState('WINRM');
  const [remoteIp, setRemoteIp]         = useState(assetIp);
  const [remoteUser, setRemoteUser]     = useState('');
  const [remotePass, setRemotePass]     = useState('');
  const [remoteDomain, setRemoteDomain] = useState('');
  const [remoteCleanup, setRemoteCleanup] = useState(true);
  const [remoteRunning, setRemoteRunning] = useState(false);
  const [remoteLogs, setRemoteLogs]     = useState([]);
  const [techStatuses, setTechStatuses] = useState({}); // { [t_code]: { status, rows, fallback, message } }
  const remoteReaderRef                 = useRef(null);
  const [collectionExpanded, setCollectionExpanded] = useState(true);
  const [notes, setNotes]               = useState([]);
  const [noteIn, setNoteIn]             = useState('');
  const [ctxMenu, setCtxMenu]           = useState({ visible: false, x: 0, y: 0, text: '' });
  const [claiming, setClaiming]         = useState(false);
  const [submitting, setSubmitting]     = useState(false);
  const pollRef = useRef(null);

  useEffect(() => { setTactics(initTactics || []); }, [initTactics]);
  useEffect(() => { if (tactics.length > 0 && !sel) setSel(tactics[0].t_code); }, [tactics]);

  useEffect(() => {
    if (!sel) return;
    setProtocol(null);
    setAnalytics(null);
    setGuidanceOpen(false);
    fetch(`https://10.11.110.60:8000/api/mitre/library/${sel}`, { headers: getAuth() })
      .then(r => r.json()).then(setProtocol).catch(() => setProtocol(null));
    fetch(`https://10.11.110.60:8000/api/mitre/analytics/${sel}`, { headers: getAuth() })
      .then(r => r.json()).then(data => {
        setAnalytics(data?.analytics_by_platform && Object.keys(data.analytics_by_platform).length > 0 ? data : null);
        setAnalyticsTab(data?.platforms?.[0] || null);
      }).catch(() => setAnalytics(null));
    loadEvidence(sel);
    loadNotes(sel);
  }, [sel]);

  useEffect(() => {
    refreshTactics();
    return () => stopPoll();
  }, [assetId, caseName]);

  const startPoll = () => { if (pollRef.current) return; pollRef.current = setInterval(refreshTactics, 8000); };
  const stopPoll  = () => { clearInterval(pollRef.current); pollRef.current = null; };

  const refreshTactics = async () => {
    if (!caseName || !assetId) return;
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/mitre/threat-profile/${encodeURIComponent(caseName)}?asset_id=${assetId}`, { headers: getAuth() });
      if (r.status === 401) { stopPoll(); return; }
      const d = await r.json();
      if (Array.isArray(d)) setTactics(d);
    } catch {}
  };

  const loadEvidence = async (tCode) => {
    setLoadingEv(true); setEvidenceRows([]); setActiveSource(null); setVisibleCount(50);
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${tCode}`, { headers: getAuth() });
      const d = await r.json();
      const content = d.rows || d;
      if (Array.isArray(content) && content.length > 0 && content[0].VQLSource) {
        const grouped = content.reduce((acc, row) => {
          const src = (row.VQLSource || 'General').split('/').pop();
          if (!acc[src]) acc[src] = [];
          acc[src].push(row);
          return acc;
        }, {});
        setEvidenceRows(grouped);
        setActiveSource(Object.keys(grouped)[0]);
      } else {
        setEvidenceRows(Array.isArray(content) ? content : []);
      }
    } catch { setEvidenceRows([]); }
    finally { setLoadingEv(false); }
  };

  // v2 notes — author-aware
  const loadNotes = async (tCode) => {
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${tCode}/notes/v2`, { headers: getAuth() });
      if (r.ok) setNotes(await r.json());
    } catch { setNotes([]); }
  };

  const updateVerdict = async (verdict) => {
    if (!sel) return;
    await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${sel}/verdict`,
      { method: 'POST', headers: getAuth(), body: JSON.stringify({ verdict }) });
    refreshTactics();
  };

  // ── Technique claim ─────────────────────────────────────────────────────
  const handleSelectTechnique = async (tCode) => {
    setSel(tCode);
    if (!collab || !assetId) return;

    setClaiming(true);
    try {
      const result = await collab.claimTechnique(assetId, tCode);
      if (result.status === 'LOCKED') {
        // Someone else holds it — we can still view but can't edit
        // The SSE access_attempt notification is sent server-side to the lock holder
      }
    } finally {
      setClaiming(false);
    }
  };

  const handleSubmit = async () => {
    if (!sel || !collab) return;
    setSubmitting(true);
    try {
      await collab.submitTechnique(assetId, sel);
      refreshTactics();
    } catch {}
    finally { setSubmitting(false); }
  };

  const handleRelease = async () => {
    if (!sel || !collab) return;
    await collab.releaseTechnique(assetId, sel);
  };

  // Derive lock state for currently selected technique
  const lockKey     = `${assetId}:${sel}`;
  const lockInfo    = collab?.techniqueLocks?.get(lockKey);
  const statusInfo  = collab?.techniqueStatuses?.get(lockKey);
  const techStatus  = statusInfo?.technique_status || 'UNCLAIMED';

  // Decode current user initials from JWT to determine lock ownership
  const myInitials = (() => {
    try { return JSON.parse(atob(localStorage.getItem('orca_token').split('.')[1])).initials; } catch { return null; }
  })();
  const iAmLockHolder = lockInfo && lockInfo.locked_by_initials === myInitials;
  const isLockedByOther = lockInfo && !iAmLockHolder;

  const runCollection = async () => {
    setIsCollecting(true);
    if (onCollectionStarted) onCollectionStarted('COLLECTION_RUNNING — Velociraptor executing...');
    try {
      const r = await fetch('https://10.11.110.60:8000/api/assets/execute', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({ action: 'Surgical Collection', asset_id: assetId, tsource: drive }),
      });
      const d = await r.json();
      if (r.ok && d.status === 'initiated') {
        if (onCollectionStarted) onCollectionStarted(`COLLECTING — ${d.target_count || '?'} techniques queued`);
        refreshTactics();   // immediate refresh so OVERVIEW updates without waiting for first poll tick
        startPoll();
      } else {
        if (onCollectionStarted) onCollectionStarted(null);
        alert('EXECUTION_ERROR: ' + (d.detail || 'Failed to initiate.'));
      }
    } catch {
      if (onCollectionStarted) onCollectionStarted(null);
      alert('CRITICAL: Cannot reach backend.');
    } finally { setIsCollecting(false); }
  };

  const runRemoteCollection = async () => {
    if (!remoteUser || !remotePass) { setRemoteLogs([{ t: ts(), m: 'USERNAME and PASSWORD required', type: 'error' }]); return; }
    setRemoteRunning(true);
    setRemoteLogs([]);
    setTechStatuses({});
    if (onCollectionStarted) onCollectionStarted('REMOTE_COLLECTION_RUNNING...');
    const addLog = (m, type = 'info') => setRemoteLogs(p => [{ t: ts(), m, type }, ...p].slice(0, 200));
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/assets/remote-execute', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({
          asset_id: assetId, ip: remoteIp, transport,
          username: remoteUser, password: remotePass,
          domain: remoteDomain || null,
          tsource: drive, cleanup: remoteCleanup,
          remap_mounted: remapEnabled ? remapMounted : null,
          remap_original: remapEnabled ? 'C' : null,
        }),
      });
      if (!resp.ok) { const e = await resp.json(); addLog('BACKEND: ' + (e.detail || resp.statusText), 'error'); setRemoteRunning(false); return; }
      const reader = resp.body.getReader(); remoteReaderRef.current = reader;
      const dec = new TextDecoder(); let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) { setRemoteRunning(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(line => {
          if (!line.startsWith('data: ')) return;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'technique_status') {
              // Structured per-technique event — update status table
              const { t_code, status, rows, fallback, message } = evt.data;
              setTechStatuses(p => ({ ...p, [t_code]: { status, rows, fallback, message } }));
            } else if (evt.type === 'log') {
              addLog(evt.data);
            } else if (evt.type === 'error') {
              addLog(evt.data, 'error');
            } else if (evt.type === 'done') {
              addLog(evt.data, evt.data.includes('FAILED') ? 'error' : 'success');
              setRemoteRunning(false);
              if (onCollectionStarted) onCollectionStarted(null);
              if (!evt.data.includes('FAILED')) { startPoll(); setCollectionExpanded(false); }
            }
          } catch {}
        });
      }
    } catch (e) {
      addLog('STREAM_ERROR: ' + e.message, 'error');
      setRemoteRunning(false);
      if (onCollectionStarted) onCollectionStarted(null);
    }
  };

  const stopRemoteCollection = () => {
    try { remoteReaderRef.current?.cancel(); } catch {}
    remoteReaderRef.current = null;
    setRemoteRunning(false);
    if (onCollectionStarted) onCollectionStarted(null);
  };

  const commitNote = async () => {
    if (!noteIn.trim() || !sel) return;
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${sel}/notes/v2`,
        { method: 'POST', headers: getAuth(), body: JSON.stringify({ text: noteIn, note_type: 'NOTE' }) });
      if (r.ok) {
        const d = await r.json();
        setNotes(prev => [...prev, {
          id: d.id, text: noteIn, type: 'NOTE',
          time: d.time, author_initials: d.author_initials,
        }]);
        setNoteIn('');
      }
    } catch {}
  };

  const deleteNote = async (id) => {
    await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${sel}/notes/${id}`,
      { method: 'DELETE', headers: getAuth() });
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  useEffect(() => {
    const close = () => setCtxMenu(p => ({ ...p, visible: false }));
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, []);

  const handleCtx = (e) => {
    const selected = window.getSelection().toString().trim();
    if (!selected) return;
    e.preventDefault();
    setCtxMenu({ visible: true, x: e.pageX, y: e.pageY, text: selected });
  };

  const promoteIOC = async () => {
    await fetch('https://10.11.110.60:8000/api/ioc/add', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value: ctxMenu.text, ioc_type: 'Manual_Highlight', t_code: sel }),
    });
    setCtxMenu(p => ({ ...p, visible: false }));
  };

  const vtUrl  = v => /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(v) ? `https://www.virustotal.com/gui/ip-address/${v}` : `https://www.virustotal.com/gui/search/${v}`;
  const otxUrl = v => {
    if (/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(v)) return `https://otx.alienvault.com/indicator/ip/${v}`;
    if (/^[a-fA-F0-9]{32,64}$/.test(v)) return `https://otx.alienvault.com/indicator/file/${v}`;
    if (v.includes('.') && !v.startsWith('http')) return `https://otx.alienvault.com/indicator/domain/${v}`;
    return `https://otx.alienvault.com/browse/indicators?q=${v}`;
  };

  const isGrouped  = !Array.isArray(evidenceRows) && typeof evidenceRows === 'object';
  const baseRows   = isGrouped ? (evidenceRows[activeSource] || []) : evidenceRows;
  const filteredRows = baseRows.filter(r => Object.values(r).some(v => String(v ?? '').toLowerCase().includes(filter.toLowerCase())));
  const dispRows   = filteredRows.slice(0, visibleCount);
  const curTactic  = tactics.find(t => t.t_code === sel);
  const curVerdict = (curTactic?.verdict || 'UNDETERMINED').toUpperCase();
  const vrdCol     = curVerdict === 'MALICIOUS' ? C.red : curVerdict === 'NON-MALICIOUS' ? C.green : C.greyDim;

  // Status badge color
  const statusColor = {
    UNCLAIMED:      C.greyDim,
    IN_PROGRESS:    C.purple,
    PENDING_REVIEW: C.amber,
    CLOSED:         C.green,
  };

  const fmtVal = (key, val) => {
    if (!val) return '---';
    const nk = key.toUpperCase().replace(/\s/g, '');
    if (['DIRECTORIES', 'FILESLOADED'].includes(nk) && typeof val === 'string') {
      return (
        <div style={{ maxHeight: 150, overflowY: 'auto', background: C.bg, padding: 5, border: `1px solid ${C.border}` }}>
          {val.split(',').map((s, i) => <div key={i} style={{ borderBottom: `1px solid #0a0a0a`, color: C.grey, fontSize: 10, paddingBottom: 2 }}>{i + 1}. {s.trim()}</div>)}
        </div>
      );
    }
    return typeof val === 'object' ? JSON.stringify(val) : val.toString();
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', height: '100%', overflow: 'hidden' }}>

      {/* ── Sidebar ── */}
      <aside style={{ borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Collection controls */}
        <div style={{ borderBottom: `1px solid ${C.border}`, background: '#080808', flexShrink: 0 }}>
          {/* Collapsible header */}
          <div
            onClick={() => setCollectionExpanded(p => !p)}
            style={{ padding: '8px 12px', display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', cursor: 'pointer', userSelect: 'none' }}
          >
            <span style={{ color: C.green, fontSize: 9, letterSpacing: 1 }}>
              RUN COLLECTION — {(assetName || `ASSET_${assetId}`).toUpperCase()}
            </span>
            <span style={{ color: C.greyDim, fontSize: 10 }}>{collectionExpanded ? '▲' : '▼'}</span>
          </div>

          {collectionExpanded && (
            <div style={{ padding: '0 12px 10px' }}>
              {analysisMode === 'LIVE_REMOTE' ? (
                /* ── Remote collection panel ── */
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {/* Transport */}
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ ...Lbl, minWidth: 60 }}>TRANSPORT</span>
                    <select value={transport} onChange={e => setTransport(e.target.value)}
                      style={{ ...Inp, flex: 1 }}>
                      <option value="WINRM">WINRM</option>
                      <option value="SSH">SSH</option>
                      <option value="SMB_PSEXEC">SMB / PSEXEC</option>
                      <option value="SMB_TASK">SMB / SCHTASK</option>
                    </select>
                  </div>
                  {/* IP */}
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ ...Lbl, minWidth: 60 }}>TARGET_IP</span>
                    <input value={remoteIp} onChange={e => setRemoteIp(e.target.value)}
                      placeholder="192.168.1.x" style={{ ...Inp, flex: 1 }} />
                  </div>
                  {/* Username */}
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ ...Lbl, minWidth: 60 }}>USERNAME</span>
                    <input value={remoteUser} onChange={e => setRemoteUser(e.target.value)}
                      placeholder="administrator" style={{ ...Inp, flex: 1 }} />
                  </div>
                  {/* Password */}
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ ...Lbl, minWidth: 60 }}>PASSWORD</span>
                    <input type="password" value={remotePass} onChange={e => setRemotePass(e.target.value)}
                      placeholder="••••••••" style={{ ...Inp, flex: 1 }} />
                  </div>
                  {/* Domain — only for WINRM/SMB */}
                  {(transport === 'WINRM' || transport === 'SMB_PSEXEC' || transport === 'SMB_TASK') && (
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      <span style={{ ...Lbl, minWidth: 60 }}>DOMAIN</span>
                      <input value={remoteDomain} onChange={e => setRemoteDomain(e.target.value)}
                        placeholder="optional" style={{ ...Inp, flex: 1 }} />
                    </div>
                  )}
                  {/* Tsource */}
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <span style={{ ...Lbl, minWidth: 60 }}>TSOURCE</span>
                    <input value={drive} onChange={e => setDrive(e.target.value)}
                      placeholder="C:" style={{ ...Inp, width: 50 }} />
                  </div>
                  {/* Cleanup toggle */}
                  <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
                    color: remoteCleanup ? C.green : C.greyDim, fontSize: 10, fontFamily: 'monospace' }}>
                    <input type="checkbox" checked={remoteCleanup} onChange={e => setRemoteCleanup(e.target.checked)} />
                    CLEANUP_AFTER
                  </label>
                  {/* Execute / Stop */}
                  {remoteRunning
                    ? <button onClick={stopRemoteCollection} style={{ ...Btn, background: C.red, color: C.white }}>■ STOP</button>
                    : <button onClick={runRemoteCollection} style={{ ...Btn, width: '100%' }}>▶ REMOTE_EXECUTE</button>
                  }
                  {/* Per-technique collection status table */}
                  {Object.keys(techStatuses).length > 0 && (
                    <div style={{ marginTop: 6, border: `1px solid ${C.border}`, background: C.bg }}>
                      <div style={{ padding: '3px 8px', background: C.bgHeader, borderBottom: `1px solid ${C.border}`,
                        fontSize: 8, color: C.greyDim, letterSpacing: 1, display: 'flex', justifyContent: 'space-between' }}>
                        <span>COLLECTION_STATUS</span>
                        <span style={{ color: C.green }}>
                          {Object.values(techStatuses).filter(s => ['COMPLETE','FALLBACK_COMPLETE'].includes(s.status)).length}
                          /{Object.keys(techStatuses).length} HITS
                        </span>
                      </div>
                      <div style={{ maxHeight: 180, overflowY: 'auto' }}>
                        {Object.entries(techStatuses).map(([tCode, s]) => {
                          const STATUS_STYLE = {
                            QUEUED:            { color: C.greyDim,  label: '○ QUEUED'   },
                            RUNNING:           { color: C.amber,    label: '◌ RUNNING'  },
                            COMPLETE:          { color: C.green,    label: '● HIT'      },
                            ZERO:              { color: C.greyDim,  label: '○ ZERO'     },
                            FALLBACK_RUNNING:  { color: C.amber,    label: '◌ BROAD...' },
                            FALLBACK_COMPLETE: { color: C.purple,   label: '◉ BROAD'    },
                            ERROR:             { color: C.red,      label: '✕ ERROR'    },
                          };
                          const st = STATUS_STYLE[s.status] || { color: C.greyDim, label: s.status };
                          return (
                            <div key={tCode} style={{ display: 'flex', alignItems: 'center', gap: 6,
                              padding: '3px 8px', borderBottom: '1px solid #0a0a0a', fontSize: 9, fontFamily: 'monospace' }}>
                              <span style={{ color: C.green, minWidth: 72 }}>{tCode}</span>
                              <span style={{ color: st.color, minWidth: 72 }}>{st.label}</span>
                              {s.rows != null && s.rows >= 0 && (
                                <span style={{ color: s.rows > 0 ? st.color : C.greyDim }}>
                                  {s.rows} rows
                                </span>
                              )}
                              {s.status === 'FALLBACK_RUNNING' && (
                                <span style={{ color: C.amber, fontSize: 8, fontStyle: 'italic' }}>
                                  primary 0 hits — broad collection for context
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                      {/* Error/transport log — collapsed below status table */}
                      {remoteLogs.some(l => l.type === 'error') && (
                        <div style={{ borderTop: `1px solid ${C.border}`, maxHeight: 60, overflowY: 'auto', padding: '3px 6px' }}>
                          {remoteLogs.filter(l => l.type === 'error').map((l, i) => (
                            <div key={i} style={{ fontSize: 8, color: C.red, fontFamily: 'monospace', padding: '1px 0' }}>
                              {l.m}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  {/* Show plain log only when no structured status yet (connection phase) */}
                  {Object.keys(techStatuses).length === 0 && remoteLogs.length > 0 && (
                    <div style={{ maxHeight: 80, overflowY: 'auto', background: C.bg,
                      border: `1px solid ${C.border}`, padding: '4px 6px', marginTop: 4 }}>
                      {remoteLogs.map((l, i) => (
                        <div key={i} style={{ fontSize: 9, fontFamily: 'monospace',
                          color: l.type === 'error' ? C.red : l.type === 'success' ? C.green : C.greyDim,
                          borderBottom: '1px solid #0a0a0a', padding: '2px 0' }}>
                          <span style={{ color: '#333', marginRight: 6 }}>{l.t}</span>{l.m}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                /* ── Local collection panel ── */
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <input value={drive} onChange={e => setDrive(e.target.value)} placeholder="C:"
                      style={{ ...Inp, width: 50 }} title="--tsource drive letter" />
                    <button onClick={runCollection} disabled={isCollecting}
                      style={{ ...Btn, flex: 1, opacity: isCollecting ? 0.5 : 1 }}>
                      {isCollecting ? 'RUNNING...' : 'EXECUTE'}
                    </button>
                  </div>
                  {(analysisMode === 'DEAD_DISK_LOCAL' || analysisMode === 'DEAD_DISK_REMOTE') && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <label style={{ display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer',
                        color: remapEnabled ? C.green : C.greyDim, fontSize: 10, fontFamily: 'monospace' }}>
                        <input type="checkbox" checked={remapEnabled} onChange={e => setRemapEnabled(e.target.checked)} />
                        REMAP_C_AS
                      </label>
                      <select value={remapMounted} onChange={e => setRemapMounted(e.target.value)}
                        disabled={!remapEnabled}
                        style={{ ...Inp, width: 52, opacity: remapEnabled ? 1 : 0.35, padding: '3px 6px' }}>
                        {'ABDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(l => (
                          <option key={l} value={l}>{l}:</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        <div style={{ padding: '4px 12px', fontSize: 9, color: C.greyDim, borderBottom: `1px solid #0a0a0a`, letterSpacing: 1 }}>TECHNIQUE_INDEX</div>

        {/* Technique list */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {tactics.map(t => {
            const active    = sel === t.t_code;
            const tKey      = `${assetId}:${t.t_code}`;
            const tStatus   = collab?.techniqueStatuses?.get(tKey)?.technique_status || 'UNCLAIMED';
            const tLock     = collab?.techniqueLocks?.get(tKey);
            const lockedByOther = tLock && tLock.locked_by_initials !== myInitials;

            const mal  = t.verdict?.toUpperCase() === 'MALICIOUS';
            const nmk  = t.verdict?.toUpperCase() === 'NON-MALICIOUS';
            const ev   = t.evidence_imported;

            // Border color priority: verdict > status
            const borderCol = mal ? C.red : nmk ? C.green : statusColor[tStatus] || C.greyDim;

            return (
              <div key={t.t_code}
                onClick={() => handleSelectTechnique(t.t_code)}
                style={{
                  padding: '9px 12px',
                  borderLeft: `3px solid ${borderCol}`,
                  borderBottom: `1px solid #0a0a0a`,
                  cursor: 'pointer',
                  background: active ? 'rgba(0,255,65,0.05)' : 'transparent',
                  opacity: lockedByOther ? 0.6 : 1,
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 12, fontWeight: 'bold', color: borderCol }}>{t.t_code}</span>
                  <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                    {/* Status badge */}
                    {tStatus !== 'UNCLAIMED' && (
                      <span style={{
                        fontSize: 7, color: statusColor[tStatus] || C.greyDim,
                        border: `1px solid ${statusColor[tStatus] || C.greyDim}`,
                        padding: '1px 4px', letterSpacing: 0.5,
                      }}>
                        {tStatus === 'IN_PROGRESS' ? 'WIP' : tStatus === 'PENDING_REVIEW' ? 'REVIEW' : tStatus}
                      </span>
                    )}
                    {/* Lock owner badge */}
                    {tLock && (
                      <span style={{
                        fontSize: 7, background: lockedByOther ? C.amber : C.green,
                        color: '#000', padding: '1px 4px', fontWeight: 'bold',
                      }} title={`Locked by ${tLock.locked_by}`}>
                        {tLock.locked_by_initials}
                      </span>
                    )}
                  </div>
                </div>
                <div style={{ fontSize: 11, color: active ? C.grey : C.greyDim, marginTop: 1 }}>
                  {t.technique_name || t.name}
                </div>
                {ev && <div style={{ fontSize: 8, color: C.purple, marginTop: 2 }}>● EVIDENCE</div>}
                {lockedByOther && <div style={{ fontSize: 8, color: C.amber, marginTop: 2 }}>⚠ LOCKED — VIEW ONLY</div>}
              </div>
            );
          })}
          {tactics.length === 0 && <div style={{ color: C.greyDim, fontSize: 11, padding: 20, textAlign: 'center' }}>NO_TECHNIQUES</div>}
        </div>
      </aside>

      {/* ── Main ── */}
      <main style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#050505' }}>

        {/* Status bar */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '8px 15px', background: C.bg, borderBottom: `1px solid ${C.border}`, flexShrink: 0, gap: 10 }}>

          <div style={{ color: C.green, fontSize: 13, fontWeight: 'bold' }}>[ STATUS ]: {sel || 'IDLE'}</div>

          {/* Workflow action buttons */}
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            {/* Lock status indicator */}
            {sel && lockInfo && (
              <span style={{
                fontSize: 9, padding: '3px 8px', fontFamily: 'monospace',
                background: isLockedByOther ? 'rgba(255,170,0,0.1)' : 'rgba(0,255,65,0.1)',
                border: `1px solid ${isLockedByOther ? C.amber : C.green}`,
                color: isLockedByOther ? C.amber : C.green,
              }}>
                {isLockedByOther ? `⚠ LOCKED: ${lockInfo.locked_by_initials}` : '● YOUR_LOCK'}
              </span>
            )}

            {/* Submit for review — only if I hold the lock and status is IN_PROGRESS */}
            {sel && iAmLockHolder && techStatus === 'IN_PROGRESS' && (
              <button onClick={handleSubmit} disabled={submitting}
                style={{ ...Btn, background: C.amber, fontSize: 9, padding: '4px 10px', opacity: submitting ? 0.5 : 1 }}>
                {submitting ? 'SUBMITTING...' : '↑ SUBMIT_REVIEW'}
              </button>
            )}

            {/* Release lock */}
            {sel && iAmLockHolder && (
              <button onClick={handleRelease}
                style={{ ...Btn, background: 'transparent', border: `1px solid ${C.border}`, color: C.greyDim, fontSize: 9, padding: '4px 10px' }}>
                RELEASE_LOCK
              </button>
            )}

            {/* Verdict selector — read-only if locked by other */}
            <span style={{ color: C.grey, fontSize: 11 }}>VERDICT:</span>
            <select
              value={curVerdict}
              onChange={e => !isLockedByOther && updateVerdict(e.target.value)}
              disabled={isLockedByOther}
              style={{ background: C.bg, border: `1px solid ${vrdCol}`, color: vrdCol, padding: '4px 8px', fontSize: 11, fontFamily: 'monospace', outline: 'none', opacity: isLockedByOther ? 0.5 : 1 }}
            >
              <option value="UNDETERMINED">UNDETERMINED</option>
              <option value="MALICIOUS">MALICIOUS</option>
              <option value="NON-MALICIOUS">NON-MALICIOUS</option>
            </select>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12, padding: 14 }}>

          {/* ── Detection Guidance — collapsed by default ── */}
          {(protocol || analytics) && (
            <Card title="DETECTION_GUIDANCE">
              {/* Collapse toggle */}
              <div
                onClick={() => setGuidanceOpen(p => !p)}
                style={{ padding: '7px 14px', display: 'flex', justifyContent: 'space-between',
                  alignItems: 'center', cursor: 'pointer', userSelect: 'none',
                  background: guidanceOpen ? 'rgba(0,255,65,0.03)' : 'transparent' }}
              >
                {/* Inner tab pills — visible even when collapsed so analyst knows what's inside */}
                <div style={{ display: 'flex', gap: 6 }}>
                  {['CURATED', 'MITRE'].map(tab => {
                    const hasData = tab === 'CURATED' ? !!protocol : !!analytics;
                    if (!hasData) return null;
                    return (
                      <span key={tab} onClick={e => { e.stopPropagation(); setGuidanceTab(tab); if (!guidanceOpen) setGuidanceOpen(true); }}
                        style={{
                          fontSize: 9, padding: '2px 8px', letterSpacing: 1, cursor: 'pointer',
                          border: `1px solid ${guidanceTab === tab && guidanceOpen ? C.green : C.border}`,
                          color: guidanceTab === tab && guidanceOpen ? C.green : C.greyDim,
                          background: guidanceTab === tab && guidanceOpen ? 'rgba(0,255,65,0.08)' : 'transparent',
                        }}>
                        {tab}
                      </span>
                    );
                  })}
                </div>
                <span style={{ color: C.greyDim, fontSize: 10 }}>{guidanceOpen ? '▲ COLLAPSE' : '▼ EXPAND'}</span>
              </div>

              {guidanceOpen && (
                <div style={{ borderTop: `1px solid ${C.border}`, padding: 14 }}>

                  {/* CURATED tab */}
                  {guidanceTab === 'CURATED' && protocol && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                      {[['LIVE_ANALYSIS', protocol.live_analysis],
                        ['DEAD_DISK_ANALYSIS', protocol.dead_disk_analysis],
                        ['COLLECTION_STRATEGY', protocol.bluf_text || protocol.collection_strategy]
                      ].map(([l, txt]) => (
                        <div key={l}>
                          <div style={{ color: C.green, fontSize: 10, fontWeight: 'bold', marginBottom: 3 }}>&gt; {l}</div>
                          <div style={{ color: C.grey, fontSize: 12, lineHeight: 1.5 }}>{txt || '---'}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* MITRE tab */}
                  {guidanceTab === 'MITRE' && analytics && (
                    <div>
                      <div style={{ fontSize: 9, color: C.greyDim, letterSpacing: 1, marginBottom: 10 }}>
                        {analytics.strategy_name || analytics.t_code}
                      </div>
                      {/* Platform tabs */}
                      <div style={{ display: 'flex', gap: 4, marginBottom: 12, borderBottom: `1px solid ${C.border}`, paddingBottom: 8 }}>
                        {analytics.platforms.map(plat => (
                          <button key={plat} onClick={() => setAnalyticsTab(plat)}
                            style={{
                              background: analyticsTab === plat ? 'rgba(0,255,65,0.1)' : 'transparent',
                              border: `1px solid ${analyticsTab === plat ? C.green : C.border}`,
                              color: analyticsTab === plat ? C.green : C.greyDim,
                              padding: '3px 10px', fontSize: 10, fontFamily: 'monospace',
                              cursor: 'pointer', letterSpacing: 1,
                            }}>
                            {plat.toUpperCase()}
                          </button>
                        ))}
                      </div>
                      {/* Analytics for selected platform */}
                      {analyticsTab && (analytics.analytics_by_platform[analyticsTab] || []).map((a, idx) => {
                        const list = analytics.analytics_by_platform[analyticsTab];
                        return (
                          <div key={a.analytic_code} style={{
                            borderLeft: `2px solid ${C.border}`, paddingLeft: 12, marginBottom: 16,
                            paddingBottom: idx < list.length - 1 ? 16 : 0,
                            borderBottom: idx < list.length - 1 ? `1px solid #0a0a0a` : 'none',
                          }}>
                            <div style={{ color: C.greyDim, fontSize: 9, marginBottom: 6, letterSpacing: 1 }}>{a.analytic_code}</div>
                            <div style={{ color: C.grey, fontSize: 12, lineHeight: 1.6, marginBottom: 10 }}>{a.detection_narrative}</div>
                            {a.log_sources?.length > 0 && (
                              <div style={{ marginBottom: 8 }}>
                                <div style={{ color: C.green, fontSize: 9, fontWeight: 'bold', marginBottom: 4, letterSpacing: 1 }}>&gt; LOG_SOURCES</div>
                                {a.log_sources.map((ls, i) => (
                                  <div key={i} style={{ display: 'flex', gap: 8, fontSize: 11, fontFamily: 'monospace', padding: '3px 0', borderBottom: `1px solid #0a0a0a` }}>
                                    <span style={{ color: C.green, minWidth: 180, flexShrink: 0 }}>{ls.name}</span>
                                    <span style={{ color: C.greyDim }}>{ls.channel}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                            {a.tuning_parameters?.length > 0 && (
                              <div>
                                <div style={{ color: C.amber, fontSize: 9, fontWeight: 'bold', marginBottom: 4, letterSpacing: 1 }}>&gt; TUNING_PARAMETERS</div>
                                {a.tuning_parameters.map((tp, i) => (
                                  <div key={i} style={{ marginBottom: 4, paddingLeft: 8 }}>
                                    <span style={{ color: C.amber, fontSize: 10, fontFamily: 'monospace' }}>{tp.field}</span>
                                    <span style={{ color: C.greyDim, fontSize: 11 }}> — {tp.description}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Fallback: selected tab has no data */}
                  {guidanceTab === 'CURATED' && !protocol && (
                    <div style={{ color: C.greyDim, fontSize: 11 }}>NO_CURATED_DATA_FOR_THIS_TECHNIQUE</div>
                  )}
                  {guidanceTab === 'MITRE' && !analytics && (
                    <div style={{ color: C.greyDim, fontSize: 11 }}>NO_MITRE_ANALYTICS_FOR_THIS_TECHNIQUE</div>
                  )}

                </div>
              )}
            </Card>
          )}

          {/* Notes — v2, author-aware, no BLUF input here (BLUF is case-level) */}
          <Card title="ANALYST_NOTES">
            <div style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <input
                  value={noteIn}
                  onChange={e => setNoteIn(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && commitNote()}
                  placeholder={isLockedByOther ? 'READ_ONLY — technique locked by another analyst' : 'ANALYST_OBSERVATION...'}
                  disabled={isLockedByOther}
                  style={{ ...Inp, flex: 1, opacity: isLockedByOther ? 0.5 : 1 }}
                />
                <button onClick={commitNote} disabled={isLockedByOther}
                  style={{ ...Btn, opacity: isLockedByOther ? 0.5 : 1 }}>
                  COMMIT
                </button>
              </div>
              {notes.length > 0 && (
                <div style={{ maxHeight: 160, overflowY: 'auto', marginTop: 3, display: 'flex', flexDirection: 'column', gap: 3 }}>
                  {notes.map((n, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 8px',
                      borderLeft: `2px solid ${C.border}`, fontSize: 11, background: '#020202' }}>
                      <span>
                        <span style={{ opacity: 0.4, marginRight: 6, color: C.greyDim }}>[{n.time}]</span>
                        {n.author_initials && (
                          <span style={{ background: '#1a1a1a', color: C.greyDim, fontSize: 9, padding: '1px 4px', marginRight: 6 }}>
                            {n.author_initials}
                          </span>
                        )}
                        <span style={{ color: C.white }}>{n.text}</span>
                      </span>
                      {/* Only allow delete if not locked by other */}
                      {!isLockedByOther && (
                        <span onClick={() => deleteNote(n.id)} style={{ color: C.red, cursor: 'pointer', marginLeft: 8 }}>×</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* Evidence records — unchanged from original */}
          {sel && (
            <Card title="EVIDENCE_RECORDS" style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 12px', borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
                <span style={{ color: C.greyDim, fontSize: 10 }}>{dispRows.length}/{filteredRows.length} RECORDS</span>
                <input placeholder="FILTER..." value={filter} onChange={e => { setFilter(e.target.value); setVisibleCount(50); }}
                  style={{ ...Inp, width: 180 }} />
              </div>
              {isGrouped && (
                <div style={{ display: 'flex', gap: 4, padding: '6px 12px', borderBottom: `1px solid #0a0a0a`, overflowX: 'auto', flexShrink: 0 }}>
                  {Object.keys(evidenceRows).map(src => (
                    <button key={src} onClick={() => setActiveSource(src)}
                      style={{ background: C.bg, border: `1px solid ${activeSource === src ? C.green : C.border}`,
                        color: activeSource === src ? C.green : C.greyDim, padding: '3px 10px', fontSize: 10, fontFamily: 'monospace', cursor: 'pointer' }}>
                      {src.replace(/_/g, ' ').toUpperCase()}
                    </button>
                  ))}
                </div>
              )}
              {ctxMenu.visible && (
                <div style={{ position: 'fixed', zIndex: 9000, background: '#050505', border: `1px solid ${C.green}`, minWidth: 200,
                  top: ctxMenu.y, left: ctxMenu.x, boxShadow: `0 0 15px rgba(0,255,65,0.2)` }}>
                  <div style={{ padding: '6px 10px', fontSize: 10, color: C.greyDim, borderBottom: `1px solid ${C.border}`,
                    maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>"{ctxMenu.text}"</div>
                  <div style={CtxItem} onClick={() => window.open(otxUrl(ctxMenu.text))}>LOOKUP_ON_OTX</div>
                  <div style={CtxItem} onClick={() => window.open(vtUrl(ctxMenu.text))}>LOOKUP_ON_VIRUSTOTAL</div>
                  <div style={{ ...CtxItem, color: '#ffea00', borderTop: `1px solid ${C.border}` }} onClick={promoteIOC}>PROMOTE_TO_IOC</div>
                </div>
              )}
              <div style={{ flex: 1, overflowY: 'auto', padding: 12 }} onContextMenu={handleCtx}
                onScroll={e => {
                  const el = e.currentTarget;
                  if (el.scrollTop + el.clientHeight >= el.scrollHeight - 200) {
                    setVisibleCount(c => Math.min(c + 50, filteredRows.length));
                  }
                }}>
                {loadingEv ? (
                  <div style={{ color: C.green, fontSize: 12 }}>DECRYPTING_STORAGE_BLOCKS...</div>
                ) : dispRows.length === 0 ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {curTactic?.evidence_imported ? (
                      <div style={{ color: C.greyDim, fontSize: 12 }}>NO_ROWS_MATCH_FILTER</div>
                    ) : (
                      <>
                        <div style={{ color: C.greyDim, fontSize: 12 }}>
                          {(curTactic?.verdict || '').toUpperCase() === 'NO_ARTIFACTS'
                            ? 'AUTOMATIC_COLLECTION_RETURNED_NO_ARTIFACTS_FOR_THIS_TECHNIQUE'
                            : 'NO_EVIDENCE_COLLECTED_FOR_THIS_TECHNIQUE'}
                        </div>
                        {(curTactic?.verdict || '').toUpperCase() === 'NO_ARTIFACTS' && (
                          <div style={{ background: '#0a0a0a', border: `1px solid #333`, padding: 12 }}>
                            <div style={{ color: '#ffaa00', fontSize: 10, marginBottom: 8 }}>
                              ⚠ No artifacts found through automatic collection — manually upload evidence?
                            </div>
                            <input
                              type="file"
                              accept=".json,.jsonl,.csv,.txt"
                              id={`upload-ev-${sel}`}
                              style={{ display: 'none' }}
                              onChange={async (e) => {
                                const file = e.target.files[0];
                                if (!file) return;
                                const text = await file.text();
                                let rows = [];
                                const ext = file.name.split('.').pop().toLowerCase();
                                try {
                                  if (ext === 'json') {
                                    const parsed = JSON.parse(text);
                                    rows = Array.isArray(parsed) ? parsed : [parsed];
                                  } else if (ext === 'jsonl') {
                                    rows = text.split('\n').filter(l => l.trim()).map(l => JSON.parse(l));
                                  } else if (ext === 'csv') {
                                    const lines = text.split('\n').filter(l => l.trim());
                                    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
                                    rows = lines.slice(1).map(line => {
                                      const vals = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
                                      return Object.fromEntries(headers.map((h, i) => [h, vals[i] || '']));
                                    });
                                  } else {
                                    rows = text.split('\n').filter(l => l.trim()).map(l => ({ Line: l }));
                                  }
                                  rows = rows.map(r => ({ ...r, _orca_manual_upload: true, _orca_upload_file: file.name }));
                                } catch (err) {
                                  alert('PARSE_ERROR: ' + err.message); return;
                                }
                                if (!rows.length) { alert('NO_PARSEABLE_ROWS_FOUND'); return; }
                                const resp = await fetch(`https://10.11.110.60:8000/api/mitre/evidence/${assetId}/${sel}/upload`, {
                                  method: 'POST',
                                  headers: { ...getAuth(), 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ rows, filename: file.name })
                                });
                                if (resp.ok) { loadEvidence(sel); refreshTactics(); }
                                else { const e = await resp.json(); alert('UPLOAD_ERROR: ' + (e.detail || resp.statusText)); }
                                e.target.value = '';
                              }}
                            />
                            <label htmlFor={`upload-ev-${sel}`} style={{
                              display: 'inline-block', padding: '5px 14px', border: `1px solid #ffaa00`,
                              color: '#ffaa00', fontSize: 10, cursor: 'pointer', letterSpacing: 1
                            }}>
                              SELECT_FILE (JSON / JSONL / CSV / TXT)
                            </label>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                    {dispRows.map((item, idx) => {
                      const isFallback = item._orca_fallback === true;
                      return (
                        <div key={idx} style={{ background: C.bgCard, border: `1px solid ${isFallback ? '#ffaa00' : C.border}`, padding: 12, position: 'relative' }}>
                          <div style={{ position: 'absolute', top: -9, right: 8, background: isFallback ? '#ffaa00' : C.green, color: '#000', fontSize: 9, padding: '1px 5px', fontWeight: 'bold' }}>
                            INDEX_{idx.toString().padStart(3, '0')}
                          </div>
                          {isFallback && (
                            <div style={{ marginBottom: 8, padding: '4px 8px', background: '#1a1200', border: '1px solid #ffaa00', color: '#ffaa00', fontSize: 10 }}>
                              ⚠ BROAD COLLECTION — Primary query returned 0 hits. EventID-only filter applied. Review for relevance.
                            </div>
                          )}
                          {Object.entries(item).map(([k, v]) => {
                            if (k === 'VQLSource' || k === '_Source' || k === '_orca_fallback' || k === '_orca_fallback_note') return null;
                            return (
                              <div key={k} style={{ display: 'flex', marginBottom: 5, borderBottom: `1px solid #0d0d0d`, paddingBottom: 3 }}>
                                <div style={{ color: isFallback ? '#ffaa00' : C.green, minWidth: 155, fontSize: 11, fontWeight: 'bold', flexShrink: 0 }}>{k.toUpperCase()}:</div>
                                <div style={{ color: C.white, fontSize: 11, lineHeight: 1.4, wordBreak: 'break-word', width: '100%' }}>{fmtVal(k, v)}</div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                    {visibleCount < filteredRows.length && (
                      <div style={{ textAlign: 'center', padding: '10px 0', color: C.greyDim, fontSize: 10, letterSpacing: 1 }}>
                        ↓ SCROLL FOR MORE — {filteredRows.length - visibleCount} REMAINING
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// MEMORY ANALYSIS TAB
// ══════════════════════════════════════════════════════════════════════════════
const MemoryAnalysisTab = ({ assetId, onSummaryUpdate, collab, analysisMode = 'UNKNOWN' }) => {
  const [mode, setMode]                     = useState('single');
  const [os, setOs]                         = useState('windows');
  const [imgPath, setImgPath]               = useState('');
  const [symPaths, setSymPaths]             = useState('');
  const [selectedPlugins, setSelectedPlugins] = useState(new Set(['windows.pslist']));
  const [pluginArgs, setPluginArgs]         = useState('');
  const [actor, setActor]                   = useState(THREAT_ACTORS[0]);
  const [openGroup, setOpenGroup]           = useState('Process Analysis');
  const [yaraPath, setYaraPath]             = useState('');
  const [isRunning, setIsRunning]           = useState(false);
  const [columns, setColumns]               = useState([]);
  const [rows, setRows]                     = useState([]);
  const [sections, setSections]             = useState({});   // multi-plugin results
  const [activeSection, setActiveSection]   = useState(null);
  const [logs, setLogs]                     = useState([]);
  const [filter, setFilter]                 = useState('');
  const [expandedT, setExpandedT]           = useState(null);
  // Acquire
  const [acquireDest, setAcquireDest]       = useState('C:\\memory_dump.raw');
  const [isAcquiring, setIsAcquiring]       = useState(false);
  const [acquireLogs, setAcquireLogs]       = useState([]);
  // Dump
  const [dumpPid, setDumpPid]               = useState('');
  const [dumpDest, setDumpDest]             = useState('C:\\dumps\\');
  const [isDumping, setIsDumping]           = useState(false);
  const readerRef = useRef(null);

  const VOL3 = 'C:\\Users\\Sentinel\\Desktop\\Tests\\ORCAWEB\\backend\\bin\\remora\\volatility3';
  const addLog = (m, type = 'info') => setLogs(p => [{ t: ts(), m, type }, ...p].slice(0, 400));
  const stopStream = () => { try { readerRef.current?.cancel(); } catch {} readerRef.current = null; setIsRunning(false); };

  const togglePlugin = (p) => setSelectedPlugins(prev => {
    const n = new Set(prev); n.has(p) ? n.delete(p) : n.add(p); return n;
  });
  const selectGroup = (grp) => {
    const ps = (VOL_PLUGINS[os] || {})[grp] || [];
    setSelectedPlugins(prev => { const n = new Set(prev); ps.forEach(p => n.add(p)); return n; });
  };
  const clearGroup = (grp) => {
    const ps = (VOL_PLUGINS[os] || {})[grp] || [];
    setSelectedPlugins(prev => { const n = new Set(prev); ps.forEach(p => n.delete(p)); return n; });
  };

  const handleRun = async () => {
    if (!imgPath.trim()) { addLog('CRITICAL: Memory image path required.', 'error'); return; }
    if (mode === 'single' && selectedPlugins.size === 0) { addLog('CRITICAL: Select at least one plugin.', 'error'); return; }

    // ── TOOL LOCK CHECK ──
    if (collab) {
      const lockResult = await collab.acquireToolLock(assetId, 'volatility');
      if (lockResult.status === 'LOCKED') {
        addLog(`BLOCKED: Volatility is running for this asset by ${lockResult.locked_by} — wait for completion.`, 'error');
        return;
      }
    }
    // ── END TOOL LOCK ──

    stopStream();
    setIsRunning(true); setColumns([]); setRows([]); setSections({}); setActiveSection(null); setLogs([]);

    const args = [];
    if (yaraPath && mode === 'single') args.push('--yara-file', yaraPath);
    if (pluginArgs) args.push(...pluginArgs.split(' ').filter(Boolean));

    let endpoint, body;
    if (mode === 'single') {
      endpoint = '/api/mitre/memory/run';
      body = { asset_id: String(assetId), image_path: imgPath, plugins: [...selectedPlugins], os_profile: os, symbol_paths: symPaths || null, args, vol3_base: VOL3 };
    } else if (mode === 'full') {
      endpoint = '/api/mitre/memory/fullscan';
      body = { asset_id: String(assetId), image_path: imgPath, os_profile: os, symbol_paths: symPaths || null, vol3_base: VOL3 };
    } else {
      endpoint = '/api/mitre/memory/actorscan';
      body = { asset_id: String(assetId), image_path: imgPath, actor_name: actor, os_profile: os, symbol_paths: symPaths || null, vol3_base: VOL3 };
    }

    try {
      const resp = await fetch(`https://10.11.110.60:8000${endpoint}`, { method: 'POST', headers: getAuth(), body: JSON.stringify(body) });
      if (!resp.ok) { const e = await resp.json(); addLog('BACKEND: ' + (e.detail || resp.statusText), 'error'); setIsRunning(false); return; }
      const reader = resp.body.getReader(); readerRef.current = reader;
      const dec = new TextDecoder();
      let buf = '', curPlugin = null, curCols = [], curRows = [], totalRows = 0, pluginsRun = 0;

      const flush = (plugin, cols, rows) => { if (!plugin) return; setSections(p => ({ ...p, [plugin]: { columns: cols, rows: [...rows] } })); };
      const handle = (line) => {
        if (!line.startsWith('data: ')) return;
        try {
          const evt = JSON.parse(line.slice(6));
          if (evt.type === 'log') addLog(evt.data);
          else if (evt.type === 'error') addLog(evt.data, 'error');
          else if (evt.type === 'columns') { curCols = evt.data; }
          else if (evt.type === 'row') { totalRows++; curRows.push(evt.data); }
          else if (evt.type === 'plugin_start') { flush(curPlugin, curCols, curRows); curPlugin = evt.data; curCols = []; curRows = []; pluginsRun++; addLog(`Running: ${evt.data}`); setActiveSection(evt.data); }
          else if (evt.type === 'plugin_done') { flush(curPlugin, curCols, curRows); addLog(`✓ ${evt.data.plugin} — ${evt.data.rows} rows`, 'success'); }
          else if (evt.type === 'plugin_error') addLog(`✗ ${evt.data.plugin}: ${evt.data.error}`, 'error');
          else if (evt.type === 'done') {
            flush(curPlugin, curCols, curRows); addLog('SCAN COMPLETE', 'success'); setIsRunning(false);
            if (onSummaryUpdate) onSummaryUpdate('memory', { pluginsRun, totalRows, lastPlugin: curPlugin });
          }
        } catch {}
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) { setIsRunning(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(handle);
      }
    } catch (e) { addLog('STREAM_ERROR: ' + e.message, 'error'); setIsRunning(false); }
    finally { if (collab) collab.releaseToolLock(assetId, 'volatility'); }
  };

  const handleAcquire = async () => {
    if (!acquireDest.trim()) return;
    setIsAcquiring(true); setAcquireLogs([]);
    const aLog = (m, type = 'info') => setAcquireLogs(p => [{ t: ts(), m, type }, ...p]);
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/mitre/memory/acquire', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({ asset_id: String(assetId), destination_path: acquireDest, winpmem_base: VOL3 })
      });
      if (!resp.ok) { const e = await resp.json(); aLog('ERROR: ' + (e.detail || resp.statusText), 'error'); setIsAcquiring(false); return; }
      const reader = resp.body.getReader(); const dec = new TextDecoder(); let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) { setIsAcquiring(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(line => {
          if (!line.startsWith('data: ')) return;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'log') aLog(evt.data);
            else if (evt.type === 'done') { aLog(`✓ Acquired: ${evt.data.path} (${evt.data.size_mb} MB)`, 'success'); setImgPath(evt.data.path); setIsAcquiring(false); }
            else if (evt.type === 'error') { aLog(evt.data, 'error'); setIsAcquiring(false); }
          } catch {}
        });
      }
    } catch (e) { aLog('STREAM_ERROR: ' + e.message, 'error'); setIsAcquiring(false); }
  };

  const handleDump = async () => {
    if (!imgPath || !dumpPid) { addLog('Need image path and PID to dump.', 'error'); return; }
    setIsDumping(true);
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/mitre/memory/dump', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({ asset_id: String(assetId), image_path: imgPath, pid: parseInt(dumpPid), destination_path: dumpDest, vol3_base: VOL3 })
      });
      if (!resp.ok) { const e = await resp.json(); addLog('DUMP_ERROR: ' + (e.detail || resp.statusText), 'error'); setIsDumping(false); return; }
      const reader = resp.body.getReader(); const dec = new TextDecoder(); let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) { setIsDumping(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(line => {
          if (!line.startsWith('data: ')) return;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'log') addLog(evt.data);
            else if (evt.type === 'done') { addLog(`✓ PID ${evt.data.pid} dumped → ${evt.data.dest}`, 'success'); setIsDumping(false); }
            else if (evt.type === 'error') { addLog(evt.data, 'error'); setIsDumping(false); }
          } catch {}
        });
      }
    } catch (e) { addLog('DUMP_ERROR: ' + e.message, 'error'); setIsDumping(false); }
  };

  const pluginGroups = VOL_PLUGINS[os] || VOL_PLUGINS.windows;
  // Replace lines 810-812
  const dispCols = (activeSection && sections[activeSection]?.columns) || [];
  const dispRows = ((activeSection && sections[activeSection]?.rows) || [])
  . filter(r => Object.values(r).some(v => String(v ?? '').toLowerCase().includes(filter.toLowerCase())));

  return (
    <div style={{ display: 'flex', height: '100%', overflow: 'hidden' }}>

      {/* Plugin sidebar */}
      <div style={{ width: 210, background: C.bg, borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0 }}>
        <div style={{ padding: '5px 10px', fontSize: 9, color: C.greyDim, borderBottom: `1px solid #0a0a0a`, letterSpacing: 1 }}>PLUGIN_LIBRARY</div>
        <div style={{ padding: '5px 8px', borderBottom: `1px solid #0a0a0a` }}>
          <select value={os} onChange={e => { setOs(e.target.value); setSelectedPlugins(new Set()); setOpenGroup(Object.keys(VOL_PLUGINS[e.target.value])[0]); }}
            style={{ ...Inp, width: '100%' }}>
            <option value="windows">Windows</option>
            <option value="linux">Linux</option>
            <option value="mac">macOS</option>
          </select>
        </div>
        {mode === 'single' && (
          <div style={{ padding: '4px 10px', borderBottom: `1px solid #0a0a0a`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: C.greyDim, fontSize: 9 }}>{selectedPlugins.size} selected</span>
            <span onClick={() => setSelectedPlugins(new Set())} style={{ color: C.red, fontSize: 9, cursor: 'pointer' }}>CLEAR ALL</span>
          </div>
        )}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {Object.entries(pluginGroups).map(([grp, plugins]) => (
            <div key={grp}>
              <div onClick={() => setOpenGroup(openGroup === grp ? null : grp)}
                style={{ padding: '6px 10px', fontSize: 9, color: C.grey, cursor: 'pointer', borderBottom: `1px solid #0a0a0a`,
                  fontWeight: 'bold', userSelect: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span>{openGroup === grp ? '▼' : '▶'} {grp.toUpperCase()}</span>
                {mode === 'single' && openGroup === grp && (
                  <span onClick={e => { e.stopPropagation(); selectGroup(grp); }}
                    style={{ fontSize: 8, color: C.green, cursor: 'pointer', marginLeft: 4 }}>ALL</span>
                )}
              </div>
              {openGroup === grp && plugins.map(p => {
                const checked = selectedPlugins.has(p);
                return (
                  <div key={p} onClick={() => mode === 'single' && togglePlugin(p)}
                    style={{ padding: '5px 10px 5px 14px', fontSize: 10, cursor: mode === 'single' ? 'pointer' : 'default',
                      borderLeft: `2px solid ${checked ? C.green : 'transparent'}`,
                      color: checked ? C.green : C.greyDim,
                      background: checked ? 'rgba(0,255,65,0.04)' : 'transparent',
                      borderBottom: `1px solid #0a0a0a`, fontFamily: 'monospace',
                      display: 'flex', alignItems: 'center', gap: 7 }}>
                    {mode === 'single' && (
                      <div style={{ width: 10, height: 10, border: `1px solid ${checked ? C.green : C.border}`,
                        background: checked ? C.green : 'transparent', flexShrink: 0 }} />
                    )}
                    {p.split('.').pop()}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Main panel */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Mode tabs + config */}
        <div style={{ background: C.bg, borderBottom: `1px solid ${C.border}`, padding: '10px 15px', flexShrink: 0 }}>
          <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
            {[['single', 'SINGLE / MULTI'], ['full', 'FULL_SCAN'], ['actor', 'ACTOR_SCAN'], ['acquire', 'ACQUIRE']].map(([m, lbl]) => (
              <button key={m} onClick={() => setMode(m)}
                style={{ padding: '4px 12px', fontSize: 9, fontFamily: 'monospace', fontWeight: 'bold', cursor: 'pointer',
                  background: mode === m ? C.green : 'transparent', color: mode === m ? '#000' : C.greyDim,
                  border: `1px solid ${mode === m ? C.green : C.border}` }}>
                {lbl}
              </button>
            ))}
          </div>

          {mode !== 'acquire' && (
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <div style={{ flex: 2, display: 'flex', flexDirection: 'column', gap: 7 }}>
                {/* Image path */}
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={Lbl}>MEMORY_IMAGE:</span>
                  <input value={imgPath} onChange={e => setImgPath(e.target.value)}
                    placeholder="C:\\path\\to\\memory.raw"
                    style={{ ...Inp, flex: 1 }} />
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={Lbl}>SYMBOL_PATHS:</span>
                  <input value={symPaths} onChange={e => setSymPaths(e.target.value)} placeholder="optional"
                    style={{ ...Inp, flex: 1 }} />
                </div>
                {mode === 'single' && (
                  <>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={Lbl}>PLUGIN_ARGS:</span>
                      <input value={pluginArgs} onChange={e => setPluginArgs(e.target.value)} placeholder="e.g. --pid 1234"
                        style={{ ...Inp, flex: 1 }} />
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={Lbl}>YARA_RULES:</span>
                      <input value={yaraPath} onChange={e => setYaraPath(e.target.value)} placeholder="C:\\rules\\custom.yar (optional)"
                        style={{ ...Inp, flex: 1 }} />
                    </div>
                  </>
                )}
                {mode === 'actor' && (
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={Lbl}>THREAT_ACTOR:</span>
                    <select value={actor} onChange={e => setActor(e.target.value)} style={{ ...Inp, flex: 1 }}>
                      {THREAT_ACTORS.map(a => <option key={a} value={a}>{a}</option>)}
                    </select>
                  </div>
                )}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
                {mode === 'single' && <div style={{ color: C.green, fontSize: 11, fontWeight: 'bold' }}>{selectedPlugins.size} plugin{selectedPlugins.size !== 1 ? 's' : ''} selected</div>}
                {isRunning
                  ? <button onClick={stopStream} style={{ ...Btn, background: C.red, color: C.white }}>■ STOP</button>
                  : <button onClick={handleRun} style={Btn}>▶ EXECUTE</button>
                }
              </div>
            </div>
          )}

          {/* Acquire / Dump panel */}
          {mode === 'acquire' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ color: C.amber, fontSize: 11, marginBottom: 2 }}>⚠ LIVE MEMORY ACQUISITION — Requires admin privileges</div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={Lbl}>OUTPUT_PATH:</span>
                <input value={acquireDest} onChange={e => setAcquireDest(e.target.value)} placeholder="C:\\memory_dump.raw"
                  style={{ ...Inp, flex: 1 }} />
                <button onClick={handleAcquire} disabled={isAcquiring}
                  style={{ ...Btn, opacity: isAcquiring ? 0.5 : 1 }}>
                  {isAcquiring ? 'ACQUIRING...' : '▶ ACQUIRE'}
                </button>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={Lbl}>DUMP_PID:</span>
                <input value={dumpPid} onChange={e => setDumpPid(e.target.value)} placeholder="Process ID" style={{ ...Inp, width: 100 }} />
                <span style={Lbl}>DUMP_DEST:</span>
                <input value={dumpDest} onChange={e => setDumpDest(e.target.value)} placeholder="C:\\dumps\\" style={{ ...Inp, flex: 1 }} />
                <button onClick={handleDump} disabled={isDumping}
                  style={{ ...Btn, background: 'transparent', border: `1px solid ${C.amber}`, color: C.amber, opacity: isDumping ? 0.5 : 1 }}>
                  {isDumping ? 'DUMPING...' : '▶ DUMP_PID'}
                </button>
              </div>
              {acquireLogs.length > 0 && (
                <div style={{ maxHeight: 75, overflowY: 'auto', background: '#0a0a0a', border: `1px solid ${C.border}`, padding: 6 }}>
                  {acquireLogs.map((l, i) => (
                    <div key={i} style={{ fontSize: 9, color: l.type === 'error' ? C.red : l.type === 'success' ? C.green : C.greyDim, fontFamily: 'monospace' }}>
                      [{l.t}] {l.m}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Multi-plugin section tabs */}
        {mode !== 'acquire' && Object.keys(sections).length > 0 && (
          <div style={{ display: 'flex', overflowX: 'auto', background: '#080808', borderBottom: `1px solid #0a0a0a`, padding: '5px 10px', gap: 4, flexShrink: 0 }}>
            {Object.keys(sections).map(p => (
              <button key={p} onClick={() => setActiveSection(p)}
                style={{ background: C.bg, border: `1px solid ${activeSection === p ? C.green : C.border}`,
                  color: activeSection === p ? C.green : C.greyDim, padding: '3px 10px', fontSize: 9, fontFamily: 'monospace', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                {p.split('.').pop()} ({sections[p].rows.length})
              </button>
            ))}
          </div>
        )}

        {/* Results + log panel */}
        {mode !== 'acquire' && (
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              {dispCols.length > 0 ? (
                <>
                  <div style={{ padding: '5px 12px', background: C.bg, borderBottom: `1px solid #0a0a0a`,
                    display: 'flex', gap: 10, alignItems: 'center', flexShrink: 0 }}>
                    <span style={{ color: C.grey, fontSize: 11 }}>{dispRows.length} ROWS</span>
                    <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="FILTER..."
                      style={{ ...Inp, width: 200 }} />
                  </div>
                  <div style={{ flex: 1, overflowY: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11, fontFamily: 'monospace' }}>
                      <thead>
                        <tr style={{ background: C.bgHeader, position: 'sticky', top: 0, zIndex: 1 }}>
                          {dispCols.filter(c => !c.startsWith('_')).map(col => (
                            <th key={col} style={{ padding: '6px 10px', textAlign: 'left', color: C.grey, borderBottom: `1px solid ${C.border}`, fontWeight: 'bold' }}>{col}</th>
                          ))}
                          <th style={{ padding: '6px 10px', textAlign: 'left', color: C.grey, borderBottom: `1px solid ${C.border}`, minWidth: 100 }}>MITRE</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dispRows.map((row, i) => {
                          const badges = row._mitre_techniques || [];
                          return (
                            <tr key={i} style={{ borderBottom: `1px solid #0a0a0a`, background: i % 2 === 0 ? '#040404' : C.bg }}>
                              {dispCols.filter(c => !c.startsWith('_')).map(col => (
                                <td key={col} style={{ padding: '5px 10px', color: C.white, verticalAlign: 'top' }}>{row[col] ?? '---'}</td>
                              ))}
                              <td style={{ padding: '5px 10px', verticalAlign: 'top' }}>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                                  {badges.map(b => (
                                    <span key={b.t_code} onClick={() => setExpandedT(expandedT === b.t_code ? null : b.t_code)}
                                      style={{ fontSize: 9, padding: '1px 4px', cursor: 'pointer',
                                        border: `1px solid ${CONF_COLOR[b.confidence] || C.border}`,
                                        color: CONF_COLOR[b.confidence] || C.grey, fontFamily: 'monospace' }}>
                                      {b.t_code} [{b.confidence}]
                                    </span>
                                  ))}
                                </div>
                                {badges.some(b => b.t_code === expandedT) && (
                                  <div style={{ marginTop: 3, fontSize: 9, color: C.grey, lineHeight: 1.3 }}>
                                    {MITRE_NAMES[expandedT]}
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div style={{ flex: 1, padding: 20 }}>
                  <div style={{ color: C.greyDim, fontSize: 12 }}>
                    {mode === 'single'
                      ? `AWAITING_EXECUTION — ${selectedPlugins.size} plugin(s) selected`
                      : 'AWAITING_SCAN_EXECUTION — Configure and press EXECUTE'}
                  </div>
                </div>
              )}
            </div>
            <LogCol logs={logs} />
          </div>
        )}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// KNOWN MALWARE SIGNATURES TAB
// ══════════════════════════════════════════════════════════════════════════════
const MalwareSignaturesTab = ({ assetId, onSummaryUpdate, collab }) => {
  const [scanPath, setScanPath]     = useState('C:\\');
  const [recursive, setRecursive]   = useState(true);
  const [remove, setRemove]         = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateResult, setUpdateResult] = useState(null);
  const [threats, setThreats]       = useState([]);
  const [scanned, setScanned]       = useState(null);
  const [infected, setInfected]     = useState(null);
  const [logs, setLogs]             = useState([]);
  const [filter, setFilter]         = useState('');
  const readerRef = useRef(null);
  const CLAM = 'C:\\Users\\Sentinel\\Desktop\\Tests\\ORCAWEB\\backend\\bin\\clamav';

  const addLog = (m, type = 'info') => setLogs(p => [{ t: ts(), m, type }, ...p].slice(0, 500));
  const stopScan = () => { try { readerRef.current?.cancel(); } catch {} readerRef.current = null; setIsScanning(false); };

  const handleUpdate = async () => {
    setIsUpdating(true); setUpdateResult(null);
    addLog('Running freshclam — this may take a moment...');
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/mitre/scan/clam/update',
        { method: 'POST', headers: getAuth(), body: JSON.stringify({ clam_base: CLAM }) });
      const d = await resp.json();
      setUpdateResult(d);
      addLog(d.message || 'Update complete.', d.status === 'SUCCESS' ? 'success' : 'error');
    } catch (e) { addLog('UPDATE_ERROR: ' + e.message, 'error'); }
    finally { setIsUpdating(false); }
  };

  const handleScan = async () => {
    if (!scanPath.trim()) { addLog('CRITICAL: Scan target path required.', 'error'); return; }

    // ── TOOL LOCK CHECK ──
    if (collab) {
      const lockResult = await collab.acquireToolLock(assetId, 'clamav');
      if (lockResult.status === 'LOCKED') {
        addLog(`BLOCKED: ClamAV is running for this asset by ${lockResult.locked_by} — wait for completion.`, 'error');
        return;
      }
    }
  // ── END TOOL LOCK ──

    stopScan();
    setIsScanning(true); setThreats([]); setScanned(null); setInfected(null); setLogs([]);
    addLog(`Starting ClamAV scan: ${scanPath}`);
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/mitre/scan/clam', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({ asset_id: String(assetId), scan_path: scanPath, recursive, remove, clam_base: CLAM })
      });
      if (!resp.ok) { const e = await resp.json(); addLog('BACKEND: ' + (e.detail || resp.statusText), 'error'); setIsScanning(false); return; }
      const reader = resp.body.getReader(); readerRef.current = reader;
      const dec = new TextDecoder(); let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) { setIsScanning(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(line => {
          if (!line.startsWith('data: ')) return;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'log') addLog(evt.data);
            else if (evt.type === 'threat') { setThreats(p => [...p, evt.data]); addLog(evt.data, 'error'); }
            else if (evt.type === 'summary') addLog(evt.data);
            else if (evt.type === 'done') {
              setScanned(evt.data.scanned_files); setInfected(evt.data.infected_files);
              addLog(`SCAN COMPLETE — Scanned: ${evt.data.scanned_files}, Infected: ${evt.data.infected_files}`,
                evt.data.infected_files > 0 ? 'error' : 'success');
              setIsScanning(false);
              if (onSummaryUpdate) onSummaryUpdate('av', { scanned: evt.data.scanned_files, infected: evt.data.infected_files });
            }
            else if (evt.type === 'error') { addLog(evt.data, 'error'); setIsScanning(false); }
          } catch {}
        });
      }
    } catch (e) { addLog('STREAM_ERROR: ' + e.message, 'error'); setIsScanning(false); }
    finally { if (collab) collab.releaseToolLock(assetId, 'clamav'); }
  };

  const filteredThreats = threats.filter(t => t.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Config bar */}
      <div style={{ background: C.bg, borderBottom: `1px solid ${C.border}`, padding: '10px 15px', flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={Lbl}>SCAN_TARGET:</span>
          <input value={scanPath} onChange={e => setScanPath(e.target.value)} placeholder="C:\Users\"
            style={{ ...Inp, flex: 1, minWidth: 200 }} />
          <label style={{ color: C.grey, fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', fontFamily: 'monospace' }}>
            <input type="checkbox" checked={recursive} onChange={e => setRecursive(e.target.checked)} style={{ marginRight: 4 }} /> RECURSIVE
          </label>
          <label style={{ color: remove ? C.red : C.greyDim, fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', fontFamily: 'monospace' }}>
            <input type="checkbox" checked={remove} onChange={e => setRemove(e.target.checked)} style={{ marginRight: 4 }} /> REMOVE_THREATS
          </label>
          {isScanning
            ? <button onClick={stopScan} style={{ ...Btn, background: C.red, color: C.white }}>■ STOP_SCAN</button>
            : <button onClick={handleScan} style={Btn}>▶ RUN_CLAMSCAN</button>
          }
          <button onClick={handleUpdate} disabled={isUpdating}
            style={{ ...Btn, background: 'transparent', border: `1px solid ${C.border}`, color: C.grey, opacity: isUpdating ? 0.5 : 1 }}>
            {isUpdating ? 'UPDATING...' : '⟳ UPDATE_DEFS'}
          </button>
        </div>
        {updateResult && (
          <div style={{ marginTop: 8, padding: '6px 10px', fontSize: 11, fontFamily: 'monospace',
            background: updateResult.return_code <= 1 ? 'rgba(0,255,65,0.04)' : 'rgba(255,68,68,0.04)',
            border: `1px solid ${updateResult.return_code <= 1 ? C.green : C.red}`,
            color: updateResult.return_code <= 1 ? C.green : C.red }}>
            {updateResult.message}
            {updateResult.return_code > 1 && (
              <details style={{ marginTop: 4 }}>
                <summary style={{ cursor: 'pointer', fontSize: 10 }}>Show output</summary>
                <pre style={{ color: C.greyDim, fontSize: 9, marginTop: 4, whiteSpace: 'pre-wrap', maxHeight: 120, overflow: 'auto' }}>
                  {updateResult.output}
                </pre>
              </details>
            )}
          </div>
        )}
      </div>

      {/* Summary bar */}
      {scanned !== null && (
        <div style={{ display: 'flex', background: '#0a0a0a', borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
          {[['SCANNED_FILES', scanned, C.white], ['INFECTED', infected, infected > 0 ? C.red : C.green],
            ['STATUS', infected > 0 ? '⚠ THREATS_DETECTED' : '✓ CLEAN', infected > 0 ? C.red : C.green]
          ].map(([l, v, col]) => (
            <div key={l} style={{ padding: '10px 20px', borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
              <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{l}</span>
              <span style={{ color: col, fontSize: typeof v === 'number' ? 20 : 11, fontWeight: 'bold', fontFamily: 'monospace' }}>{String(v)}</span>
            </div>
          ))}
        </div>
      )}

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRight: `1px solid #0a0a0a` }}>
          <div style={{ padding: '5px 12px', background: '#0a0a0a', borderBottom: `1px solid #0a0a0a`,
            display: 'flex', gap: 10, alignItems: 'center', flexShrink: 0 }}>
            <span style={{ color: C.grey, fontSize: 10, letterSpacing: 1 }}>THREAT_SIGNATURES ({filteredThreats.length})</span>
            <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="FILTER..."
              style={{ ...Inp, width: 160 }} />
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: 8 }}>
            {filteredThreats.length === 0 ? (
              <div style={{ color: C.greyDim, fontSize: 12, padding: 10 }}>
                {isScanning ? 'SCANNING IN PROGRESS...' : scanned !== null ? 'NO_THREATS_DETECTED — System clean.' : 'AWAITING_SCAN_EXECUTION — Configure target and press RUN_CLAMSCAN.'}
              </div>
            ) : filteredThreats.map((t, i) => (
              <div key={i} style={{ padding: '6px 10px', borderBottom: `1px solid #0a0a0a`, display: 'flex', alignItems: 'flex-start' }}>
                <span style={{ color: C.red, marginRight: 8, flexShrink: 0 }}>⚠</span>
                <span style={{ color: C.amber, fontSize: 11, wordBreak: 'break-all', fontFamily: 'monospace' }}>{t}</span>
              </div>
            ))}
          </div>
        </div>
        <LogCol logs={logs} width={300} />
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// VULN SCAN TAB — Syft + Grype
// ══════════════════════════════════════════════════════════════════════════════
const VulnScanTab = ({ assetId, analysisMode, collab, onScanComplete }) => {
  const [scanPath, setScanPath]       = useState('C:\\');
  const [offline, setOffline]         = useState(false);
  const [isScanning, setIsScanning]   = useState(false);
  const [logs, setLogs]               = useState([]);
  const [summary, setSummary]         = useState(null);
  const [vulns, setVulns]             = useState([]);
  const [filter, setFilter]           = useState('');
  const [sevFilter, setSevFilter]     = useState('ALL');
  const [sortCol, setSortCol]         = useState('severity');
  const [sortDir, setSortDir]         = useState('asc');
  const readerRef                     = useRef(null);

  const SEV_ORDER = { Critical: 0, High: 1, Medium: 2, Low: 3, Unknown: 4 };
  const handleSort = col => {
    if (sortCol === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortCol(col); setSortDir('asc'); }
  };

  const addLog = (m, type = 'info') => setLogs(p => [{ t: ts(), m, type }, ...p].slice(0, 500));
  const stopScan = () => { try { readerRef.current?.cancel(); } catch {} readerRef.current = null; setIsScanning(false); };

  // Load existing results on mount
  useEffect(() => {
    if (!assetId) return;
    fetch(`https://10.11.110.60:8000/api/assets/${assetId}/vuln-results`, { headers: getAuth() })
      .then(r => r.ok ? r.json() : [])
      .then(data => { if (data.length) setVulns(data); })
      .catch(() => {});
  }, [assetId]);

  const handleScan = async () => {
    if (!scanPath.trim()) { addLog('SCAN_PATH required', 'error'); return; }
    if (collab) {
      const lock = await collab.acquireToolLock(assetId, 'grype');
      if (lock.status === 'LOCKED') {
        addLog(`BLOCKED: Vuln scan running for this asset by ${lock.locked_by}`, 'error');
        return;
      }
    }
    stopScan();
    setIsScanning(true); setLogs([]); setSummary(null);
    addLog(`Starting Syft → Grype pipeline on ${scanPath}`);
    try {
      const resp = await fetch('https://10.11.110.60:8000/api/assets/vuln-scan', {
        method: 'POST', headers: getAuth(),
        body: JSON.stringify({ asset_id: assetId, scan_path: scanPath, offline }),
      });
      if (!resp.ok) { const e = await resp.json(); addLog('BACKEND: ' + (e.detail || resp.statusText), 'error'); setIsScanning(false); return; }
      const reader = resp.body.getReader(); readerRef.current = reader;
      const dec = new TextDecoder(); let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) { setIsScanning(false); break; }
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop();
        lines.forEach(line => {
          if (!line.startsWith('data: ')) return;
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === 'log')     addLog(evt.data);
            else if (evt.type === 'error')   addLog(evt.data, 'error');
            else if (evt.type === 'summary') {
              setSummary(evt.data);
              if (onScanComplete) onScanComplete(evt.data);
              // Reload results from DB
              fetch(`https://10.11.110.60:8000/api/assets/${assetId}/vuln-results`, { headers: getAuth() })
                .then(r => r.json()).then(setVulns).catch(() => {});
            }
            else if (evt.type === 'done') {
              addLog(evt.data, evt.data.includes('FAILED') ? 'error' : 'success');
              setIsScanning(false);
            }
          } catch {}
        });
      }
    } catch (e) { addLog('STREAM_ERROR: ' + e.message, 'error'); setIsScanning(false); }
    finally { if (collab) collab.releaseToolLock(assetId, 'grype'); }
  };

  const isDead = analysisMode === 'DEAD_DISK_LOCAL' || analysisMode === 'DEAD_DISK_REMOTE';

  const sevColor = { Critical: C.red, High: '#ff8800', Medium: C.amber, Low: C.green, Unknown: C.greyDim };

  const filtered = vulns.filter(v => {
    const matchSev = sevFilter === 'ALL' || v.severity === sevFilter;
    const matchText = !filter || v.cve_id?.toLowerCase().includes(filter.toLowerCase()) ||
      v.package?.toLowerCase().includes(filter.toLowerCase());
    return matchSev && matchText;
  }).sort((a, b) => {
    let av, bv;
    if (sortCol === 'severity') {
      av = SEV_ORDER[a.severity] ?? 99;
      bv = SEV_ORDER[b.severity] ?? 99;
    } else {
      av = (a[sortCol] || '').toLowerCase();
      bv = (b[sortCol] || '').toLowerCase();
    }
    if (av < bv) return sortDir === 'asc' ? -1 : 1;
    if (av > bv) return sortDir === 'asc' ?  1 : -1;
    return 0;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>

      {/* Config bar */}
      <div style={{ background: C.bg, borderBottom: `1px solid ${C.border}`, padding: '10px 15px', flexShrink: 0 }}>
        {!isDead ? (
          <div style={{ color: C.amber, fontSize: 11, fontFamily: 'monospace' }}>
            ⚠ VULN_SCAN requires DEAD_DISK_LOCAL or DEAD_DISK_REMOTE mode
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={Lbl}>SCAN_PATH:</span>
            <input value={scanPath} onChange={e => setScanPath(e.target.value)}
              placeholder="N:\\" style={{ ...Inp, flex: 1, minWidth: 200 }} />
            <label style={{ color: offline ? C.amber : C.greyDim, fontSize: 11, cursor: 'pointer',
              display: 'flex', alignItems: 'center', fontFamily: 'monospace' }}>
              <input type="checkbox" checked={offline} onChange={e => setOffline(e.target.checked)}
                style={{ marginRight: 4 }} /> OFFLINE_DB
            </label>
            {isScanning
              ? <button onClick={stopScan} style={{ ...Btn, background: C.red, color: C.white }}>■ STOP</button>
              : <button onClick={handleScan} style={Btn}>▶ RUN_VULN_SCAN</button>
            }
          </div>
        )}
      </div>

      {/* Summary bar */}
      {summary && (
        <div style={{ display: 'flex', background: '#0a0a0a', borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
          {[
            ['TOTAL',    summary.total,    C.white],
            ['CRITICAL', summary.critical, summary.critical > 0 ? C.red : C.greyDim],
            ['HIGH',     summary.high,     summary.high > 0 ? '#ff8800' : C.greyDim],
            ['MEDIUM',   summary.medium,   summary.medium > 0 ? C.amber : C.greyDim],
            ['LOW',      summary.low,      summary.low > 0 ? C.green : C.greyDim],
          ].map(([l, v, col]) => (
            <div key={l} style={{ padding: '10px 20px', borderRight: `1px solid ${C.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
              <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{l}</span>
              <span style={{ color: col, fontSize: 20, fontWeight: 'bold', fontFamily: 'monospace' }}>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* Results + log */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

        {/* Vuln table */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Filter bar */}
          <div style={{ padding: '6px 12px', background: '#0a0a0a', borderBottom: `1px solid #0a0a0a`,
            display: 'flex', gap: 8, alignItems: 'center', flexShrink: 0 }}>
            <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="FILTER CVE / PACKAGE..."
              style={{ ...Inp, width: 220 }} />
            {['ALL','Critical','High','Medium','Low'].map(s => (
              <button key={s} onClick={() => setSevFilter(s)}
                style={{ padding: '2px 8px', fontSize: 9, fontFamily: 'monospace', cursor: 'pointer',
                  background: sevFilter === s ? (sevColor[s] || C.green) : 'transparent',
                  color: sevFilter === s ? '#000' : (sevColor[s] || C.greyDim),
                  border: `1px solid ${sevColor[s] || C.border}` }}>
                {s}
              </button>
            ))}
            <span style={{ color: C.greyDim, fontSize: 9, marginLeft: 'auto' }}>{filtered.length} results</span>
          </div>

          {/* Table */}
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {filtered.length === 0 ? (
              <div style={{ color: C.greyDim, fontSize: 12, padding: 20 }}>
                {isScanning ? 'SCAN IN PROGRESS...' : vulns.length > 0 ? 'NO_RESULTS_MATCH_FILTER' : 'AWAITING_SCAN — Configure path and press RUN_VULN_SCAN'}
              </div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11, fontFamily: 'monospace' }}>
                <thead>
                  <tr style={{ background: '#0a0a0a', position: 'sticky', top: 0 }}>
                    {[
                      ['SEVERITY',    'severity'],
                      ['CVE_ID',      'cve_id'],
                      ['PACKAGE',     'package'],
                      ['VERSION',     'version'],
                      ['FIX_VERSION', 'fix_version'],
                      ['FIX_STATE',   'fix_state'],
                    ].map(([label, col]) => (
                      <th key={col} onClick={() => handleSort(col)}
                        style={{ padding: '6px 10px', color: sortCol === col ? C.green : C.greyDim,
                          fontSize: 9, letterSpacing: 1, textAlign: 'left',
                          borderBottom: `1px solid ${C.border}`, cursor: 'pointer',
                          userSelect: 'none', whiteSpace: 'nowrap' }}>
                        {label}{sortCol === col ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ' ⇅'}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((v, i) => (
                    <tr key={i} style={{ borderBottom: `1px solid #0a0a0a`,
                      background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)' }}>
                      <td style={{ padding: '5px 10px' }}>
                        <span style={{ color: sevColor[v.severity] || C.greyDim, fontWeight: 'bold', fontSize: 10 }}>
                          {v.severity}
                        </span>
                      </td>
                      <td style={{ padding: '5px 10px', color: C.green }}>{v.cve_id}</td>
                      <td style={{ padding: '5px 10px', color: C.white }}>{v.package}</td>
                      <td style={{ padding: '5px 10px', color: C.grey }}>{v.version}</td>
                      <td style={{ padding: '5px 10px', color: v.fix_version ? C.green : C.greyDim }}>
                        {v.fix_version || '—'}
                      </td>
                      <td style={{ padding: '5px 10px', color: C.greyDim, fontSize: 10 }}>{v.fix_state || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <LogCol logs={logs} width={280} />
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// ROOT: EVIDENCE WINDOW
// PATCH: Replace lines 1190–1261 in EvidenceWindow.jsx
//
// ══════════════════════════════════════════════════════════════════════════════
// REPORT TAB
// ══════════════════════════════════════════════════════════════════════════════
const ReportTab = ({ caseName, assetId }) => {
  const [report, setReport]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState(null);

  const fetchReport = async () => {
    setLoading(true); setError(null);
    try {
      const url = `https://10.11.110.60:8000/api/reports/${encodeURIComponent(caseName)}${assetId ? `?asset_id=${assetId}` : ''}`;
      const r = await fetch(url, { headers: getAuth() });
      if (!r.ok) { setError(`HTTP ${r.status}`); return; }
      setReport(await r.json());
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (caseName) fetchReport(); }, [caseName, assetId]);

  if (loading) return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.greyDim, fontSize: 12 }}>
      ASSEMBLING_REPORT...
    </div>
  );
  if (error) return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.red, fontSize: 12 }}>
      REPORT_ERROR: {error}
    </div>
  );
  if (!report) return null;

  const { summary, bluf_notes, timeline, techniques, assets } = report;
  const vCol = { MALICIOUS: C.red, 'NON-MALICIOUS': C.green, UNDETERMINED: C.greyDim, 'EVIDENCE FOUND': C.purple, NO_ARTIFACTS: C.greyDim };

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: 18, display: 'flex', flexDirection: 'column', gap: 14, boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ color: C.green, fontSize: 14, fontWeight: 'bold' }}>{report.case_name}</div>
          <div style={{ color: C.greyDim, fontSize: 10, marginTop: 3 }}>FOCUS: {report.focus_country} &nbsp;·&nbsp; GENERATED: {new Date(report.generated_at).toLocaleString()}</div>
        </div>
        <button onClick={fetchReport} style={{ ...Btn, background: 'transparent', border: `1px solid ${C.green}`, color: C.green }}>↻ REFRESH</button>
      </div>

      <Card title="INVESTIGATION_SUMMARY">
        <div style={{ padding: 14, display: 'flex', gap: 0, flexWrap: 'wrap' }}>
          {[
            ['TOTAL',        summary.total_techniques, C.white],
            ['CLOSED',       summary.closed,           C.green],
            ['EVIDENCE',     summary.with_evidence,    C.purple],
            ['NO_ARTIFACTS', summary.no_artifacts,     C.greyDim],
            ['PENDING',      summary.pending,          '#ffaa00'],
            ['COMPLETION',   `${summary.completion_pct}%`, C.green],
            ['MALICIOUS',    summary.malicious,        C.red],
            ['NON-MALICIOUS',summary.non_malicious,    C.green],
            ['UNDETERMINED', summary.undetermined,     C.greyDim],
          ].map(([label, val, col]) => (
            <div key={label} style={{ padding: '10px 18px', borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', gap: 3 }}>
              <span style={{ color: C.greyDim, fontSize: 9, letterSpacing: 1 }}>{label}</span>
              <span style={{ color: col, fontSize: 22, fontWeight: 'bold' }}>{val}</span>
            </div>
          ))}
        </div>
      </Card>

      {assets.length > 0 && (
        <Card title={`ASSETS (${assets.length})`}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11, fontFamily: 'monospace' }}>
            <thead><tr style={{ background: C.bgHeader }}>
              {['HOSTNAME','OS','TYPE','MODE'].map(h => <th key={h} style={{ padding: '6px 12px', textAlign: 'left', color: C.greyDim, borderBottom: `1px solid ${C.border}` }}>{h}</th>)}
            </tr></thead>
            <tbody>{assets.map(a => (
              <tr key={a.id} style={{ borderBottom: `1px solid #0a0a0a` }}>
                <td style={{ padding: '5px 12px', color: C.green }}>{a.hostname || `ASSET_${a.id}`}</td>
                <td style={{ padding: '5px 12px', color: C.white }}>{a.os || '—'}</td>
                <td style={{ padding: '5px 12px', color: C.grey }}>{a.asset_type || '—'}</td>
                <td style={{ padding: '5px 12px', color: C.greyDim }}>{a.analysis_mode || '—'}</td>
              </tr>
            ))}</tbody>
          </table>
        </Card>
      )}

      {bluf_notes.length > 0 && (
        <Card title="BLUF_NOTES">
          <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
            {bluf_notes.map((n, i) => (
              <div key={i} style={{ borderLeft: `3px solid ${C.green}`, paddingLeft: 12 }}>
                <div style={{ color: C.greyDim, fontSize: 9, marginBottom: 4 }}>{n.author || 'ANALYST'} &nbsp;·&nbsp; {n.created_at ? new Date(n.created_at).toLocaleString() : ''}</div>
                <div style={{ color: C.white, fontSize: 12, whiteSpace: 'pre-wrap' }}>{n.text}</div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {timeline.length > 0 && (
        <Card title={`ANALYST_TIMELINE (${timeline.length})`}>
          <div style={{ maxHeight: 320, overflowY: 'auto' }}>
            {timeline.map((entry, i) => (
              <div key={i} style={{ padding: '8px 14px', borderBottom: `1px solid #0a0a0a`, display: 'flex', gap: 12 }}>
                <div style={{ color: C.green, fontSize: 10, minWidth: 70, flexShrink: 0 }}>{entry.t_code}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ color: C.greyDim, fontSize: 9, marginBottom: 3 }}>[{entry.initials || entry.author || '?'}] &nbsp;·&nbsp; {entry.note_type} &nbsp;·&nbsp; {entry.created_at ? new Date(entry.created_at).toLocaleString() : ''}</div>
                  <div style={{ color: C.white, fontSize: 11, whiteSpace: 'pre-wrap' }}>{entry.text}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card title={`TECHNIQUE_VERDICTS (${techniques.length})`}>
        <div style={{ maxHeight: 400, overflowY: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11, fontFamily: 'monospace' }}>
            <thead><tr style={{ background: C.bgHeader, position: 'sticky', top: 0 }}>
              {['T_CODE','TECHNIQUE','STATUS','EVIDENCE','VERDICT','ACTORS'].map(h => (
                <th key={h} style={{ padding: '6px 10px', textAlign: 'left', color: C.greyDim, borderBottom: `1px solid ${C.border}` }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>{techniques.map((t, i) => {
              const v = (t.verdict || 'UNDETERMINED').toUpperCase();
              return (
                <tr key={i} style={{ borderBottom: `1px solid #0a0a0a` }}>
                  <td style={{ padding: '4px 10px', color: C.green }}>{t.t_code}</td>
                  <td style={{ padding: '4px 10px', color: C.grey, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.technique_name}</td>
                  <td style={{ padding: '4px 10px', color: t.technique_status === 'CLOSED' ? C.green : C.greyDim }}>{t.technique_status || 'UNCLAIMED'}</td>
                  <td style={{ padding: '4px 10px', color: t.evidence_imported ? C.purple : C.greyDim }}>{t.evidence_imported ? '✓' : '—'}</td>
                  <td style={{ padding: '4px 10px', color: vCol[v] || C.greyDim }}>{v}</td>
                  <td style={{ padding: '4px 10px', color: C.greyDim, fontSize: 10, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.associated_actors || '—'}</td>
                </tr>
              );
            })}</tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// THE FIX: Tab content is now always mounted. Each tab wrapper uses
// display: 'flex'/'none' to show/hide. This means MemoryAnalysisTab,
// MalwareSignaturesTab, and ArtifactAnalysisTab are NEVER unmounted when
// switching tabs — their state, refs, and active SSE streams all survive.
// ══════════════════════════════════════════════════════════════════════════════
const EvidenceWindow = ({ assetId, assetName, tCode, isOpen, onClose, tacticList, caseName, collab, analysisMode = 'UNKNOWN', assetIp = '' }) => {
  const [tab, setTab]                 = useState('OVERVIEW');
  const [progressLabel, setProgressLabel] = useState(null);
  const [memSummary, setMemSummary]   = useState(null);
  const [avSummary, setAvSummary]     = useState(null);
  const [vulnSummary, setVulnSummary] = useState(null);

useEffect(() => {
    if (isOpen) {
      setTab('OVERVIEW');
      setProgressLabel(null);
      setVulnSummary(null);
      if (collab && assetId) collab.loadTechniqueStatuses(assetId);
      // Persist vuln summary across sessions by deriving counts from stored results
      fetch(`https://10.11.110.60:8000/api/assets/${assetId}/vuln-results`, { headers: getAuth() })
        .then(r => r.ok ? r.json() : [])
        .then(rows => {
          if (!rows.length) return;
          const counts = { total: rows.length, critical: 0, high: 0, medium: 0, low: 0 };
          rows.forEach(r => {
            const s = (r.severity || '').toLowerCase();
            if (s === 'critical') counts.critical++;
            else if (s === 'high')     counts.high++;
            else if (s === 'medium')   counts.medium++;
            else if (s === 'low')      counts.low++;
          });
          setVulnSummary(counts);
        })
        .catch(() => {});
    }
  }, [isOpen, assetId]);

  if (!isOpen) return null;

  const TABS = ['OVERVIEW', 'ARTIFACT_ANALYSIS', 'MEMORY_ANALYSIS', 'KNOWN_MALWARE_SIGNATURES', 'VULN_SCAN', 'REPORT'];

  // Shared style for each tab's wrapper div.
  // When the tab is active: flex column filling all available space.
  // When inactive: display none — component stays mounted, state/streams preserved.
  const tabStyle = (name) => ({
    display: tab === name ? 'flex' : 'none',
    flexDirection: 'column',
    flex: 1,
    overflow: 'hidden',
  });

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)', display: 'flex',
      justifyContent: 'center', alignItems: 'center', zIndex: 1000, fontFamily: 'monospace' }}>
      <div style={{ width: '93%', height: '93%', background: '#050505', border: `1px solid ${C.green}`,
        display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Header */}
        <div style={{ padding: '10px 20px', borderBottom: `1px solid ${C.border}`, display: 'flex',
          justifyContent: 'space-between', alignItems: 'center', background: C.bg, flexShrink: 0 }}>
          <div style={{ color: C.green, fontWeight: 'bold', fontSize: 14 }}>
            [INVESTIGATION_WORKSPACE]: {(assetName || `ASSET_${assetId}`).toUpperCase()}
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: C.red, cursor: 'pointer', fontWeight: 'bold', fontSize: 16, fontFamily: 'monospace' }}>[ X ]</button>
        </div>

        {/* Analysis mode banner */}
        {analysisMode === 'UNKNOWN' && (
          <div style={{ padding: '5px 20px', background: 'rgba(255,170,0,0.06)', borderBottom: `1px solid ${C.amber}`,
            color: C.amber, fontSize: 10, letterSpacing: 1, flexShrink: 0 }}>
            ⚠ ANALYSIS_MODE: UNKNOWN — set mode on ASSETS tab to gate tool availability
          </div>
        )}
        {analysisMode !== 'UNKNOWN' && (
          <div style={{ padding: '5px 20px', background: 'rgba(0,255,65,0.03)', borderBottom: `1px solid ${C.border}`,
            color: C.greyDim, fontSize: 10, letterSpacing: 1, flexShrink: 0 }}>
            MODE: {analysisMode}
          </div>
        )}

        {/* Collection status bar — shows real progress while collection runs */}
        <CollectionStatusBar tacticList={tacticList} />

        {/* Tab bar */}
        <div style={{ display: 'flex', background: C.bg, borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ padding: '10px 20px', border: 'none', cursor: 'pointer', fontSize: 11,
                fontFamily: 'monospace', fontWeight: 'bold', letterSpacing: 1,
                borderBottom: `2px solid ${tab === t ? C.green : 'transparent'}`,
                color: tab === t ? C.green : C.greyDim,
                background: tab === t ? 'rgba(0,255,65,0.04)' : 'transparent' }}>
              {t.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {/* Content — ALL tabs always mounted, toggled with display */}
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>

          <div style={tabStyle('OVERVIEW')}>
            <OverviewTab tacticList={tacticList || []} memSummary={memSummary} avSummary={avSummary} vulnSummary={vulnSummary} />
          </div>

          <div style={tabStyle('ARTIFACT_ANALYSIS')}>
            <ArtifactAnalysisTab
              assetId={assetId}
              assetName={assetName}
              tacticList={tacticList || []}
              caseName={caseName}
              onCollectionStarted={setProgressLabel}
              collab={collab}
              analysisMode={analysisMode}
              assetIp={assetIp}
            />
          </div>

          <div style={tabStyle('MEMORY_ANALYSIS')}>
            <MemoryAnalysisTab
              assetId={assetId}
              collab={collab}
              analysisMode={analysisMode}
              onSummaryUpdate={(type, data) => {
                if (type === 'memory') setMemSummary(data);
                else if (type === 'av') setAvSummary(data);
              }}
            />
          </div>

          <div style={tabStyle('KNOWN_MALWARE_SIGNATURES')}>
            <MalwareSignaturesTab
              assetId={assetId}
              collab={collab}
              analysisMode={analysisMode}
              onSummaryUpdate={(type, data) => {
                if (type === 'memory') setMemSummary(data);
                else if (type === 'av') setAvSummary(data);
              }}
            />
          </div>

          <div style={tabStyle('VULN_SCAN')}>
            <VulnScanTab
              assetId={assetId}
              analysisMode={analysisMode}
              collab={collab}
              onScanComplete={setVulnSummary}
            />
          </div>

          <div style={tabStyle('REPORT')}>
            <ReportTab caseName={caseName} assetId={assetId} />
          </div>

        </div>
      </div>
    </div>
  );
};

export default EvidenceWindow;

