import React, { useState, useEffect, useMemo } from 'react';
import InvestigationGallery from './InvestigationGallery';
import CaseDetail from './CaseDetail'; 

export default function InvestigationWorkspace({ activeNodes, activeLinks, updateNodeData }) {
  const [mitreData, setMitreData] = useState([]);
  const [cases, setCases] = useState([]);
  const [selectedCase, setSelectedCase] = useState(null);
  const [status, setStatus] = useState("INITIALIZING_UPLINK...");

  const isConnected = status === "CONNECTED_STABLE";
  const API_BASE = 'https://10.11.110.60:8000/api/mitre';

  // AUTH HEADER HELPER
  const getAuthHeaders = () => ({
    "Authorization": `Bearer ${localStorage.getItem('orca_token')}`,
    "Content-Type": "application/json"
  });

  // --- INITIAL DATA SYNC ---
  useEffect(() => {
    const loadData = async () => {
      try {
        const headers = getAuthHeaders();
        const [mitreRes, casesRes] = await Promise.all([
          fetch(`${API_BASE}/geopolitical/groups`, { headers }),
          fetch(`${API_BASE}/cases`, { headers })
        ]);
        
        if (!mitreRes.ok || !casesRes.ok) throw new Error("DATA_SYNC_FAILED");
        
        setMitreData(await mitreRes.json());
        setCases(await casesRes.json()); 
        setStatus("CONNECTED_STABLE");
      } catch (err) {
        setStatus(`OFFLINE: ${err.message}`);
      }
    };
    loadData();
  }, []);

  // --- PURPLE_STATUS_LOGIC (LANDMARK MATCHING) ---
  const enrichedNodes = useMemo(() => {
    if (!selectedCase || !selectedCase.assets) return activeNodes;

    // Flatten all detected T-codes across every asset assigned to this investigation
    const detectedTCodes = new Set(
      selectedCase.assets
        .filter(a => a.found_t_codes)
        .flatMap(a => a.found_t_codes.split(',').map(code => code.trim()))
    );

    // Map workspace nodes to their 'DETECTED' status based on KAPE hits
    return activeNodes.map(node => {
      const nodeCode = node.t_code || node.hostname || node.id;
      const isHit = detectedTCodes.has(nodeCode);
      
      return {
        ...node,
        isDetected: isHit,
        status: isHit ? 'DETECTED' : (node.status || 'READY')
      };
    });
  }, [activeNodes, selectedCase]);

  // --- DRILL DOWN INTO CASE ---
  const handleSelectCase = async (caseObj) => {
    // Standardize case name reference
    const caseName = caseObj.case_name || caseObj.name;
    setStatus(`FETCHING_ASSETS: ${caseName}`);
    
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/assets`, {
        headers: getAuthHeaders()
      });
      const assetData = res.ok ? await res.json() : [];
      
      // Update local case object with fresh asset data including found_t_codes
      setSelectedCase({ ...caseObj, assets: assetData });
      setStatus("CONNECTED_STABLE");
    } catch (err) {
      setSelectedCase({ ...caseObj, assets: [] });
      setStatus("CONNECTED_STABLE");
    }
  };

  const handleAddCase = async (newCase) => {
    // Optimistic UI update
    setCases(prev => [...prev, newCase]);
    try {
      await fetch(`${API_BASE}/cases`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(newCase),
      });
    } catch (err) { console.error("DB_COMMIT_ERROR:", err); }
  };

  const handleDeleteCase = async (caseName) => {
    if (!window.confirm(`TERMINATE_INVESTIGATION: ${caseName}?`)) return;
    setCases(prev => prev.filter(c => (c.case_name || c.name) !== caseName));
    try {
      await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}`, { 
        method: 'DELETE',
        headers: getAuthHeaders()
      });
    } catch (err) { console.error("DB_DELETE_ERROR:", err); }
  };

  return (
    <div style={{ width: '100%', height: '100%', minHeight: '100vh', background: '#000' }}>
      <div style={{ 
        background: isConnected ? 'rgba(0, 255, 65, 0.05)' : 'rgba(255, 68, 68, 0.05)', 
        color: isConnected ? '#00ff41' : '#ff4444', 
        padding: '12px 40px', fontSize: '11px', fontFamily: 'monospace',
        borderBottom: `1px solid ${isConnected ? '#00ff41' : '#ff4444'}`,
        display: 'flex', justifyContent: 'space-between',
        position: 'sticky', top: 0, zIndex: 100
      }}>
        <span>[SYSTEM_LINK]: {status}</span>
        <span>{selectedCase ? `LOCATION: /${selectedCase.case_name || selectedCase.name}` : `ACTIVE_CASES: ${cases.length}`}</span>
      </div>

      <div>
        {selectedCase ? (
          <CaseDetail 
            caseData={selectedCase} 
            onBack={() => setSelectedCase(null)} 
            onRefresh={() => handleSelectCase(selectedCase)}
            activeNodes={enrichedNodes} // Passing the "Purple" status nodes
            activeLinks={activeLinks}
            updateNodeData={updateNodeData}
          />
        ) : (
          <InvestigationGallery 
            cases={cases} 
            mitreData={mitreData} 
            onSelectCase={handleSelectCase}
            onAddCase={handleAddCase}
            onDeleteCase={handleDeleteCase}
          />
        )}
      </div>
    </div>
  );
}