import React, { useState, useEffect } from 'react';
import NetworkMap from './NetworkMap';
import AssetActionTab from './AssetActionTab';
import EvidenceWindow from './EvidenceWindow';
import CollabNotificationTray from './CollabNotificationTray';
import { useCollaboration } from './useCollaboration';

export default function CaseDetail({ caseData, onBack, onRefresh }) {
  const [activeTab, setActiveTab]         = useState('OVERVIEW');
  const [notes, setNotes]                 = useState([]);
  const [newNote, setNewNote]             = useState('');
  const [noteType, setNoteType]           = useState('NOTE'); // 'NOTE' | 'BLUF'
  const [showAssetModal, setShowAssetModal] = useState(false);
  const [editingConfig, setEditingConfig] = useState(null);
  const [configBuffer, setConfigBuffer]   = useState('');
  const [completion, setCompletion]       = useState(null);

  const [investigatingAssetId, setInvestigatingAssetId] = useState(null);
  const [isEvidenceOpen, setIsEvidenceOpen]             = useState(false);
  const [evidenceTacticList, setEvidenceTacticList]     = useState([]);
  const [isFetchingTactics, setIsFetchingTactics]       = useState(false);

  const [activeNodes, setActiveNodes]   = useState([]);
  const [activeLinks, setActiveLinks]   = useState([]);
  const [isMaximized, setIsMaximized]   = useState(false);
  const [saveStatus, setSaveStatus]     = useState('READY');
  const [linkForm, setLinkForm]         = useState(null);
  const [assetModes, setAssetModes]     = useState({});
  const [mountSessions, setMountSessions] = useState({});
  const [mountExpanded, setMountExpanded] = useState({});
  const [mountForms, setMountForms]     = useState({});
  const [mountLoading, setMountLoading] = useState({});
  const [pkgExpanded, setPkgExpanded]   = useState({});
  const [pkgData, setPkgData]           = useState({});
  const [pkgGenerating, setPkgGenerating] = useState({});
  const [pkgProgress, setPkgProgress]   = useState({});
  const [pkgCopied, setPkgCopied]       = useState({}); // { [asset_id]: bool } — tracks one-liner copy state

  const API_BASE = 'https://10.11.110.60:8000/api/mitre';

  const getAuthHeaders = () => ({
    'Authorization': `Bearer ${localStorage.getItem('orca_token')}`,
    'Content-Type': 'application/json',
  });

  const getCurrentUserRole = () => {
    try {
      const token = localStorage.getItem('orca_token');
      if (!token) return 'analyst';
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.role || 'analyst';
    } catch { return 'analyst'; }
  };
  const userRole = getCurrentUserRole();

  const collab = useCollaboration();

  const currentAsset = caseData.assets?.find(a => String(a.id) === String(investigatingAssetId));
  const caseName     = caseData.name || caseData.case_name;

  useEffect(() => {
    if (caseData.assets) {
      setAssetModes(prev => {
        const next = { ...prev };
        caseData.assets.forEach(a => {
          if (!next[String(a.id)]) next[String(a.id)] = a.analysis_mode || 'UNKNOWN';
        });
        return next;
      });
    }
  }, [caseData.assets]);

  const loadCompletion = async () => {
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/completion`, { headers: getAuthHeaders() });
      if (res.ok) setCompletion(await res.json());
    } catch {}
  };

  useEffect(() => { loadCompletion(); }, [caseName]);

  const handleInvestigateAsset = (id) => {
    setIsEvidenceOpen(false);
    setInvestigatingAssetId(null);
    setTimeout(() => setInvestigatingAssetId(id), 0);
  };

  useEffect(() => {
    if (!investigatingAssetId) return;
    const identifier = caseName || caseData.country;
    if (!identifier) { setEvidenceTacticList([]); setIsEvidenceOpen(true); return; }

    setIsFetchingTactics(true);
    fetch(`${API_BASE}/threat-profile/${encodeURIComponent(identifier)}?asset_id=${investigatingAssetId}`, { headers: getAuthHeaders() })
      .then(r => r.json())
      .then(data => { setEvidenceTacticList(Array.isArray(data) ? data : []); setIsEvidenceOpen(true); })
      .catch(() => { setEvidenceTacticList([]); setIsEvidenceOpen(true); })
      .finally(() => setIsFetchingTactics(false));
  }, [investigatingAssetId]);

  const handleCloseEvidence = () => {
    if (investigatingAssetId) {
      collab.releaseTechnique(investigatingAssetId, '__ALL__').catch(() => {});
    }
    setIsEvidenceOpen(false);
    setInvestigatingAssetId(null);
    setEvidenceTacticList([]);
    loadCompletion();
  };

  useEffect(() => {
    const rawMap = caseData.mapData || caseData.map_data;
    if (rawMap) {
      try {
        const parsed = typeof rawMap === 'string' ? JSON.parse(rawMap) : rawMap;
        if (parsed?.nodes) { setActiveNodes(parsed.nodes || []); setActiveLinks(parsed.links || []); }
        else if (Array.isArray(parsed)) { setActiveNodes(parsed); setActiveLinks([]); }
      } catch (e) { console.error('MAP_REHYDRATION_ERROR:', e); }
    }
  }, [caseData]);

  const saveMapLayout = async () => {
    setSaveStatus('SAVING...');
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/map-sync`, {
        method: 'POST', headers: getAuthHeaders(),
        body: JSON.stringify({ nodes: activeNodes || [], links: activeLinks || [] }),
      });
      if (res.ok) { setSaveStatus('SAVED_SUCCESSFULLY'); setTimeout(() => setSaveStatus('READY'), 2000); }
      else setSaveStatus('ERROR');
    } catch { setSaveStatus('ERROR'); }
  };

  useEffect(() => {
    fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/notes/v2`, { headers: getAuthHeaders() })
      .then(r => r.json()).then(setNotes).catch(() => setNotes([]));
  }, [caseName]);

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/notes/v2`, {
      method: 'POST', headers: getAuthHeaders(),
      body: JSON.stringify({ text: newNote, note_type: noteType }),
    });
    if (res.ok) {
      const d = await res.json();
      setNotes(prev => [...prev, {
        text: newNote, time: d.time, type: noteType, author_initials: d.author_initials,
      }]);
      setNewNote('');
    }
  };

  const [assetForm, setAssetForm] = useState({
    hostname: '', ip: '', subnet: '255.255.255.0', gateway: '', mac: '',
    type: 'Workstation', os: 'Windows', version: '10', formFactor: 'Laptop',
    assetNotes: '', analysisMode: 'UNKNOWN',
  });

  const handleRegisterAsset = async () => {
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/assets`, {
        method: 'POST', headers: getAuthHeaders(), body: JSON.stringify(assetForm),
      });
      if (res.ok) {
        if (assetForm.analysisMode !== 'UNKNOWN') {
          const assetsRes = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/assets`, { headers: getAuthHeaders() });
          const assets = await assetsRes.json();
          const newAsset = assets.find(a => a.hostname === assetForm.hostname);
          if (newAsset) {
            await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/assets/${newAsset.id}/mode`, {
              method: 'PATCH', headers: getAuthHeaders(),
              body: JSON.stringify({ analysis_mode: assetForm.analysisMode }),
            });
            setAssetModes(prev => ({ ...prev, [String(newAsset.id)]: assetForm.analysisMode }));
          }
        }
        setShowAssetModal(false);
        if (onRefresh) onRefresh();
      }
    } catch (err) { console.error(err); }
  };

  const loadMountSessions = async (assetId) => {
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/assets/${assetId}/mounts`, { headers: getAuthHeaders() });
      if (r.ok) {
        const data = await r.json();
        setMountSessions(prev => ({ ...prev, [String(assetId)]: data }));
      }
    } catch {}
  };

  const handleMount = async (assetId) => {
    const form = mountForms[String(assetId)] || {};
    if (!form.imagePath) return;
    setMountLoading(prev => ({ ...prev, [String(assetId)]: true }));
    try {
      const r = await fetch('https://10.11.110.60:8000/api/assets/mount', {
        method: 'POST', headers: getAuthHeaders(),
        body: JSON.stringify({
          asset_id: assetId, image_path: form.imagePath,
          drive_letter: form.driveLetter || null, provider: form.provider || 'auto', readonly: true,
        }),
      });
      const d = await r.json();
      if (r.ok) {
        setAssetModes(prev => ({ ...prev, [String(assetId)]: 'DEAD_DISK_LOCAL' }));
        if (d.drive_letter) {
          setMountForms(prev => ({ ...prev, [String(assetId)]: { ...form, driveLetter: d.drive_letter } }));
        }
        await loadMountSessions(assetId);
        if (onRefresh) onRefresh();
      } else {
        alert('MOUNT_ERROR: ' + (d.detail || 'Unknown error'));
      }
    } catch (e) { alert('MOUNT_ERROR: ' + e.message); }
    finally { setMountLoading(prev => ({ ...prev, [String(assetId)]: false })); }
  };

  const handleDismount = async (assetId, mountId) => {
    setMountLoading(prev => ({ ...prev, [String(assetId)]: true }));
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/assets/dismount?asset_id=${assetId}&mount_id=${mountId}`, {
        method: 'POST', headers: getAuthHeaders(),
      });
      const d = await r.json();
      if (r.ok) { await loadMountSessions(assetId); }
      else { alert('DISMOUNT_ERROR: ' + (d.detail || 'Unknown error')); }
    } catch (e) { alert('DISMOUNT_ERROR: ' + e.message); }
    finally { setMountLoading(prev => ({ ...prev, [String(assetId)]: false })); }
  };

  // ── Remote package helpers ──────────────────────────────────────────────────

  const fetchPkgProgress = async (assetId) => {
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/ingest/remote/${assetId}/progress`, { headers: getAuthHeaders() });
      if (r.status === 401) return;
      if (r.ok) { const data = await r.json(); setPkgProgress(prev => ({ ...prev, [String(assetId)]: data })); }
    } catch {}
  };

  const handleGeneratePackage = async (assetId) => {
    setPkgGenerating(prev => ({ ...prev, [String(assetId)]: true }));
    try {
      const r = await fetch(`https://10.11.110.60:8000/api/assets/${assetId}/package`, {
        method: 'POST', headers: getAuthHeaders(),
      });
      if (!r.ok) { const e = await r.json(); alert(`PACKAGE_ERROR: ${e.detail || r.statusText}`); return; }
      const data = await r.json();
      setPkgData(prev => ({ ...prev, [String(assetId)]: data }));
      const pollId = setInterval(() => fetchPkgProgress(assetId), 5000);
      setTimeout(() => clearInterval(pollId), 24 * 60 * 60 * 1000);
    } catch (e) { alert(`PACKAGE_ERROR: ${e.message}`); }
    finally { setPkgGenerating(prev => ({ ...prev, [String(assetId)]: false })); }
  };

  const handleRevokePackage = async (assetId) => {
    const pkg = pkgData[String(assetId)];
    if (!pkg?.token) return;
    if (!window.confirm('Revoke this package token? The agent cannot submit further results.')) return;
    try {
      await fetch(`https://10.11.110.60:8000/api/packages/${pkg.token}`, {
        method: 'DELETE', headers: getAuthHeaders(),
      });
      setPkgData(prev => { const n = { ...prev }; delete n[String(assetId)]; return n; });
    } catch (e) { alert(`REVOKE_ERROR: ${e.message}`); }
  };

  // Copy the one-liner (bootstrap command) to clipboard
  const handleCopyOneliner = (assetId) => {
    const pkg = pkgData[String(assetId)];
    if (!pkg?.oneliner) return;
    navigator.clipboard.writeText(pkg.oneliner).then(() => {
      setPkgCopied(prev => ({ ...prev, [String(assetId)]: true }));
      setTimeout(() => setPkgCopied(prev => ({ ...prev, [String(assetId)]: false })), 2000);
    });
  };

  const pkgExpiresIn = (isoStr) => {
    if (!isoStr) return '';
    const diff = new Date(isoStr + 'Z') - new Date();
    if (diff <= 0) return 'EXPIRED';
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    return `${h}h ${m}m`;
  };

  const deployToMap = (asset) => {
    if (!activeNodes.find(n => n.hostname === asset.hostname)) {
      setActiveNodes([...activeNodes, {
        hostname: asset.hostname, ip: asset.ip, mac: asset.mac_address,
        os: asset.os, version: asset.os_version, type: asset.form_factor,
        config: '', nodeNote: '', x: 400, y: 250,
      }]);
    }
  };

  const handleInitiateLink = (source, target) => {
    setLinkForm({
      id: `link-${Date.now()}`, source: source.hostname, target: target.hostname,
      link_type: 'WIRED', interface_src: '', interface_dst: '',
      ip_src: source.ip || '', ip_dst: target.ip || '', vlan: '1',
    });
  };

  const handleConfirmLink = () => { setActiveLinks(prev => [...prev, linkForm]); setLinkForm(null); };

  const handleDeleteNode = (node) => {
    if (window.confirm(`REMOVE ${node.hostname} FROM WORKSPACE?`)) {
      setActiveNodes(prev => prev.filter(n => n.hostname !== node.hostname));
      setActiveLinks(prev => prev.filter(l => l.source !== node.hostname && l.target !== node.hostname));
    }
  };

  const addInfrastructure = (type) => {
    const id = Math.floor(Math.random() * 999);
    setActiveNodes([...activeNodes, { hostname: `${type}_${id}`, ip: '0.0.0.0', mac: 'AUTO_GEN', type, os: 'Firmware_v1.0', config: '', nodeNote: '', x: 450, y: 250 }]);
  };

  const handleUpdateNode = (node, action, data) => {
    if (action === 'COORD_UPDATE') { setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, x: data.x, y: data.y } : n)); return; }
    if (action === 'CONFIG') {
      if (['SWITCH', 'ROUTER', 'FIREWALL'].includes(node.type?.toUpperCase())) { setEditingConfig(node); setConfigBuffer(node.config || ''); }
      else { const v = prompt(`ENTER SYSTEM NOTES FOR ${node.hostname}:`, node.nodeNote || ''); if (v !== null) setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, nodeNote: v } : n)); }
      return;
    }
    const field = { 'IP': 'ip', 'NOTE': 'nodeNote' }[action];
    if (field) { const v = prompt(`ENTER ${action} FOR ${node.hostname}:`, node[field] || ''); if (v !== null) setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, [field]: v } : n)); }
  };

  const pct    = completion?.aggregate_completion_pct || 0;
  const pctCol = pct >= 80 ? '#00ff41' : pct >= 40 ? '#ffaa00' : '#ff4444';

  return (
    <div style={{ animation: 'fadeIn 0.3s ease', color: '#fff', fontFamily: 'monospace' }}>

      <CollabNotificationTray
        notifications={collab.notifications}
        dismissNotification={collab.dismissNotification}
        connected={collab.connected}
      />

      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#00ff41', cursor: 'pointer', fontSize: '10px', marginBottom: '20px' }}>
        [ BACK_TO_GALLERY ]
      </button>

      <div style={{ marginBottom: '20px' }}>
        <h1 style={{ fontSize: '42px', fontWeight: 900, margin: '0' }}>{caseName}</h1>
        <div style={{ color: '#444', fontSize: '10px', marginTop: '5px' }}>CASE_REF: {caseData.country?.toUpperCase()}_INTEL_PRIORITY_1</div>

        {completion && (
          <div style={{ marginTop: 12, maxWidth: 480 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ color: '#444', fontSize: 9, letterSpacing: 1 }}>INVESTIGATION_COMPLETION</span>
              <span style={{ color: pctCol, fontSize: 11, fontWeight: 'bold' }}>{pct}%</span>
            </div>
            <div style={{ background: '#111', height: 4 }}>
              <div style={{ background: pctCol, height: '100%', width: `${pct}%`, transition: 'width 0.6s ease' }} />
            </div>
            <div style={{ display: 'flex', gap: 16, marginTop: 6 }}>
              {[
                ['TOTAL_TECHNIQUES', completion.total_techniques, '#444'],
                ['CLOSED', completion.assets?.reduce((s, a) => s + (a.closed || 0), 0), '#00ff41'],
                ['PENDING_REVIEW', completion.assets?.reduce((s, a) => s + (a.pending_review || 0), 0), '#ffaa00'],
                ['IN_PROGRESS', completion.assets?.reduce((s, a) => s + (a.in_progress || 0), 0), '#9b59ff'],
              ].map(([label, val, col]) => (
                <div key={label} style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                  <span style={{ color: '#333', fontSize: 8, letterSpacing: 1 }}>{label}</span>
                  <span style={{ color: col, fontSize: 13, fontWeight: 'bold' }}>{val ?? 0}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: '30px', marginBottom: '30px', borderBottom: '1px solid #111' }}>
        {['OVERVIEW', 'ASSETS', 'NETWORK_MAP'].map(tab => (
          <div key={tab} onClick={() => setActiveTab(tab)} style={{
            fontSize: '11px', letterSpacing: '2px', cursor: 'pointer',
            color: activeTab === tab ? '#00ff41' : '#444',
            borderBottom: activeTab === tab ? '2px solid #00ff41' : '2px solid transparent',
            paddingBottom: '10px',
          }}>{tab}</div>
        ))}
      </div>

      <div style={{ minHeight: '500px' }}>

        {/* ── OVERVIEW TAB ── */}
        {activeTab === 'OVERVIEW' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '40px' }}>
            <div style={{ animation: 'fadeIn 0.5s ease' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '40px' }}>
                <StatTile label="LEAD" val={caseData.missionLead} />
                <StatTile label="TEAM" val={caseData.teamName} />
                <StatTile label="UNIT" val={caseData.support} />
                <StatTile label="OPS"  val={caseData.personnel} />
              </div>

              {completion?.assets?.length > 0 && (
                <div style={{ marginBottom: 30 }}>
                  <div style={{ color: '#444', fontSize: '9px', marginBottom: 10, letterSpacing: 1 }}>ASSET_INVESTIGATION_STATUS</div>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 10 }}>
                    <thead>
                      <tr style={{ color: '#333', borderBottom: '1px solid #111' }}>
                        {['HOSTNAME', 'CLOSED', 'PENDING', 'IN_PROGRESS', 'MALICIOUS', 'CLEAN', 'PCT'].map(h => (
                          <th key={h} style={{ padding: '5px 8px', textAlign: 'left', fontWeight: 'normal' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {completion.assets.map((a, i) => (
                        <tr key={i} style={{ borderBottom: '1px solid #0a0a0a' }}>
                          <td style={{ padding: '6px 8px', color: '#00ff41' }}>{a.hostname}</td>
                          <td style={{ padding: '6px 8px', color: '#00ff41' }}>{a.closed}</td>
                          <td style={{ padding: '6px 8px', color: '#ffaa00' }}>{a.pending_review}</td>
                          <td style={{ padding: '6px 8px', color: '#9b59ff' }}>{a.in_progress}</td>
                          <td style={{ padding: '6px 8px', color: '#ff4444' }}>{a.malicious}</td>
                          <td style={{ padding: '6px 8px', color: '#00ff41' }}>{a.clean}</td>
                          <td style={{ padding: '6px 8px', color: a.completion_pct >= 80 ? '#00ff41' : a.completion_pct >= 40 ? '#ffaa00' : '#ff4444' }}>
                            {a.completion_pct}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div style={{ borderTop: '1px solid #111', paddingTop: '30px' }}>
                <div style={{ color: '#444', fontSize: '10px', marginBottom: '15px' }}>MISSION_TIMELINE_LOG</div>
                <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
                  <input
                    value={newNote} onChange={e => setNewNote(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleAddNote()}
                    placeholder="APPEND_LOG_DATA..." style={InputStyle}
                  />
                  {(userRole === 'admin' || userRole === 'lead') && (
                    <button
                      onClick={() => setNoteType(t => t === 'NOTE' ? 'BLUF' : 'NOTE')}
                      style={{ ...BtnStyle, background: noteType === 'BLUF' ? '#00ff41' : 'transparent',
                        color: noteType === 'BLUF' ? '#000' : '#444',
                        border: '1px solid #222', padding: '6px 12px', fontSize: 9 }}
                    >
                      {noteType === 'BLUF' ? '★ BLUF' : '☆ BLUF'}
                    </button>
                  )}
                  <button onClick={handleAddNote} style={BtnStyle}>COMMIT</button>
                </div>
                <div style={{ maxHeight: '300px', overflowY: 'auto', background: 'rgba(0,0,0,0.2)', padding: '15px', border: '1px solid #0a0a0a' }}>
                  {notes.map((n, i) => (
                    <div key={i} style={{
                      fontSize: '11px', marginBottom: '12px',
                      borderLeft: `2px solid ${n.type === 'BLUF' ? '#00ff41' : '#333'}`,
                      paddingLeft: '15px',
                      background: n.type === 'BLUF' ? 'rgba(0,255,65,0.03)' : 'transparent',
                    }}>
                      <span style={{ color: '#00ff41', marginRight: '8px' }}>[{n.time}]</span>
                      {n.author_initials && (
                        <span style={{
                          color: n.type === 'BLUF' ? '#000' : '#444',
                          background: n.type === 'BLUF' ? '#00ff41' : '#1a1a1a',
                          fontSize: 9, padding: '1px 5px', marginRight: 8,
                        }}>
                          {n.author_initials}
                        </span>
                      )}
                      {n.type === 'BLUF' && (
                        <span style={{ color: '#00ff41', fontSize: 9, marginRight: 6 }}>★ BLUF</span>
                      )}
                      <span style={{ color: n.type === 'BLUF' ? '#00ff41' : '#aaa' }}>{n.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <aside style={{ borderLeft: '1px solid #111', paddingLeft: '40px' }}>
              <div style={{ color: '#444', fontSize: '9px', marginBottom: '15px' }}>GEOPOLITICAL_CONTEXT</div>
              <div style={{ fontSize: '12px', color: '#888', lineHeight: '1.6' }}>
                Operational environment confirmed as {caseData.country}. Priority assessment is high.
              </div>
            </aside>
          </div>
        )}

        {/* ── ASSETS TAB ── */}
        {activeTab === 'ASSETS' && (
          <div style={{ animation: 'fadeIn 0.4s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '11px', color: '#444' }}>SYSTEM_INVENTORY</h3>
              <button onClick={() => setShowAssetModal(true)} style={BtnStyle}>+ REGISTER_NEW_ASSET</button>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px' }}>
              <thead style={{ color: '#333', textAlign: 'left', borderBottom: '1px solid #111' }}>
                <tr>
                  <th style={{ padding: '10px' }}>HOSTNAME</th>
                  <th>NETWORK_ADDRESSING</th>
                  <th>OS_SPECIFICATION</th>
                  <th>FORM_FACTOR</th>
                  <th>ANALYSIS_MODE</th>
                  <th style={{ width: '240px', textAlign: 'left', paddingLeft: '20px' }}>ACTION</th>
                </tr>
              </thead>
              <tbody>
                {caseData.assets?.map((a, i) => {
                  const aId = String(a.id);
                  const modeCol = {
                    LIVE_REMOTE: '#ffaa00', DEAD_DISK_LOCAL: '#9b59ff',
                    DEAD_DISK_REMOTE: '#9b59ff', UNKNOWN: '#333',
                  }[a.analysis_mode] || '#333';
                  const sessions   = mountSessions[aId] || [];
                  const activeMount = sessions.find(s => s.status === 'MOUNTED');
                  const isExpanded = mountExpanded[aId];
                  const form       = mountForms[aId] || {};
                  const loading    = mountLoading[aId];

                  return (
                    <React.Fragment key={i}>
                      <tr style={{ borderBottom: isExpanded ? 'none' : '1px solid #0a0a0a' }}>
                        <td style={{ padding: '15px 10px', color: '#00ff41', fontWeight: 'bold' }}>{a.hostname}</td>
                        <td style={{ color: '#888' }}>IP: {a.ip}<br /><span style={{ fontSize: '9px', color: '#333' }}>MAC: {a.mac_address}</span></td>
                        <td>{a.os} {a.os_version}</td>
                        <td>{a.form_factor}</td>
                        <td>
                          <select
                            value={assetModes[aId] || a.analysis_mode || 'UNKNOWN'}
                            onChange={async e => {
                              const mode = e.target.value;
                              setAssetModes(prev => ({ ...prev, [aId]: mode }));
                              await fetch(`${API_BASE}/cases/${encodeURIComponent(caseName)}/assets/${a.id}/mode`, {
                                method: 'PATCH', headers: getAuthHeaders(),
                                body: JSON.stringify({ analysis_mode: mode }),
                              });
                              if (onRefresh) onRefresh();
                            }}
                            style={{
                              background: '#0a0a0a', border: '1px solid #1a1a1a',
                              color: modeCol, fontFamily: 'monospace', fontSize: 9,
                              letterSpacing: 1, padding: '3px 6px', cursor: 'pointer', outline: 'none',
                            }}
                          >
                            {['UNKNOWN','LIVE_REMOTE','DEAD_DISK_LOCAL','DEAD_DISK_REMOTE'].map(m => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        </td>
                        <td style={{ width: '240px', padding: '15px 0 15px 20px' }}>
                          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                            {isFetchingTactics && String(investigatingAssetId) === String(a.id) ? (
                              <span style={{ color: '#444', fontSize: '10px' }}>LOADING...</span>
                            ) : (
                              <AssetActionTab
                                assetId={a.id}
                                assetName={a.hostname}
                                setInvestigatingAsset={setInvestigatingAssetId}
                              />
                            )}
                            <button
                              onClick={() => {
                                setMountExpanded(prev => ({ ...prev, [aId]: !prev[aId] }));
                                if (!mountSessions[aId]) loadMountSessions(a.id);
                              }}
                              style={{
                                background: activeMount ? 'rgba(155,89,255,0.15)' : '#0a0a0a',
                                border: `1px solid ${activeMount ? '#9b59ff' : '#1a1a1a'}`,
                                color: activeMount ? '#9b59ff' : '#444',
                                fontFamily: 'monospace', fontSize: 9, padding: '4px 8px',
                                cursor: 'pointer', letterSpacing: 1,
                              }}
                            >
                              {activeMount ? '⏏ MOUNTED' : '⏏ MOUNT'}
                            </button>
                            <button
                              onClick={() => {
                                setPkgExpanded(prev => ({ ...prev, [aId]: !prev[aId] }));
                                fetchPkgProgress(a.id);
                              }}
                              style={{
                                background: pkgData[aId] ? 'rgba(0,191,255,0.1)' : '#0a0a0a',
                                border: `1px solid ${pkgData[aId] ? '#00bfff' : '#1a1a1a'}`,
                                color: pkgData[aId] ? '#00bfff' : '#444',
                                fontFamily: 'monospace', fontSize: 9, padding: '4px 8px',
                                cursor: 'pointer', letterSpacing: 1,
                              }}
                            >
                              ⬇ PKG
                            </button>
                          </div>
                        </td>
                      </tr>

                      {/* ── Inline mount panel ── */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={6} style={{ padding: '0 0 12px 0', borderBottom: '1px solid #0a0a0a' }}>
                            <div style={{
                              background: '#060606', border: '1px solid #111',
                              margin: '0 10px', padding: '12px 16px', fontFamily: 'monospace', fontSize: 10,
                            }}>
                              <div style={{ color: '#444', fontSize: 9, letterSpacing: 1, marginBottom: 10 }}>
                                IMAGE_MOUNT_CONTROLLER — {a.hostname.toUpperCase()}
                              </div>
                              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap', marginBottom: 10 }}>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 2, minWidth: 250 }}>
                                  <span style={{ color: '#333', fontSize: 9 }}>IMAGE_PATH</span>
                                  <input
                                    value={form.imagePath || ''}
                                    onChange={e => setMountForms(prev => ({ ...prev, [aId]: { ...form, imagePath: e.target.value } }))}
                                    placeholder="C:\images\suspect.E01"
                                    style={{ background: '#000', border: '1px solid #1a1a1a', color: '#00ff41', fontFamily: 'monospace', fontSize: 10, padding: '5px 8px', outline: 'none' }}
                                  />
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                                  <span style={{ color: '#333', fontSize: 9 }}>DRIVE_LETTER</span>
                                  <select
                                    value={form.driveLetter || ''}
                                    onChange={e => setMountForms(prev => ({ ...prev, [aId]: { ...form, driveLetter: e.target.value } }))}
                                    style={{ background: '#000', border: '1px solid #1a1a1a', color: '#00ff41', fontFamily: 'monospace', fontSize: 10, padding: '5px 6px', outline: 'none' }}
                                  >
                                    <option value="">AUTO</option>
                                    {'ABDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(l => (
                                      <option key={l} value={l}>{l}:</option>
                                    ))}
                                  </select>
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                                  <span style={{ color: '#333', fontSize: 9 }}>PROVIDER</span>
                                  <select
                                    value={form.provider || 'auto'}
                                    onChange={e => setMountForms(prev => ({ ...prev, [aId]: { ...form, provider: e.target.value } }))}
                                    style={{ background: '#000', border: '1px solid #1a1a1a', color: '#00ff41', fontFamily: 'monospace', fontSize: 10, padding: '5px 6px', outline: 'none' }}
                                  >
                                    {['auto','LibEwf','DiscUtils','LibQcow','None'].map(p => (
                                      <option key={p} value={p}>{p}</option>
                                    ))}
                                  </select>
                                </div>
                                <button
                                  onClick={() => handleMount(a.id)}
                                  disabled={loading || !form.imagePath || !!activeMount}
                                  style={{
                                    background: activeMount ? '#111' : '#00ff41', color: activeMount ? '#333' : '#000',
                                    border: 'none', fontFamily: 'monospace', fontSize: 9, fontWeight: 'bold',
                                    padding: '7px 14px', cursor: activeMount ? 'not-allowed' : 'pointer',
                                    letterSpacing: 1, opacity: loading ? 0.5 : 1,
                                  }}
                                >
                                  {loading ? 'MOUNTING...' : activeMount ? 'ALREADY_MOUNTED' : '[ MOUNT_IMAGE ]'}
                                </button>
                              </div>
                              {activeMount && (
                                <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 10px',
                                  background: 'rgba(155,89,255,0.06)', border: '1px solid #2a1a4a', marginBottom: 8 }}>
                                  <div style={{ display: 'flex', gap: 16 }}>
                                    {[
                                      ['DEVICE', activeMount.device_number],
                                      ['DRIVE', activeMount.drive_letter ? `${activeMount.drive_letter}:` : '—'],
                                      ['PHYSICAL', activeMount.physical_drive],
                                      ['PROVIDER', activeMount.provider],
                                    ].map(([l, v]) => v && (
                                      <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                                        <span style={{ color: '#333', fontSize: 8 }}>{l}</span>
                                        <span style={{ color: '#9b59ff', fontSize: 10 }}>{v}</span>
                                      </div>
                                    ))}
                                  </div>
                                  <button
                                    onClick={() => handleDismount(a.id, activeMount.id)}
                                    disabled={loading}
                                    style={{
                                      marginLeft: 'auto', background: 'transparent',
                                      border: '1px solid #ff4141', color: '#ff4141',
                                      fontFamily: 'monospace', fontSize: 9, padding: '4px 10px', cursor: 'pointer', letterSpacing: 1,
                                    }}
                                  >
                                    {loading ? 'DISMOUNTING...' : '[ DISMOUNT ]'}
                                  </button>
                                </div>
                              )}
                              {sessions.filter(s => s.status === 'DISMOUNTED').length > 0 && (
                                <div style={{ marginTop: 6 }}>
                                  <div style={{ color: '#222', fontSize: 8, letterSpacing: 1, marginBottom: 4 }}>MOUNT_HISTORY</div>
                                  {sessions.filter(s => s.status === 'DISMOUNTED').map((s, idx) => (
                                    <div key={idx} style={{ display: 'flex', gap: 12, fontSize: 9, color: '#333', borderTop: '1px solid #0a0a0a', padding: '4px 0' }}>
                                      <span>{s.image_path}</span>
                                      <span style={{ color: '#222' }}>{s.drive_letter ? `${s.drive_letter}:` : '—'}</span>
                                      <span style={{ color: '#1a1a1a', marginLeft: 'auto' }}>{new Date(s.mounted_at).toLocaleString()}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}

                      {/* ── Inline remote package panel ── */}
                      {pkgExpanded[aId] && (
                        <tr>
                          <td colSpan={6} style={{ padding: '0 0 12px 0', borderBottom: '1px solid #0a0a0a' }}>
                            <div style={{
                              background: '#060606', border: '1px solid #111',
                              margin: '0 10px', padding: '12px 16px', fontFamily: 'monospace', fontSize: 10,
                            }}>
                              {/* Header */}
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                                <span style={{ color: '#333', fontSize: 9, letterSpacing: 1 }}>
                                  REMOTE_PACKAGE_CONTROLLER — {a.hostname.toUpperCase()}
                                </span>
                                {!pkgData[aId] ? (
                                  <button
                                    onClick={() => handleGeneratePackage(a.id)}
                                    disabled={pkgGenerating[aId]}
                                    style={{
                                      background: 'transparent', border: '1px solid #00bfff',
                                      color: '#00bfff', padding: '3px 12px',
                                      fontFamily: 'monospace', fontSize: 10,
                                      cursor: pkgGenerating[aId] ? 'not-allowed' : 'pointer',
                                      opacity: pkgGenerating[aId] ? 0.5 : 1, letterSpacing: 1,
                                    }}
                                  >
                                    {pkgGenerating[aId] ? 'BUILDING...' : '[ GENERATE_PACKAGE ]'}
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleRevokePackage(a.id)}
                                    style={{
                                      background: 'transparent', border: '1px solid #ff4141',
                                      color: '#ff4141', padding: '3px 12px',
                                      fontFamily: 'monospace', fontSize: 9, cursor: 'pointer', letterSpacing: 1,
                                    }}
                                  >
                                    [ REVOKE ]
                                  </button>
                                )}
                              </div>

                              {/* Package ready state */}
                              {pkgData[aId] && (() => {
                                const pkg  = pkgData[aId];
                                const prog = pkgProgress[aId];
                                const total       = prog?.total || 0;
                                const withEvidence = prog?.with_evidence || 0;
                                const noArt       = prog?.no_artifacts || 0;
                                const pending     = prog?.pending || 0;
                                return (
                                  <>
                                    <div style={{ display: 'flex', gap: 16, marginBottom: 10, alignItems: 'center' }}>
                                      <span style={{ color: '#00bfff', fontSize: 10 }}>
                                        ✓ {pkg.technique_count} TECHNIQUES PACKAGED
                                      </span>
                                      <span style={{ color: '#333', fontSize: 9 }}>
                                        EXPIRES {pkgExpiresIn(pkg.expires_at)}
                                      </span>
                                    </div>

                                    {/* One-liner deploy command */}
                                    <div style={{ color: '#333', fontSize: 9, marginBottom: 4, letterSpacing: 1 }}>
                                      DEPLOY_COMMAND — run as admin on target:
                                    </div>
                                    <div style={{
                                      background: '#030303', border: '1px solid #1a1a1a',
                                      padding: '8px 10px', display: 'flex', alignItems: 'center',
                                      gap: 8, marginBottom: 10,
                                    }}>
                                      <span style={{
                                        color: '#00ff41', flex: 1, fontSize: 10,
                                        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                                        fontFamily: 'monospace',
                                      }}>
                                        {pkg.oneliner}
                                      </span>
                                      <button
                                        onClick={() => handleCopyOneliner(a.id)}
                                        style={{
                                          background: pkgCopied[aId] ? '#00ff41' : 'transparent',
                                          border: `1px solid ${pkgCopied[aId] ? '#00ff41' : '#333'}`,
                                          color: pkgCopied[aId] ? '#000' : '#555',
                                          fontFamily: 'monospace', fontSize: 9,
                                          padding: '3px 10px', cursor: 'pointer', flexShrink: 0,
                                          fontWeight: pkgCopied[aId] ? 'bold' : 'normal',
                                          transition: 'all 0.15s',
                                        }}
                                      >
                                        {pkgCopied[aId] ? '✓ COPIED' : 'COPY'}
                                      </button>
                                    </div>

                                    {/* Progress bar */}
                                    {total > 0 && (
                                      <>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9, color: '#444', marginBottom: 3 }}>
                                          <span>COLLECTION PROGRESS</span>
                                          <span>{withEvidence + noArt}/{total} PROCESSED</span>
                                        </div>
                                        <div style={{ display: 'flex', height: 5, borderRadius: 2, overflow: 'hidden', background: '#111', marginBottom: 4 }}>
                                          <div style={{ width: `${(withEvidence/total)*100}%`, background: '#00ff41', transition: 'width 0.4s' }} />
                                          <div style={{ width: `${(noArt/total)*100}%`,        background: '#333',    transition: 'width 0.4s' }} />
                                          <div style={{ width: `${(pending/total)*100}%`,      background: '#111',    transition: 'width 0.4s' }} />
                                        </div>
                                        <div style={{ display: 'flex', gap: 12, fontSize: 8, color: '#333' }}>
                                          <span style={{ color: '#00ff41' }}>■ EVIDENCE {withEvidence}</span>
                                          <span style={{ color: '#444' }}>■ NO_ARTIFACTS {noArt}</span>
                                          <span>■ PENDING {pending}</span>
                                        </div>
                                        {prog?.package_info?.completed_at && (
                                          <div style={{ color: '#00ff41', fontSize: 9, marginTop: 6 }}>
                                            ✓ COLLECTION COMPLETE — {new Date(prog.package_info.completed_at + 'Z').toLocaleString()}
                                          </div>
                                        )}
                                      </>
                                    )}
                                  </>
                                );
                              })()}

                              {/* No package yet */}
                              {!pkgData[aId] && !pkgGenerating[aId] && (
                                <div style={{ color: '#333', fontSize: 9, lineHeight: 1.8 }}>
                                  Generates a self-contained collection package.<br />
                                  Copy the one-line deploy command and run it as admin on the target.<br />
                                  The agent collects artifacts, ships results back, and self-deletes.<br />
                                  Token is scoped to this asset, auto-revokes on completion,<br />
                                  and expires in 24 hours.
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* ── NETWORK MAP TAB ── */}
        {activeTab === 'NETWORK_MAP' && (
          <div style={{
            position: isMaximized ? 'fixed' : 'relative', top: isMaximized ? 0 : 'auto', left: isMaximized ? 0 : 'auto',
            width: isMaximized ? '100vw' : '100%', height: isMaximized ? '100vh' : '650px',
            zIndex: isMaximized ? 2000 : 1, display: 'grid',
            gridTemplateColumns: isMaximized ? '1fr 350px' : '1fr 300px',
            background: '#111', border: '1px solid #111',
          }}>
            <div style={{ background: '#000', overflow: 'hidden', position: 'relative' }}>
              <NetworkMap
                activeNodes={activeNodes} activeLinks={activeLinks}
                updateNodeData={handleUpdateNode} onInitiateLink={handleInitiateLink}
                onDeleteNode={handleDeleteNode} onInvestigateAsset={handleInvestigateAsset}
                investigatingAssetId={investigatingAssetId} isFetchingTactics={isFetchingTactics}
                techniqueStatuses={collab.techniqueStatuses}
                caseAssets={caseData.assets || []}
                onToggleMaximize={() => setIsMaximized(p => !p)}
                isMaximized={isMaximized}
              />
            </div>
            <div style={{ background: '#080808', padding: '20px', borderLeft: '1px solid #111', overflowY: 'auto' }}>
              <button onClick={saveMapLayout} style={{ ...BtnStyle, width: '100%', marginBottom: '20px' }}>
                {saveStatus === 'READY' ? '[ COMMIT_MAP_TO_DATABASE ]' : `[ ${saveStatus} ]`}
              </button>
              <div style={{ color: '#444', fontSize: '9px', marginBottom: '15px' }}>INFRASTRUCTURE_TEMPLATES</div>
              {['SWITCH', 'ROUTER', 'FIREWALL'].map(type => (
                <button key={type} onClick={() => addInfrastructure(type)} style={TempBtnStyle}>+ ADD_{type}</button>
              ))}
              <div style={{ color: '#444', fontSize: '9px', margin: '20px 0 15px' }}>AVAILABLE_ASSETS</div>
              {caseData.assets?.map((asset, i) => (
                <div key={i} onDoubleClick={() => deployToMap(asset)} style={AssetCardStyle}>
                  <div style={{ color: '#00ff41' }}>{asset.hostname}</div>
                  <div style={{ color: '#444', fontSize: '10px' }}>{asset.ip}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── EVIDENCE WINDOW ── */}
      <EvidenceWindow
        assetId={investigatingAssetId}
        assetName={currentAsset?.hostname}
        tCode={null}
        isOpen={isEvidenceOpen}
        onClose={handleCloseEvidence}
        tacticList={evidenceTacticList}
        caseName={caseName}
        collab={collab}
        analysisMode={assetModes[String(investigatingAssetId)] || currentAsset?.analysis_mode || 'UNKNOWN'}
        assetIp={currentAsset?.ip || ''}
      />

      {/* ── LINK MODAL ── */}
      {linkForm && (
        <div style={ModalOverlay}>
          <div style={ModalContent}>
            <h2 style={{ color: '#00ff41', fontSize: '12px', marginBottom: '20px' }}>[ ESTABLISH_LINK ]: {linkForm.source} ↔ {linkForm.target}</h2>
            <div style={{ display: 'grid', gap: '15px' }}>
              <select style={InputStyle} value={linkForm.link_type} onChange={e => setLinkForm({ ...linkForm, link_type: e.target.value })}>
                <option value="WIRED">WIRED</option>
                <option value="WIRELESS">WIRELESS</option>
                <option value="VPN">VPN</option>
              </select>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <input style={InputStyle} value={linkForm.ip_src} onChange={e => setLinkForm({ ...linkForm, ip_src: e.target.value })} placeholder="SRC IP" />
                <input style={InputStyle} value={linkForm.interface_src} onChange={e => setLinkForm({ ...linkForm, interface_src: e.target.value })} placeholder="eth0" />
              </div>
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button onClick={handleConfirmLink} style={BtnStyle}>INITIATE_UPLINK</button>
                <button onClick={() => setLinkForm(null)} style={{ ...BtnStyle, background: 'transparent', color: '#444', border: '1px solid #222' }}>ABORT</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── CONFIG EDITOR MODAL ── */}
      {editingConfig && (
        <div style={ModalOverlay}>
          <div style={{ width: '90%', height: '85%', background: '#050505', border: '1px solid #00ff41', display: 'flex', flexDirection: 'column', padding: '20px' }}>
            <div style={{ color: '#00ff41', fontSize: '12px', marginBottom: '15px' }}>[TERMINAL_EDITOR]: {editingConfig.hostname.toUpperCase()}_CONFIG</div>
            <textarea autoFocus value={configBuffer} onChange={e => setConfigBuffer(e.target.value)} style={TextareaStyle} />
            <div style={{ display: 'flex', gap: '15px', marginTop: '20px' }}>
              <button onClick={() => { setActiveNodes(prev => prev.map(n => n.hostname === editingConfig.hostname ? { ...n, config: configBuffer } : n)); setEditingConfig(null); }} style={BtnStyle}>COMMIT_TO_MEMORY</button>
              <button onClick={() => setEditingConfig(null)} style={{ ...BtnStyle, background: 'transparent', color: '#444', border: '1px solid #222' }}>ABORT</button>
            </div>
          </div>
        </div>
      )}

      {/* ── ASSET REGISTRATION MODAL ── */}
      {showAssetModal && (
        <div style={ModalOverlay}>
          <div style={{ ...ModalContent, width: 480 }}>
            <h2 style={{ color: '#00ff41', fontSize: '14px', marginBottom: '20px' }}>NEW_ASSET_SPECIFICATION</h2>
            <div style={{ display: 'grid', gap: '10px' }}>
              <input style={InputStyle} placeholder="HOSTNAME" value={assetForm.hostname} onChange={e => setAssetForm({ ...assetForm, hostname: e.target.value })} />
              <input style={InputStyle} placeholder="IP_ADDRESS" value={assetForm.ip} onChange={e => setAssetForm({ ...assetForm, ip: e.target.value })} />
              <input style={InputStyle} placeholder="MAC_ADDRESS" value={assetForm.mac} onChange={e => setAssetForm({ ...assetForm, mac: e.target.value })} />
              <div>
                <div style={{ color: '#444', fontSize: 9, marginBottom: 6, letterSpacing: 1 }}>OPERATING_SYSTEM</div>
                <select style={InputStyle} value={assetForm.os} onChange={e => setAssetForm({ ...assetForm, os: e.target.value })}>
                  {['Windows', 'Linux', 'macOS', 'Other'].map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <div style={{ color: '#444', fontSize: 9, marginBottom: 6, letterSpacing: 1 }}>ASSET_TYPE</div>
                <select style={InputStyle} value={assetForm.type} onChange={e => setAssetForm({ ...assetForm, type: e.target.value })}>
                  {['Workstation', 'Server', 'Domain Controller', 'Network Device', 'Unknown'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <div style={{ color: '#444', fontSize: 9, marginBottom: 6, letterSpacing: 1 }}>ANALYSIS_MODE</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  {[
                    ['LIVE_REMOTE',      'LIVE_REMOTE',      'Deploy VR to live system'],
                    ['DEAD_DISK_LOCAL',  'DEAD_DISK_LOCAL',  'Image mounted on ORCA host'],
                    ['DEAD_DISK_REMOTE', 'DEAD_DISK_REMOTE', 'Image at analyst site B'],
                    ['UNKNOWN',          'UNKNOWN',          'Determine later'],
                  ].map(([val, label, hint]) => (
                    <button
                      key={val} onClick={() => setAssetForm({ ...assetForm, analysisMode: val })} title={hint}
                      style={{
                        background: assetForm.analysisMode === val ? '#00ff41' : 'transparent',
                        color: assetForm.analysisMode === val ? '#000' : '#444',
                        border: `1px solid ${assetForm.analysisMode === val ? '#00ff41' : '#222'}`,
                        padding: '8px 10px', fontSize: 9, fontFamily: 'monospace',
                        cursor: 'pointer', textAlign: 'left', letterSpacing: 1,
                      }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button onClick={handleRegisterAsset} style={BtnStyle}>SAVE_ASSET</button>
                <button onClick={() => setShowAssetModal(false)} style={{ background: '#111', border: 'none', color: '#444', padding: '10px', cursor: 'pointer', fontFamily: 'monospace', fontSize: 10 }}>CANCEL</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const StatTile = ({ label, val }) => (
  <div style={{ border: '1px solid #111', padding: '12px' }}>
    <div style={{ fontSize: '8px', color: '#333', marginBottom: '5px' }}>{label}</div>
    <div style={{ fontSize: '12px', color: '#eee' }}>{val || '---'}</div>
  </div>
);

const AssetCardStyle = { padding: '10px', border: '1px solid #111', marginBottom: '8px', cursor: 'grab', fontSize: '11px' };
const TempBtnStyle   = { background: '#111', color: '#00ff41', border: '1px solid #222', textAlign: 'left', width: '100%', padding: '10px', marginBottom: '8px', cursor: 'pointer', fontSize: '10px', fontFamily: 'monospace' };
const InputStyle     = { background: '#000', border: '1px solid #1a1a1a', padding: '10px', color: '#00ff41', fontSize: '11px', width: '100%', outline: 'none', fontFamily: 'monospace', boxSizing: 'border-box' };
const TextareaStyle  = { flex: 1, background: '#000', color: '#00ff41', border: '1px solid #111', fontFamily: 'monospace', fontSize: '13px', padding: '20px', outline: 'none' };
const BtnStyle       = { background: '#00ff41', color: '#000', border: 'none', padding: '10px 20px', fontWeight: 'bold', cursor: 'pointer', fontSize: '10px', fontFamily: 'monospace' };
const ModalOverlay   = { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0,0,0,0.95)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 3000 };
const ModalContent   = { background: '#050505', border: '1px solid #00ff41', padding: '40px', width: '420px' };
