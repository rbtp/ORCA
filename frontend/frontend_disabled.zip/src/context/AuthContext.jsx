import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('orca_user');
    const token = localStorage.getItem('orca_token');
    if (savedUser && token) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (username, password) => {
    const response = await fetch('https://10.11.110.60:8000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
      const data = await response.json();
      localStorage.setItem('orca_token', data.access_token);
      localStorage.setItem('orca_user', JSON.stringify(data.user));
      setUser(data.user);
      return { success: true };
    } else {
      const error = await response.json();
      return { success: false, message: error.detail };
    }
  };

  const logout = () => {
    localStorage.removeItem('orca_token');
    localStorage.removeItem('orca_user');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);