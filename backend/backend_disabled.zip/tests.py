import psycopg2
from auth_utils import hash_password

def create_admin():
    conn = psycopg2.connect("postgresql://postgres:password@localhost:5432/orca_db")
    cur = conn.cursor()
    
    username = "admin"
    initials = "ADM"
    role = "admin"
    # This is the only time you'll type the password in plain text
    raw_password = "SuperSecretPassword123" 
    hashed = hash_password(raw_password)
    
    cur.execute(
        "INSERT INTO users (username, password_hash, initials, role) VALUES (%s, %s, %s, %s)",
        (username, hashed, initials, role)
    )
    
    conn.commit()
    print(f"User {username} created successfully.")
    cur.close()
    conn.close()

if __name__ == "__main__":
    create_admin()