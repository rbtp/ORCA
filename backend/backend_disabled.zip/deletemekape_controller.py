import subprocess
import os
import json
from datetime import datetime

# Point this to your Velociraptor executable
VR_BIN_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "bin", "velociraptor.exe"))

def run_velociraptor_task(case_id, tsource, output_root, vr_target_name, t_code):
    """
    tsource: The drive letter (e.g., "N:")
    vr_target_name: The target from our new DB column (e.g., "PowerShell")
    t_code: The MITRE ID (e.g., "T1059.001") for labeling the output
    """
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Velociraptor outputs a single unified file (JSONL is best for parsing)
    final_output_dir = os.path.join(output_root, str(case_id), run_id)
    os.makedirs(final_output_dir, exist_ok=True)
    
    output_file = os.path.join(final_output_dir, f"orca_{t_code}_results.json")

    # Construct the VQL arguments
    # Note: Velociraptor expects the target list as a JSON string
    target_list_json = json.dumps([vr_target_name])

    cmd = [
        VR_BIN_PATH,
        "artifacts", "collect", "Windows.Triage.Targets",
        "--args", f"CollectionTargets={target_list_json}",
        "--args", f"Device={tsource}",
        "--format", "jsonl",
        "--output", output_file
    ]

    try:
        # We still use Popen so the UI doesn't hang while VR scans the disk
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
        )
        
        return {
            "status": "initiated",
            "pid": process.pid,
            "output_file": output_file,
            "t_code": t_code
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}