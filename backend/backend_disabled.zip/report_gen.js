const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageBreak, TabStopType, TabStopPosition,
} = require('docx');

const payload  = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const data     = payload.report;
const sections = payload.sections;
const rangeFrom= payload.range_from ? new Date(payload.range_from) : null;
const rangeTo  = payload.range_to   ? new Date(payload.range_to)   : null;
const outPath  = process.argv[3];

const G = {
  GREEN:"00FF41", BLACK:"000000", WHITE:"FFFFFF", AMBER:"FFAA00",
  RED:"FF4141", DIM:"888888", G2:"1A1A1A", G4:"2A2A2A", G5:"333333",
};

const bdr  = { style: BorderStyle.SINGLE, size: 1, color: G.G5 };
const bdrs = { top: bdr, bottom: bdr, left: bdr, right: bdr };

function cell(text, { bold=false, color=G.WHITE, bg=G.G5, width=2000,
                       align=AlignmentType.LEFT, size=18 }={}) {
  return new TableCell({
    borders: bdrs, width: { size: width, type: WidthType.DXA },
    shading: { fill: bg, type: ShadingType.CLEAR },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    verticalAlign: VerticalAlign.CENTER,
    children: [new Paragraph({
      alignment: align,
      children: [new TextRun({ text: String(text??'—'), bold, color, font:"Courier New", size })],
    })],
  });
}
function hdr(text, opts={}) { return cell(text, { bold:true, color:G.GREEN, bg:G.G2, ...opts }); }

function para(text, { bold=false, color=G.WHITE, size=20, before=0, after=120 }={}) {
  return new Paragraph({
    spacing: { before, after },
    children: [new TextRun({ text: String(text??''), bold, color, font:"Courier New", size })],
  });
}
function sHead(text) {
  return new Paragraph({
    spacing: { before: 400, after: 180 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: G.GREEN, space: 2 } },
    children: [new TextRun({ text: text.toUpperCase(), bold:true, color:G.GREEN, font:"Courier New", size:28 })],
  });
}
function divider() {
  return new Paragraph({
    spacing: { before:60, after:60 },
    border: { bottom: { style: BorderStyle.SINGLE, size:1, color:"333333", space:1 } },
    children: [],
  });
}
function verdictBg(v) {
  const u=(v||'').toUpperCase();
  if(u==='MALICIOUS') return '3A0000';
  if(u==='NON_MALICIOUS') return '003318';
  return G.G5;
}
function verdictColor(v) {
  const u=(v||'').toUpperCase();
  if(u==='MALICIOUS') return G.RED;
  if(u==='NON_MALICIOUS') return G.GREEN;
  return G.DIM;
}
function sLabel(s) {
  return {CLOSED:'Closed',PENDING_REVIEW:'Pending Review',
          IN_PROGRESS:'In Progress',UNCLAIMED:'Unclaimed'}[(s||'').toUpperCase()]||s||'—';
}
function fmt(n) { return (n??0).toLocaleString(); }
function pct(a,b) { return b ? ((a/b)*100).toFixed(1)+'%' : '0%'; }

// ── cover ─────────────────────────────────────────────────────
function cover() {
  const gen = data.generated_at ? new Date(data.generated_at).toUTCString() : new Date().toUTCString();
  return [
    new Paragraph({ spacing:{before:2160,after:120}, children:[
      new TextRun({ text:"ORCA DFIR PLATFORM", bold:true, color:G.GREEN, font:"Courier New", size:64 })]}),
    new Paragraph({ spacing:{after:80}, children:[
      new TextRun({ text:"INVESTIGATION REPORT", bold:true, color:G.WHITE, font:"Courier New", size:40 })]}),
    divider(), para(''),
    new Paragraph({ spacing:{after:80}, children:[
      new TextRun({text:"CASE:            ",color:G.DIM,font:"Courier New",size:24}),
      new TextRun({text:(data.case_name||'').toUpperCase(),bold:true,color:G.WHITE,font:"Courier New",size:24})]}),
    new Paragraph({ spacing:{after:80}, children:[
      new TextRun({text:"FOCUS COUNTRY:   ",color:G.DIM,font:"Courier New",size:24}),
      new TextRun({text:(data.focus_country||'UNKNOWN').toUpperCase(),bold:true,color:G.AMBER,font:"Courier New",size:24})]}),
    new Paragraph({ spacing:{after:80}, children:[
      new TextRun({text:"GENERATED:       ",color:G.DIM,font:"Courier New",size:24}),
      new TextRun({text:gen,color:G.WHITE,font:"Courier New",size:24})]}),
    new Paragraph({ spacing:{after:80}, children:[
      new TextRun({text:"CLASSIFICATION:  ",color:G.DIM,font:"Courier New",size:24}),
      new TextRun({text:"CONFIDENTIAL",bold:true,color:G.RED,font:"Courier New",size:24})]}),
    para(''), divider(),
    new Paragraph({ children:[new PageBreak()] }),
  ];
}

// ── summary ───────────────────────────────────────────────────
function renderSummary() {
  const s=data.summary||{};
  const cw=3120;
  const tiles=[
    {l:"TOTAL TECHNIQUES",v:fmt(s.total_techniques)},
    {l:"CLOSED",v:fmt(s.closed)},
    {l:"WITH EVIDENCE",v:fmt(s.with_evidence)},
    {l:"NO ARTIFACTS",v:fmt(s.no_artifacts),c:G.DIM},
    {l:"PENDING",v:fmt(s.pending),c:G.AMBER},
    {l:"COMPLETION",v:pct(s.closed,s.total_techniques)},
    {l:"MALICIOUS",v:fmt(s.malicious),c:G.RED},
    {l:"NON-MALICIOUS",v:fmt(s.non_malicious),c:G.GREEN},
    {l:"UNDETERMINED",v:fmt(s.undetermined),c:G.DIM},
  ];
  const rows=[];
  for(let i=0;i<tiles.length;i+=3){
    const sl=tiles.slice(i,i+3);
    while(sl.length<3) sl.push({l:'',v:''});
    rows.push(new TableRow({children:sl.map(t=>new TableCell({
      borders:bdrs,width:{size:cw,type:WidthType.DXA},
      shading:{fill:G.G2,type:ShadingType.CLEAR},
      margins:{top:140,bottom:140,left:200,right:200},
      children:[
        new Paragraph({spacing:{after:40},children:[new TextRun({text:t.l,color:G.DIM,font:"Courier New",size:16})]}),
        new Paragraph({children:[new TextRun({text:String(t.v??'—'),bold:true,color:t.c||G.WHITE,font:"Courier New",size:40})]}),
      ],
    }))}));
  }
  return [sHead("Investigation Summary"),
    new Table({width:{size:9360,type:WidthType.DXA},columnWidths:[cw,cw,cw],rows}),
    para('')];
}

// ── daily ─────────────────────────────────────────────────────
function renderDaily(detail) {
  const out=[sHead("Daily Update")];
  if(!rangeFrom||!rangeTo){out.push(para("No date range specified.",{color:G.DIM}));return out;}
  const rf=rangeFrom.getTime(),rt=rangeTo.getTime();
  out.push(new Paragraph({spacing:{after:80},children:[
    new TextRun({text:`PERIOD: ${rangeFrom.toUTCString()}  \u2192  ${rangeTo.toUTCString()}`,color:G.AMBER,font:"Courier New",size:18}),
  ]}));
  const closed=(data.techniques||[]).filter(t=>{
    if(!t.closed_at)return false;
    const ts=new Date(t.closed_at).getTime();return ts>=rf&&ts<=rt;
  });
  const notes=(data.timeline||[]).filter(n=>{
    const ts=new Date(n.created_at).getTime();return ts>=rf&&ts<=rt;
  });
  const malCount=closed.filter(t=>(t.verdict||'').toUpperCase()==='MALICIOUS').length;
  const cw=3120;
  const hTiles=[
    {l:"TECHNIQUES CLOSED",v:fmt(closed.length),c:G.WHITE},
    {l:"ANALYST ENTRIES",v:fmt(notes.length),c:G.AMBER},
    {l:"MALICIOUS FINDS",v:fmt(malCount),c:malCount>0?G.RED:G.DIM},
  ];
  out.push(new Table({width:{size:9360,type:WidthType.DXA},columnWidths:[cw,cw,cw],rows:[
    new TableRow({children:hTiles.map(t=>new TableCell({
      borders:bdrs,width:{size:cw,type:WidthType.DXA},
      shading:{fill:G.G2,type:ShadingType.CLEAR},
      margins:{top:140,bottom:140,left:200,right:200},
      children:[
        new Paragraph({spacing:{after:40},children:[new TextRun({text:t.l,color:G.DIM,font:"Courier New",size:16})]}),
        new Paragraph({children:[new TextRun({text:t.v,bold:true,color:t.c,font:"Courier New",size:40})]}),
      ],
    }))}),
  ]}));
  out.push(para(''));
  // per-asset breakdown
  const byAsset={};
  for(const t of closed){
    const aid=t.asset_id||'unknown';
    if(!byAsset[aid]) byAsset[aid]={hostname:t.hostname||String(aid),closed:0,mal:0,nonmal:0};
    byAsset[aid].closed++;
    if((t.verdict||'').toUpperCase()==='MALICIOUS') byAsset[aid].mal++;
    if((t.verdict||'').toUpperCase()==='NON_MALICIOUS') byAsset[aid].nonmal++;
  }
  const arows=Object.values(byAsset);
  if(arows.length){
    const cols=[3000,2000,2180,2180];
    out.push(new Table({width:{size:9360,type:WidthType.DXA},columnWidths:cols,rows:[
      new TableRow({tableHeader:true,children:[hdr("ASSET",{width:cols[0]}),hdr("CLOSED",{width:cols[1]}),hdr("MALICIOUS",{width:cols[2]}),hdr("NON-MALICIOUS",{width:cols[3]})]}),
      ...arows.map((a,i)=>{const bg=i%2?G.G4:G.G5;return new TableRow({children:[
        cell(a.hostname,{bg,width:cols[0]}),cell(a.closed,{bg,width:cols[1],color:G.GREEN}),
        cell(a.mal,{bg,width:cols[2],color:a.mal>0?G.RED:G.DIM}),cell(a.nonmal,{bg,width:cols[3],color:G.GREEN}),
      ]});}),
    ]}));
    out.push(para(''));
  }
  if(detail&&notes.length){
    out.push(new Paragraph({spacing:{before:160,after:80},children:[new TextRun({text:"ANALYST NOTES IN RANGE",bold:true,color:G.AMBER,font:"Courier New",size:20})]}));
    for(const n of notes){
      const init=(n.initials||n.author||'??').toUpperCase();
      out.push(new Paragraph({spacing:{before:100,after:40},children:[
        new TextRun({text:`[${init}]  [${n.t_code||'CASE'}]  ${new Date(n.created_at).toUTCString()}`,bold:true,color:G.AMBER,font:"Courier New",size:18}),
      ]}));
      out.push(para(n.text,{size:20,after:80}));
      out.push(divider());
    }
  }
  return out;
}

// ── assets ────────────────────────────────────────────────────
function renderAssets() {
  const out=[sHead("Asset Breakdown")];
  const s=data.summary||{};
  for(const asset of (data.assets||[])){
    const techs=(data.techniques||[]).filter(t=>t.asset_id===asset.id);
    const closed=techs.filter(t=>(t.technique_status||'').toUpperCase()==='CLOSED').length;
    const mal=techs.filter(t=>(t.verdict||'').toUpperCase()==='MALICIOUS').length;
    const total=techs.length||s.total_techniques||1;
    out.push(new Paragraph({spacing:{before:160,after:60},children:[
      new TextRun({text:asset.hostname,bold:true,color:G.GREEN,font:"Courier New",size:24}),
      new TextRun({text:`  ${asset.os}  \u00B7  ${asset.asset_type}  \u00B7  ${asset.analysis_mode}`,color:G.DIM,font:"Courier New",size:18}),
    ]}));
    const cols=[3000,2000,2180,2180];
    out.push(new Table({width:{size:9360,type:WidthType.DXA},columnWidths:cols,rows:[
      new TableRow({children:[
        cell(`${closed} / ${total} CLOSED`,{bg:G.G2,width:cols[0],color:G.GREEN}),
        cell(pct(closed,total),{bg:G.G2,width:cols[1],color:G.GREEN}),
        cell(`${mal} MALICIOUS`,{bg:G.G2,width:cols[2],color:mal>0?G.RED:G.DIM}),
        cell(`${total-closed} REMAINING`,{bg:G.G2,width:cols[3],color:G.AMBER}),
      ]}),
    ]}));
    out.push(para(''));
  }
  return out;
}

// ── BLUF ──────────────────────────────────────────────────────
function renderBluf() {
  const out=[sHead("Executive Summary (BLUF)")];
  const notes=data.bluf_notes||[];
  if(!notes.length){out.push(para("No BLUF notes recorded.",{color:G.DIM}));return out;}
  for(const n of notes){
    out.push(new Paragraph({spacing:{before:160,after:60},children:[
      new TextRun({text:`[${(n.author||'ANALYST').toUpperCase()}]  ${n.created_at?new Date(n.created_at).toUTCString():''}`,bold:true,color:G.AMBER,font:"Courier New",size:18}),
    ]}));
    out.push(para(n.text,{size:20,after:80}));
    out.push(divider());
  }
  return out;
}

// ── timeline ─────────────────────────────────────────────────
function renderTimeline(detail) {
  const out=[sHead("Analyst Timeline")];
  const entries=data.timeline||[];
  if(!entries.length){out.push(para("No timeline entries.",{color:G.DIM}));return out;}
  if(!detail){
    const cols=[2200,900,1200,5060];
    out.push(new Table({width:{size:9360,type:WidthType.DXA},columnWidths:cols,rows:[
      new TableRow({tableHeader:true,children:[hdr("TIMESTAMP",{width:cols[0]}),hdr("BY",{width:cols[1]}),hdr("T-CODE",{width:cols[2]}),hdr("NOTE",{width:cols[3]})]}),
      ...entries.map((e,i)=>{const bg=i%2?G.G4:G.G5;return new TableRow({children:[
        cell(e.created_at?new Date(e.created_at).toUTCString():'',{bg,width:cols[0],size:14}),
        cell((e.initials||'??').toUpperCase(),{bg,width:cols[1],color:G.GREEN}),
        cell(e.t_code||'CASE',{bg,width:cols[2],color:G.AMBER}),
        cell(e.text,{bg,width:cols[3]}),
      ]});}),
    ]}));
  } else {
    for(const e of entries){
      const init=(e.initials||e.author||'??').toUpperCase();
      out.push(new Paragraph({spacing:{before:140,after:40},children:[
        new TextRun({text:`[${init}]  [${e.t_code||'CASE'}]  ${e.created_at?new Date(e.created_at).toUTCString():''}`,bold:true,color:G.GREEN,font:"Courier New",size:18}),
      ]}));
      out.push(para(e.text,{size:20,after:80}));
      out.push(divider());
    }
  }
  return out;
}

// ── verdicts ──────────────────────────────────────────────────
function renderVerdicts() {
  const cols=[1440,3360,1440,1680,940];
  const out=[sHead("Technique Verdicts")];
  out.push(new Table({width:{size:9360,type:WidthType.DXA},columnWidths:cols,rows:[
    new TableRow({tableHeader:true,children:[
      hdr("T-CODE",{width:cols[0]}),hdr("TECHNIQUE",{width:cols[1]}),
      hdr("VERDICT",{width:cols[2]}),hdr("STATUS",{width:cols[3]}),hdr("EVID.",{width:cols[4]}),
    ]}),
    ...(data.techniques||[]).map(t=>{
      const bg=verdictBg(t.verdict),vc=verdictColor(t.verdict);
      return new TableRow({children:[
        cell(t.t_code,{bg,width:cols[0],color:G.GREEN,bold:true}),
        cell(t.technique_name,{bg,width:cols[1]}),
        cell(t.verdict||'\u2014',{bg,width:cols[2],color:vc,bold:true}),
        cell(sLabel(t.technique_status),{bg,width:cols[3],color:G.DIM}),
        cell(t.evidence_imported?'\u2713':'\u2014',{bg,width:cols[4],color:t.evidence_imported?G.GREEN:G.DIM,align:AlignmentType.CENTER}),
      ]});
    }),
  ]}));
  out.push(para(''));
  return out;
}

// ── header/footer ─────────────────────────────────────────────
const docHeader={default:new Header({children:[new Paragraph({
  border:{bottom:{style:BorderStyle.SINGLE,size:4,color:G.GREEN,space:2}},
  spacing:{after:100},
  children:[
    new TextRun({text:"ORCA DFIR",bold:true,color:G.GREEN,font:"Courier New",size:20}),
    new TextRun({text:"  //  INVESTIGATION REPORT  //  ",color:G.DIM,font:"Courier New",size:20}),
    new TextRun({text:(data.case_name||'').toUpperCase(),bold:true,color:G.WHITE,font:"Courier New",size:20}),
  ],
})]})};

const docFooter={default:new Footer({children:[new Paragraph({
  border:{top:{style:BorderStyle.SINGLE,size:2,color:"333333",space:2}},
  spacing:{before:80},
  tabStops:[{type:TabStopType.RIGHT,position:TabStopPosition.MAX}],
  children:[
    new TextRun({text:"CONFIDENTIAL \u2014 AUTHORIZED USE ONLY",color:G.DIM,font:"Courier New",size:16}),
    new TextRun({text:"\t",font:"Courier New",size:16}),
  ],
})]})};

// ── assemble ─────────────────────────────────────────────────
const RENDERERS={
  summary:()=>renderSummary(),
  daily:(d)=>renderDaily(d),
  assets:()=>renderAssets(),
  bluf:()=>renderBluf(),
  timeline:(d)=>renderTimeline(d),
  verdicts:()=>renderVerdicts(),
};

const children=[...cover()];
for(const sec of sections){
  if(RENDERERS[sec.id]) children.push(...RENDERERS[sec.id](sec.detail));
}

const doc=new Document({
  background:{color:G.BLACK},
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1080,right:1080,bottom:1080,left:1080}}},
    headers:docHeader,footers:docFooter,children,
  }],
});

Packer.toBuffer(doc)
  .then(buf=>{fs.writeFileSync(outPath,buf);process.stdout.write('OK\n');})
  .catch(e=>{process.stderr.write(e.message+'\n');process.exit(1);});