"""
report_routes.py — ORCA Reporting Module
=========================================
Assembles case data into a structured report payload.
Frontend consumes this JSON to render the REPORT tab and eventually export PDF/Word.

Endpoint:
  GET /api/reports/{case_name}?asset_id={id}

Response shape:
  {
    "case_name": str,
    "focus_country": str,
    "generated_at": ISO timestamp,
    "summary": {
      "total_techniques": int,
      "closed": int,
      "with_evidence": int,
      "no_artifacts": int,
      "pending": int,
      "completion_pct": float,
      "malicious": int,
      "non_malicious": int,
      "undetermined": int
    },
    "bluf_notes": [{ "author", "text", "created_at" }],
    "timeline": [{ "author", "initials", "t_code", "text", "note_type", "created_at" }],
    "techniques": [{
      "t_code", "technique_name", "verdict", "technique_status",
      "evidence_imported", "associated_actors", "closed_at"
    }],
    "assets": [{ "id", "hostname", "os", "asset_type", "analysis_mode" }]
  }
"""

from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy import text
from typing import Optional
from datetime import datetime

from core.database_manager import db
from auth_utils import get_current_user

router = APIRouter(prefix="/api/reports")


@router.get("/{case_name}")
async def get_case_report(
    case_name: str,
    asset_id: Optional[int] = None,
    current_user: dict = Depends(get_current_user)
):
    """
    Assemble full report data for a case.
    If asset_id is provided, technique data is scoped to that asset.
    If not, returns aggregate across all assets in the case.
    """
    session = db.get_session()
    try:
        # ── Case metadata ──────────────────────────────────────────────────────
        case_row = session.execute(
            text("SELECT name, focus_country FROM cases WHERE name = :n"),
            {"n": case_name}
        ).mappings().first()

        if not case_row:
            raise HTTPException(status_code=404, detail=f"Case '{case_name}' not found")

        focus_country = case_row["focus_country"]

        # ── Assets ────────────────────────────────────────────────────────────
        assets = session.execute(text("""
            SELECT id, hostname, os, asset_type, analysis_mode
            FROM assets
            WHERE case_name = :cn
            ORDER BY hostname
        """), {"cn": case_name}).mappings().all()
        assets_list = [dict(a) for a in assets]

        # Determine which asset_ids to scope technique data to
        if asset_id:
            scoped_asset_ids = [asset_id]
        else:
            scoped_asset_ids = [a["id"] for a in assets_list]

        # ── Technique results ─────────────────────────────────────────────────
        # Aggregate across scoped assets — one row per t_code, worst-case verdict
        techniques = session.execute(text("""
            SELECT
                mt.t_code,
                mt.name AS technique_name,
                string_agg(DISTINCT ta.group_name, ', ') AS associated_actors,
                -- Worst-case verdict: MALICIOUS > Evidence Found > NO_ARTIFACTS > Undetermined
                CASE
                    WHEN bool_or(ar.verdict = 'MALICIOUS') THEN 'MALICIOUS'
                    WHEN bool_or(ar.verdict = 'Evidence Found') THEN 'Evidence Found'
                    WHEN bool_or(ar.verdict = 'NO_ARTIFACTS') THEN 'NO_ARTIFACTS'
                    ELSE 'Undetermined'
                END AS verdict,
                -- Worst-case status
                CASE
                    WHEN bool_or(ar.technique_status = 'CLOSED') THEN 'CLOSED'
                    WHEN bool_or(ar.technique_status = 'PENDING_REVIEW') THEN 'PENDING_REVIEW'
                    WHEN bool_or(ar.technique_status = 'IN_PROGRESS') THEN 'IN_PROGRESS'
                    ELSE 'UNCLAIMED'
                END AS technique_status,
                bool_or(COALESCE(ar.evidence_imported, FALSE)) AS evidence_imported,
                MAX(ar.closed_at) AS closed_at
            FROM threat_attribution ta
            JOIN mitre_actors ma ON ta.group_name = ma.name
            JOIN mitre_relationships mr ON ma.stix_id = mr.source_ref
            JOIN mitre_techniques mt ON mr.target_ref = mt.stix_id
            JOIN ref_artifact_library ref ON mt.t_code = ref.t_code
            LEFT JOIN artifact_results ar ON (
                ar.t_code = mt.t_code
                AND ar.asset_id = ANY(:asset_ids)
            )
            WHERE UPPER(ta.attribution) = UPPER(:country)
              AND mr.relationship_type = 'uses'
              AND NOT COALESCE(mt.is_deprecated, FALSE)
              AND NOT COALESCE(mt.is_revoked, FALSE)
            GROUP BY mt.t_code, mt.name
            ORDER BY mt.t_code
        """), {"country": focus_country, "asset_ids": scoped_asset_ids}).mappings().all()

        tech_list = [dict(t) for t in techniques]

        # ── Summary counts ────────────────────────────────────────────────────
        total         = len(tech_list)
        closed        = sum(1 for t in tech_list if t["technique_status"] == "CLOSED")
        with_evidence = sum(1 for t in tech_list if t["evidence_imported"])
        no_artifacts  = sum(1 for t in tech_list if (t["verdict"] or "").upper() == "NO_ARTIFACTS")
        pending       = total - with_evidence - no_artifacts
        malicious     = sum(1 for t in tech_list if (t["verdict"] or "").upper() == "MALICIOUS")
        non_malicious = sum(1 for t in tech_list if (t["verdict"] or "").upper() == "NON-MALICIOUS")
        undetermined  = total - malicious - non_malicious
        completion_pct = round((closed / total * 100), 1) if total > 0 else 0.0

        # ── BLUF notes (case-level) ────────────────────────────────────────────
        bluf_notes = session.execute(text("""
            SELECT n.note_text AS text, u.username AS author, n.created_at
            FROM case_notes n
            LEFT JOIN users u ON n.author_id = u.id
            WHERE n.case_name = :cn
              AND n.note_type = 'BLUF'
            ORDER BY n.created_at DESC
        """), {"cn": case_name}).mappings().all()

        # ── Timeline (tcode notes across scoped assets) ───────────────────────
        timeline = session.execute(text("""
            SELECT
                n.t_code,
                n.note_text AS text,
                n.note_type,
                n.author_initials AS initials,
                u.username AS author,
                n.created_at
            FROM tcode_notes n
            LEFT JOIN users u ON n.author_id = u.id
            WHERE n.asset_id = ANY(:asset_ids)
            ORDER BY n.created_at ASC
        """), {"asset_ids": scoped_asset_ids}).mappings().all()

        return {
            "case_name":     case_name,
            "focus_country": focus_country,
            "generated_at":  datetime.utcnow().isoformat(),
            "summary": {
                "total_techniques": total,
                "closed":           closed,
                "with_evidence":    with_evidence,
                "no_artifacts":     no_artifacts,
                "pending":          pending,
                "completion_pct":   completion_pct,
                "malicious":        malicious,
                "non_malicious":    non_malicious,
                "undetermined":     undetermined,
            },
            "bluf_notes": [dict(n) for n in bluf_notes],
            "timeline":   [dict(t) for t in timeline],
            "techniques": tech_list,
            "assets":     assets_list,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()