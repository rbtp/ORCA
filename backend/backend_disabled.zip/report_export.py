"""
report_export.py  —  ORCA Report Export Endpoint
Mount in main.py:
    from report_export import export_router
    app.include_router(export_router)

POST /api/reports/{case_name}/export?format=docx|pdf
Body: { "sections": [{"id": "summary", "detail": false}, ...], "range_from": "...", "range_to": "..." }
"""

import io, os, json, tempfile, subprocess
from datetime import datetime
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import httpx
from auth_utils import get_current_user

export_router = APIRouter()

_SCRIPT_PATH = os.path.join(os.path.dirname(__file__), "report_gen.js")


async def _fetch_report_data(case_name: str, asset_id, token: str) -> dict:
    url = f"http://localhost:8000/api/reports/{case_name}"
    if asset_id:
        url += f"?asset_id={asset_id}"
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, headers={"Authorization": f"Bearer {token}"})
    if resp.status_code == 404:
        raise HTTPException(status_code=404, detail=f"Case '{case_name}' not found")
    if resp.status_code != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch report data")
    return resp.json()


class SectionConfig(BaseModel):
    id: str
    detail: bool = False

class ExportRequest(BaseModel):
    sections: List[SectionConfig] = []
    range_from: Optional[str] = None
    range_to:   Optional[str] = None


def generate_docx(report_data: dict, sections: list, range_from: str, range_to: str) -> bytes:
    with tempfile.TemporaryDirectory() as d:
        payload = {"report": report_data, "sections": sections,
                   "range_from": range_from, "range_to": range_to}
        data_file = os.path.join(d, "data.json")
        out_file  = os.path.join(d, "report.docx")

        with open(data_file, "w", encoding="utf-8") as f:
            json.dump(payload, f, default=str)

        result = subprocess.run(
            ["node", _SCRIPT_PATH, data_file, out_file],
            capture_output=True, text=True
        )
        if result.returncode != 0 or not os.path.exists(out_file):
            raise RuntimeError(f"docx generation failed:\n{result.stderr.strip()}")

        with open(out_file, "rb") as f:
            return f.read()


@export_router.post("/api/reports/{case_name}/export")
async def export_report(
    case_name: str,
    request: Request,
    format: str = Query(default="docx", pattern="^(docx|pdf)$"),
    asset_id: Optional[int] = Query(default=None),
    body: ExportRequest = None,
    current_user: dict = Depends(get_current_user),
):
    body = body or ExportRequest()
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    report_data = await _fetch_report_data(case_name, asset_id, token)

    sections = [s.dict() for s in body.sections] if body.sections else [
        {"id": sid, "detail": False}
        for sid in ["summary", "daily", "assets", "bluf", "timeline", "verdicts"]
    ]

    try:
        docx_bytes = generate_docx(report_data, sections, body.range_from, body.range_to)
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))

    slug = "".join(c if c.isalnum() else "_" for c in case_name.lower())
    ts   = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    if format == "docx":
        return StreamingResponse(
            io.BytesIO(docx_bytes),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="orca_report_{slug}_{ts}.docx"'},
        )

    # PDF via docx2pdf (uses Microsoft Word on Windows)
    try:
        from docx2pdf import convert
    except ImportError:
        raise HTTPException(status_code=500, detail="docx2pdf not installed. Run: pip install docx2pdf")

    with tempfile.TemporaryDirectory() as d:
        docx_path = os.path.join(d, "report.docx")
        pdf_path  = os.path.join(d, "report.pdf")
        with open(docx_path, "wb") as f:
            f.write(docx_bytes)
        try:
            convert(docx_path, pdf_path)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"PDF conversion failed: {e}")
        if not os.path.exists(pdf_path):
            raise HTTPException(status_code=500, detail="PDF conversion produced no output")
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()

    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="orca_report_{slug}_{ts}.pdf"'},
    )