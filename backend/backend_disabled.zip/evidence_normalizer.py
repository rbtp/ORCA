import json
import time
import os
from sqlalchemy import text
from core.database_manager import db

def normalize_and_ingest(file_path, asset_id, t_code, target_name_hint=None, is_fallback=False):
    """
    Standardizes evidence from Velociraptor JSONL output.
    Ensures nested objects are flattened to avoid React [object Object] rendering.
    """
    if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
        print(f"[-] SKIPPING: {file_path} is empty or missing.")
        return 0

    try:
        # Prevent race conditions with Velociraptor's file write
        time.sleep(0.5) 
        
        evidence_list = []
        with open(file_path, 'r', encoding='utf-8-sig', errors='ignore') as f:
            for line in f:
                if line.strip():
                    try:
                        raw_item = json.loads(line)
                        # Skip VR source header rows emitted by artifacts collect
                        if '_Source' in raw_item and len(raw_item) == 1:
                            continue
                        
                        # FLATTEN: Convert nested dictionaries/lists to strings
                        # This prevents the [object Object] error in the UI
                        clean_item = {}
                        for k, v in raw_item.items():
                            if isinstance(v, (dict, list)):
                                clean_item[k] = json.dumps(v)
                            else:
                                clean_item[k] = v
                        if is_fallback:
                            clean_item["_orca_fallback"] = True
                            clean_item["_orca_fallback_note"] = "Primary query returned 0 hits — broad EventID collection for analyst review"
                        evidence_list.append(clean_item)
                    except Exception as json_err:
                        print(f"[!] JSON PARSE ERROR in {file_path}: {json_err}")
        
        if not evidence_list:
            return 0

        with db.engine.connect() as conn:
            # --- FIX APPLIED HERE ---
            # Create a structured dictionary for the summary
            summary_data = {
                "message": (
                    f"Broad Collection (Fallback): {len(evidence_list)} entries — primary query returned 0 hits. Review for relevance."
                    if is_fallback else
                    f"Forensic Hit: {len(evidence_list)} system entries found via {target_name_hint or 'Surgical Logic'}"
                )
            }

            # ACTION A: Update the UI Status Map (Purple status)
            conn.execute(text("""
                INSERT INTO artifact_results (asset_id, t_code, verdict, evidence_summary, evidence_imported)
                VALUES (:aid, :t, 'Evidence Found', :s, TRUE)
                ON CONFLICT (asset_id, t_code) 
                DO UPDATE SET 
                    verdict = 'Evidence Found',
                    evidence_summary = EXCLUDED.evidence_summary,
                    evidence_imported = TRUE
            """), {
                "aid": asset_id,
                "t": t_code,
                "s": json.dumps(summary_data) # Wrap in json.dumps to fix InvalidTextRepresentation
            })

            # ACTION B: Populate the Evidence Table for Deep Analysis View
            for item in evidence_list:
                # Determine best display names based on forensic type
                display_name = item.get("Name") or item.get("EventID") or item.get("ID") or target_name_hint or "Surgical_Hit"
                display_path = item.get("Key") or item.get("OSPath") or item.get("FullPath") or "System"

                conn.execute(text("""
                    INSERT INTO evidence (asset_id, t_code, file_name, file_path, raw_data)
                    VALUES (:aid, :t, :fname, :fpath, :raw)
                """), {
                    "aid": asset_id,
                    "t": t_code,
                    "fname": display_name,
                    "fpath": display_path,
                    "raw": json.dumps(item)
                })

            conn.commit()
            
        print(f"[+] SUCCESS: {t_code} ingested correctly ({len(evidence_list)} rows).")
        return len(evidence_list)
            
    except Exception as e:
        print(f"[!] INGESTION_ERROR for {t_code}: {e}")
        return 0