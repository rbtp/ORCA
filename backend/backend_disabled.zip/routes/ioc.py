from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy import text
from core.database_manager import db 
from pydantic import BaseModel
from typing import Optional
import httpx  # For the external lookup proxy

# --- AUTH IMPORTS ---
from auth_utils import get_current_user

router = APIRouter(prefix="/api/ioc", tags=["ioc"])

class AddIOCRequest(BaseModel):
    value: str
    ioc_type: str
    case_name: str
    hostname: str
    t_code: str

@router.get("/search")
async def search_all_evidence(query: str, current_user: dict = Depends(get_current_user)):
    sql = text("""
        SELECT 
            c.name as case_origin, 
            a.hostname, 
            e.t_code, 
            e.raw_data->>'Name' as artifact_alias,
            e.raw_data->>'ValueData' as evidence_detail,
            e.raw_data as full_context
        FROM public.cases c
        JOIN public.assets a ON c.name = a.case_name
        JOIN public.evidence e ON a.id = e.asset_id
        WHERE e.raw_data::text ILIKE :term
    """)
    
    try:
        with db.engine.connect() as conn:
            result = conn.execute(sql, {"term": f"%{query}%"})
            findings = [dict(row) for row in result.mappings()]
            
        return {
            "search_term": query,
            "total_hits": len(findings),
            "data": findings
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/add")
async def add_discovered_ioc(req: AddIOCRequest, current_user: dict = Depends(get_current_user)):
    """Promotes a piece of evidence to a permanent IOC with automated context notes."""
    automated_note = f"Added from {req.case_name} investigation of {req.hostname} in Mitre Att&ck code {req.t_code}"
    
    sql = text("""
        INSERT INTO public.discovered_iocs (ioc_value, ioc_type, case_name, t_code, note)
        VALUES (:val, :type, :case, :tcode, :note)
        ON CONFLICT (ioc_value, case_name) DO UPDATE SET note = excluded.note
    """)
    
    try:
        with db.engine.connect() as conn:
            conn.execute(sql, {
                "val": req.value,
                "type": req.ioc_type,
                "case": req.case_name,
                "tcode": req.t_code,
                "note": automated_note
            })
            conn.commit()
        return {"status": "success", "value": req.value, "note": automated_note}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/enrich")
async def enrich_observable(observable: str, type: str, current_user: dict = Depends(get_current_user)):
    """Proxy endpoint for on-demand lookups."""
    try:
        summary = {
            "observable": observable,
            "type": type,
            "status": "Ready for API Integration",
            "external_links": [
                f"https://otx.alienvault.com/indicator/{type}/{observable}",
                f"https://www.virustotal.com/gui/search/{observable}"
            ]
        }
        return summary
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Enrichment failed: {str(e)}")