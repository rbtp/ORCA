"""
vr_remote.py — Velociraptor remote deployment and collection for ORCA.

Transports: SSH | WINRM | SMB_PSEXEC | SMB_TASK
Flow per transport:
  1. Connect & authenticate
  2. Push velociraptor.exe to remote temp dir
  3. Push generated VQL/YAML artifacts
  4. Execute VR, write results to remote temp dir
  5. Pull result JSONL files back to local DATA_ROOT
  6. Run evidence_normalizer on each pulled file
  7. If primary returns zero rows, run fallback VQL automatically
  8. Cleanup remote temp dir if requested

Yields SSE-formatted strings for streaming to frontend.

SSE event types:
  log              — plain text status message
  error            — error message
  done             — terminal event (success or failure)
  technique_status — per-technique structured progress event
    payload: { t_code, status, rows, fallback, message }
    status values: QUEUED | RUNNING | COMPLETE | ZERO | FALLBACK_RUNNING | FALLBACK_COMPLETE | ERROR
"""

import os
import io
import re
import json
import asyncio
import tempfile
import posixpath
from datetime import datetime
from typing import AsyncGenerator

import evidence_normalizer

# ── Remote temp path (Windows targets) ──────────────────────────────────────
REMOTE_TEMP        = r"C:\Windows\Temp\orca_vr"
REMOTE_TEMP_POSIX  = "/tmp/orca_vr"  # SSH Linux targets


# ── SSE helpers ──────────────────────────────────────────────────────────────
def _sse(type_: str, data) -> str:
    return f"data: {json.dumps({'type': type_, 'data': data})}\n\n"

def _log(msg: str) -> str:
    return _sse("log", msg)

def _error(msg: str) -> str:
    return _sse("error", msg)

def _done(msg: str = "REMOTE_COLLECTION_COMPLETE") -> str:
    return _sse("done", msg)

def _tech(t_code: str, status: str, rows: int = None, fallback: bool = False, message: str = None) -> str:
    """
    Structured per-technique status event.
    Frontend uses this to build a live status table.
    status: QUEUED | RUNNING | COMPLETE | ZERO | FALLBACK_RUNNING | FALLBACK_COMPLETE | ERROR
    """
    return _sse("technique_status", {
        "t_code":   t_code,
        "status":   status,
        "rows":     rows,
        "fallback": fallback,
        "message":  message,
    })


# ── Fallback VQL generation ──────────────────────────────────────────────────
# Strip the WHERE clause of custom_vql down to just the EventID filter.
# The analyst is shown "primary query returned 0 hits — broad collection below."
_EVENTID_FILTER = re.compile(
    r'System\.EventID\.Value\s*(?:=|IN)\s*(?:\([\w,\s]+\)|\w+)',
    re.IGNORECASE | re.DOTALL
)
_WHERE_CLAUSE = re.compile(r'\bWHERE\b.+', re.IGNORECASE | re.DOTALL)

# Maps known channel names to their evtx file paths
_CHANNEL_TO_PATH = {
    'security':                                    'C:/Windows/System32/winevt/Logs/Security.evtx',
    'system':                                      'C:/Windows/System32/winevt/Logs/System.evtx',
    'application':                                 'C:/Windows/System32/winevt/Logs/Application.evtx',
    'microsoft-windows-sysmon/operational':        'C:/Windows/System32/winevt/Logs/Microsoft-Windows-Sysmon%4Operational.evtx',
    'microsoft-windows-powershell/operational':    'C:/Windows/System32/winevt/Logs/Microsoft-Windows-PowerShell%4Operational.evtx',
    'microsoft-windows-taskscheduler/operational': 'C:/Windows/System32/winevt/Logs/Microsoft-Windows-TaskScheduler%4Operational.evtx',
    'microsoft-windows-winrm/operational':         'C:/Windows/System32/winevt/Logs/Microsoft-Windows-WinRM%4Operational.evtx',
    'microsoft-windows-wmi-activity/operational':  'C:/Windows/System32/winevt/Logs/Microsoft-Windows-WMI-Activity%4Operational.evtx',
}

def build_fallback_vql(custom_vql: str):
    """
    Given a targeted custom_vql, generate a broad fallback using parse_evtx()
    with only the EventID filter, dropping all other WHERE conditions.
    Uses direct file parsing instead of source(artifact=...) to avoid
    Windows Event Log API permission issues.
    Returns None if no EventID filter is found (no useful fallback possible).
    """
    if not custom_vql:
        return None

    # Extract EventID filter
    eid_match = _EVENTID_FILTER.search(custom_vql)
    if not eid_match:
        return None

    eid_filter = eid_match.group(0).strip()

    # Extract channel from source(artifact=..., channel='...') pattern
    channel_match = re.search(r"channel\s*=\s*['\"]([^'\"]+)['\"]", custom_vql, re.IGNORECASE)
    channel = channel_match.group(1).lower() if channel_match else None
    evtx_path = _CHANNEL_TO_PATH.get(channel) if channel else None

    if evtx_path:
        # Use parse_evtx with direct file path — avoids Windows Event Log API
        select_cols = re.search(r'SELECT\s+(.+?)\s+FROM', custom_vql, re.IGNORECASE | re.DOTALL)
        cols = select_cols.group(1).strip() if select_cols else '*'
        fallback = f"SELECT {cols}\nFROM parse_evtx(filename='{evtx_path}')\nWHERE {eid_filter}"
    else:
        # No known channel — strip WHERE and reuse source() call as-is
        select_from = _WHERE_CLAUSE.sub('', custom_vql).strip()
        select_from = re.sub(r'\s+ORDER\s+BY\s+.*$', '', select_from, flags=re.IGNORECASE).strip()
        fallback = f"{select_from}\nWHERE {eid_filter}"

    return fallback


# ── VQL/YAML generation ──────────────────────────────────────────────────────
def build_collection_files(target_list: list, tsource: str, output_dir: str,
                            remap_mounted: str = None, remap_original: str = None) -> list[dict]:
    """
    Generates per-technique VQL files from ref_artifact_library.
    Returns list of dicts with keys:
      t_code, local_vql_path, remote_vql_path, remote_output_path,
      local_fallback_path (or None), remote_fallback_path (or None)
    """
    from core.database_manager import db
    from sqlalchemy import text

    files = []
    clean_tsource = tsource.replace("\\", "/").rstrip("/")

    for item in target_list:
        t_code = item["t_code"]
        with db.engine.connect() as conn:
            lib = conn.execute(text(
                "SELECT custom_vql, surgical_yaml FROM ref_artifact_library WHERE t_code = :t"
            ), {"t": t_code}).fetchone()

        local_vql    = os.path.join(output_dir, f"query_{t_code}.vql")
        remote_vql   = posixpath.join(REMOTE_TEMP, f"query_{t_code}.vql").replace("/", "\\")
        remote_out   = posixpath.join(REMOTE_TEMP, f"orca_{t_code}.jsonl").replace("/", "\\")

        if lib and lib.surgical_yaml and lib.surgical_yaml.strip():
            content = lib.surgical_yaml.strip()
            fallback_content = None  # surgical_yaml is already multi-source, no simple fallback
        elif lib and lib.custom_vql and lib.custom_vql.strip():
            content = lib.custom_vql.replace(":tsource", clean_tsource)
            fallback_content = build_fallback_vql(lib.custom_vql)
        else:
            content = f"SELECT *, '{t_code}' AS TCode FROM glob(globs='{clean_tsource}/**/{item.get('orca_name', t_code)}*')"
            fallback_content = None

        # Apply drive remapping
        if remap_mounted and remap_original:
            content = content.replace(f"{remap_original}:", f"{remap_mounted}:")
            content = content.replace(f"{remap_original.lower()}:", f"{remap_mounted.lower()}:")
            if fallback_content:
                fallback_content = fallback_content.replace(f"{remap_original}:", f"{remap_mounted}:")
                fallback_content = fallback_content.replace(f"{remap_original.lower()}:", f"{remap_mounted.lower()}:")

        with open(local_vql, "w", encoding="utf-8") as f:
            f.write(content)

        # Write fallback VQL file if one was generated
        local_fallback  = None
        remote_fallback = None
        remote_fallback_out = None
        if fallback_content:
            local_fallback  = os.path.join(output_dir, f"fallback_{t_code}.vql")
            remote_fallback = posixpath.join(REMOTE_TEMP, f"fallback_{t_code}.vql").replace("/", "\\")
            remote_fallback_out = posixpath.join(REMOTE_TEMP, f"orca_fallback_{t_code}.jsonl").replace("/", "\\")
            with open(local_fallback, "w", encoding="utf-8") as f:
                f.write(fallback_content)

        files.append({
            "t_code":               t_code,
            "orca_name":            item.get("orca_name", t_code),
            "local_vql":            local_vql,
            "remote_vql":           remote_vql,
            "remote_out":           remote_out,
            "local_fallback":       local_fallback,
            "remote_fallback":      remote_fallback,
            "remote_fallback_out":  remote_fallback_out,
        })

    return files


# ── Result file helpers ───────────────────────────────────────────────────────
def _count_jsonl_rows(path: str) -> int:
    """Count non-empty lines in a JSONL file."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return sum(1 for line in f if line.strip())
    except Exception:
        return 0


# ── SSH Transport ────────────────────────────────────────────────────────────
async def _collect_ssh(
    ip, username, password, vr_exe, target_files, local_output_dir, asset_id, cleanup, queue
):
    import paramiko

    async def q(msg): await queue.put(msg)

    try:
        await q(_log(f"SSH: connecting to {ip}..."))
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: ssh.connect(ip, username=username, password=password, timeout=15)
        )
        sftp = await asyncio.get_event_loop().run_in_executor(None, ssh.open_sftp)
        await q(_log("SSH: connected"))

        ssh.exec_command(f"mkdir -p {REMOTE_TEMP_POSIX}")
        await asyncio.sleep(0.5)

        remote_vr = f"{REMOTE_TEMP_POSIX}/velociraptor"
        await q(_log("SSH: pushing velociraptor binary..."))
        await asyncio.get_event_loop().run_in_executor(None, lambda: sftp.put(vr_exe, remote_vr))
        ssh.exec_command(f"chmod +x {remote_vr}")
        await q(_log("SSH: binary pushed"))

        # Emit QUEUED status for all techniques upfront
        for item in target_files:
            await q(_tech(item["t_code"], "QUEUED"))

        results = []
        for item in target_files:
            t_code = item["t_code"]
            remote_vql = f"{REMOTE_TEMP_POSIX}/query_{t_code}.vql"
            remote_out = f"{REMOTE_TEMP_POSIX}/orca_{t_code}.jsonl"

            await asyncio.get_event_loop().run_in_executor(
                None, lambda: sftp.put(item["local_vql"], remote_vql)
            )

            await q(_tech(t_code, "RUNNING"))
            cmd = f'{remote_vr} query -f "{remote_vql}" --format jsonl --output "{remote_out}"'
            _, stdout, stderr = ssh.exec_command(cmd)
            await asyncio.get_event_loop().run_in_executor(None, stdout.channel.recv_exit_status)

            local_out = os.path.join(local_output_dir, f"orca_{t_code}.jsonl")
            try:
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: sftp.get(remote_out, local_out)
                )
                row_count = _count_jsonl_rows(local_out)
                if row_count > 0:
                    await q(_tech(t_code, "COMPLETE", rows=row_count))
                    results.append((t_code, item["orca_name"], local_out, False))
                else:
                    # Zero rows — run fallback if available
                    if item.get("local_fallback") and item.get("remote_fallback"):
                        await q(_tech(t_code, "FALLBACK_RUNNING", rows=0,
                                      message="Primary query returned 0 hits — running broad collection for context"))
                        remote_fb = f"{REMOTE_TEMP_POSIX}/fallback_{t_code}.vql"
                        remote_fb_out = f"{REMOTE_TEMP_POSIX}/orca_fallback_{t_code}.jsonl"
                        await asyncio.get_event_loop().run_in_executor(
                            None, lambda: sftp.put(item["local_fallback"], remote_fb)
                        )
                        cmd_fb = f'{remote_vr} query -f "{remote_fb}" --format jsonl --output "{remote_fb_out}"'
                        _, stdout_fb, _ = ssh.exec_command(cmd_fb)
                        await asyncio.get_event_loop().run_in_executor(
                            None, stdout_fb.channel.recv_exit_status
                        )
                        local_fb_out = os.path.join(local_output_dir, f"orca_fallback_{t_code}.jsonl")
                        try:
                            await asyncio.get_event_loop().run_in_executor(
                                None, lambda: sftp.get(remote_fb_out, local_fb_out)
                            )
                            fb_rows = _count_jsonl_rows(local_fb_out)
                            await q(_tech(t_code, "FALLBACK_COMPLETE", rows=fb_rows, fallback=True,
                                          message=f"Broad collection returned {fb_rows} rows"))
                            if fb_rows > 0:
                                results.append((t_code, item["orca_name"], local_fb_out, True))
                            else:
                                await q(_tech(t_code, "ZERO", rows=0))
                        except FileNotFoundError:
                            await q(_tech(t_code, "ZERO", rows=0))
                    else:
                        await q(_tech(t_code, "ZERO", rows=0))
            except FileNotFoundError:
                await q(_tech(t_code, "ZERO", rows=0))

        # Normalize
        for t_code, orca_name, local_out, is_fallback in results:
            if os.path.exists(local_out) and os.path.getsize(local_out) > 0:
                await q(_log(f"Normalizing {t_code}{'(fallback)' if is_fallback else ''}..."))
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: evidence_normalizer.normalize_and_ingest(local_out, asset_id, t_code, orca_name)
                )

        if cleanup:
            await q(_log("SSH: cleaning up remote temp..."))
            ssh.exec_command(f"rm -rf {REMOTE_TEMP_POSIX}")

        sftp.close()
        ssh.close()
        await q(_done())

    except Exception as e:
        await q(_error(f"SSH_ERROR: {e}"))
        await q(_done("REMOTE_COLLECTION_FAILED"))


# ── WinRM Transport ──────────────────────────────────────────────────────────
async def _collect_winrm(
    ip, username, password, domain, vr_exe, target_files, local_output_dir, asset_id, cleanup, queue
):
    import winrm
    import base64

    async def q(msg): await queue.put(msg)

    async def push_file_winrm(session, local_path, remote_path):
        with open(local_path, "rb") as f:
            data = f.read()
        chunk_size = 8192
        chunks = [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]
        b64 = base64.b64encode(chunks[0]).decode()
        ps = f'[IO.File]::WriteAllBytes("{remote_path}", [Convert]::FromBase64String("{b64}"))'
        await asyncio.get_event_loop().run_in_executor(None, lambda: session.run_ps(ps))
        for chunk in chunks[1:]:
            b64 = base64.b64encode(chunk).decode()
            ps = f'$f=[IO.File]::Open("{remote_path}",[IO.FileMode]::Append);$f.Write([Convert]::FromBase64String("{b64}"),0,{len(chunk)});$f.Close()'
            await asyncio.get_event_loop().run_in_executor(None, lambda: session.run_ps(ps))

    async def pull_file_winrm(session, remote_path, local_path):
        ps_pull = f'[Convert]::ToBase64String([IO.File]::ReadAllBytes("{remote_path}"))'
        pull_result = await asyncio.get_event_loop().run_in_executor(
            None, lambda: session.run_ps(ps_pull)
        )
        if pull_result.status_code == 0 and pull_result.std_out:
            raw = base64.b64decode(pull_result.std_out.strip())
            with open(local_path, "wb") as f:
                f.write(raw)
            return True
        return False

    try:
        await q(_log(f"WINRM: connecting to {ip}..."))
        auth_user = f"{domain}\\{username}" if domain else username
        session = await asyncio.get_event_loop().run_in_executor(
            None, lambda: winrm.Session(f"http://{ip}:5985/wsman",
                                         auth=(auth_user, password),
                                         transport="ntlm")
        )
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: session.run_cmd(f'cmd /c mkdir "{REMOTE_TEMP}" 2>nul')
        )
        await q(_log("WINRM: connected, temp dir created"))

        await q(_log("WINRM: pushing velociraptor binary (base64)..."))
        remote_vr = f"{REMOTE_TEMP}\\velociraptor.exe"
        await push_file_winrm(session, vr_exe, remote_vr)
        await q(_log("WINRM: binary pushed"))

        # Emit QUEUED status for all techniques upfront
        for item in target_files:
            await q(_tech(item["t_code"], "QUEUED"))

        results = []
        for item in target_files:
            t_code = item["t_code"]
            remote_vql = f"{REMOTE_TEMP}\\query_{t_code}.vql"
            remote_out = f"{REMOTE_TEMP}\\orca_{t_code}.jsonl"

            await push_file_winrm(session, item["local_vql"], remote_vql)

            await q(_tech(t_code, "RUNNING"))
            cmd = f'"{remote_vr}" query -f "{remote_vql}" --format jsonl --output "{remote_out}"'
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: session.run_cmd(cmd)
            )

            local_out = os.path.join(local_output_dir, f"orca_{t_code}.jsonl")
            pulled = await pull_file_winrm(session, remote_out, local_out)

            if pulled:
                row_count = _count_jsonl_rows(local_out)
                if row_count > 0:
                    await q(_tech(t_code, "COMPLETE", rows=row_count))
                    results.append((t_code, item["orca_name"], local_out, False))
                else:
                    if item.get("local_fallback") and item.get("remote_fallback"):
                        await q(_tech(t_code, "FALLBACK_RUNNING", rows=0,
                                      message="Primary query returned 0 hits — running broad collection for context"))
                        remote_fb     = f"{REMOTE_TEMP}\\fallback_{t_code}.vql"
                        remote_fb_out = f"{REMOTE_TEMP}\\orca_fallback_{t_code}.jsonl"
                        await push_file_winrm(session, item["local_fallback"], remote_fb)
                        cmd_fb = f'"{remote_vr}" query -f "{remote_fb}" --format jsonl --output "{remote_fb_out}"'
                        await asyncio.get_event_loop().run_in_executor(
                            None, lambda: session.run_cmd(cmd_fb)
                        )
                        local_fb_out = os.path.join(local_output_dir, f"orca_fallback_{t_code}.jsonl")
                        fb_pulled = await pull_file_winrm(session, remote_fb_out, local_fb_out)
                        if fb_pulled:
                            fb_rows = _count_jsonl_rows(local_fb_out)
                            await q(_tech(t_code, "FALLBACK_COMPLETE", rows=fb_rows, fallback=True,
                                          message=f"Broad collection returned {fb_rows} rows"))
                            if fb_rows > 0:
                                results.append((t_code, item["orca_name"], local_fb_out, True))
                            else:
                                await q(_tech(t_code, "ZERO", rows=0))
                        else:
                            await q(_tech(t_code, "ZERO", rows=0))
                    else:
                        await q(_tech(t_code, "ZERO", rows=0))
            else:
                await q(_tech(t_code, "ZERO", rows=0))

        # Normalize
        for t_code, orca_name, local_out, is_fallback in results:
            if os.path.exists(local_out) and os.path.getsize(local_out) > 0:
                await q(_log(f"Normalizing {t_code}{'(fallback)' if is_fallback else ''}..."))
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: evidence_normalizer.normalize_and_ingest(local_out, asset_id, t_code, orca_name)
                )

        if cleanup:
            await q(_log("WINRM: cleaning up remote temp..."))
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: session.run_cmd(f'cmd /c rmdir /s /q "{REMOTE_TEMP}"')
            )

        await q(_done())

    except Exception as e:
        await q(_error(f"WINRM_ERROR: {e}"))
        await q(_done("REMOTE_COLLECTION_FAILED"))


# ── SMB/PsExec Transport ─────────────────────────────────────────────────────
async def _collect_smb_psexec(
    ip, username, password, domain, vr_exe, target_files, local_output_dir, asset_id, cleanup, queue
):
    from impacket.smbconnection import SMBConnection
    from impacket.examples.psexec import PSEXEC

    async def q(msg): await queue.put(msg)

    share      = "ADMIN$"
    remote_dir = "Temp\\orca_vr"

    async def smb_put(smb, local_path, remote_name):
        with open(local_path, "rb") as f:
            data = f.read()
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.putFile(share, f"{remote_dir}\\{remote_name}", io.BytesIO(data).read)
        )

    async def smb_get(smb, remote_name, local_path):
        buf = io.BytesIO()
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.getFile(share, f"{remote_dir}\\{remote_name}", buf.write)
        )
        with open(local_path, "wb") as f:
            f.write(buf.getvalue())

    try:
        await q(_log(f"SMB_PSEXEC: connecting to {ip}..."))
        smb = await asyncio.get_event_loop().run_in_executor(
            None, lambda: SMBConnection(ip, ip)
        )
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.login(username, password, domain or "")
        )
        await q(_log("SMB: authenticated"))

        try:
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: smb.createDirectory(share, remote_dir)
            )
        except Exception:
            pass

        await q(_log("SMB: pushing velociraptor binary..."))
        await smb_put(smb, vr_exe, "velociraptor.exe")
        await q(_log("SMB: binary pushed"))

        # Emit QUEUED status for all techniques upfront
        for item in target_files:
            await q(_tech(item["t_code"], "QUEUED"))

        results = []
        for item in target_files:
            t_code          = item["t_code"]
            vql_name        = f"query_{t_code}.vql"
            out_name        = f"orca_{t_code}.jsonl"
            remote_vr_path  = f"C:\\Windows\\{remote_dir}\\velociraptor.exe"
            remote_vql_path = f"C:\\Windows\\{remote_dir}\\{vql_name}"
            remote_out_path = f"C:\\Windows\\{remote_dir}\\{out_name}"

            await smb_put(smb, item["local_vql"], vql_name)

            await q(_tech(t_code, "RUNNING"))
            cmd = f'"{remote_vr_path}" query -f "{remote_vql_path}" --format jsonl --output "{remote_out_path}"'
            executer = PSEXEC(
                command=cmd, path=None, exeFile=None, copyFile=None,
                protocols=None, username=username, password=password,
                domain=domain or "", hashes=None, aesKey=None, doKerberos=False,
                kdcHost=None, mode='SERVER', share=share, port=445
            )
            await asyncio.get_event_loop().run_in_executor(None, lambda: executer.run(ip, ip))

            local_out = os.path.join(local_output_dir, f"orca_{t_code}.jsonl")
            try:
                await smb_get(smb, out_name, local_out)
                row_count = _count_jsonl_rows(local_out)
                if row_count > 0:
                    await q(_tech(t_code, "COMPLETE", rows=row_count))
                    results.append((t_code, item["orca_name"], local_out, False))
                else:
                    if item.get("local_fallback"):
                        await q(_tech(t_code, "FALLBACK_RUNNING", rows=0,
                                      message="Primary query returned 0 hits — running broad collection for context"))
                        fb_vql_name = f"fallback_{t_code}.vql"
                        fb_out_name = f"orca_fallback_{t_code}.jsonl"
                        remote_fb_path     = f"C:\\Windows\\{remote_dir}\\{fb_vql_name}"
                        remote_fb_out_path = f"C:\\Windows\\{remote_dir}\\{fb_out_name}"
                        await smb_put(smb, item["local_fallback"], fb_vql_name)
                        cmd_fb = f'"{remote_vr_path}" query -f "{remote_fb_path}" --format jsonl --output "{remote_fb_out_path}"'
                        executer_fb = PSEXEC(
                            command=cmd_fb, path=None, exeFile=None, copyFile=None,
                            protocols=None, username=username, password=password,
                            domain=domain or "", hashes=None, aesKey=None, doKerberos=False,
                            kdcHost=None, mode='SERVER', share=share, port=445
                        )
                        await asyncio.get_event_loop().run_in_executor(None, lambda: executer_fb.run(ip, ip))
                        local_fb_out = os.path.join(local_output_dir, f"orca_fallback_{t_code}.jsonl")
                        try:
                            await smb_get(smb, fb_out_name, local_fb_out)
                            fb_rows = _count_jsonl_rows(local_fb_out)
                            await q(_tech(t_code, "FALLBACK_COMPLETE", rows=fb_rows, fallback=True,
                                          message=f"Broad collection returned {fb_rows} rows"))
                            if fb_rows > 0:
                                results.append((t_code, item["orca_name"], local_fb_out, True))
                            else:
                                await q(_tech(t_code, "ZERO", rows=0))
                        except Exception:
                            await q(_tech(t_code, "ZERO", rows=0))
                    else:
                        await q(_tech(t_code, "ZERO", rows=0))
            except Exception:
                await q(_tech(t_code, "ERROR", message="Failed to pull result file"))

        # Normalize
        for t_code, orca_name, local_out, is_fallback in results:
            if os.path.exists(local_out) and os.path.getsize(local_out) > 0:
                await q(_log(f"Normalizing {t_code}{'(fallback)' if is_fallback else ''}..."))
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: evidence_normalizer.normalize_and_ingest(local_out, asset_id, t_code, orca_name)
                )

        if cleanup:
            await q(_log("SMB: cleaning up remote temp..."))
            cleaner = PSEXEC(
                command=f'cmd /c rmdir /s /q "C:\\Windows\\{remote_dir}"',
                path=None, exeFile=None, copyFile=None, protocols=None,
                username=username, password=password, domain=domain or "",
                hashes=None, aesKey=None, doKerberos=False, kdcHost=None,
                mode='SERVER', share=share, port=445
            )
            await asyncio.get_event_loop().run_in_executor(None, lambda: cleaner.run(ip, ip))

        smb.logoff()
        await q(_done())

    except Exception as e:
        await q(_error(f"SMB_PSEXEC_ERROR: {e}"))
        await q(_done("REMOTE_COLLECTION_FAILED"))


# ── SMB/Scheduled Task Transport ─────────────────────────────────────────────
async def _collect_smb_task(
    ip, username, password, domain, vr_exe, target_files, local_output_dir, asset_id, cleanup, queue
):
    from impacket.smbconnection import SMBConnection
    from impacket.dcerpc.v5 import tsch, transport as dce_transport

    async def q(msg): await queue.put(msg)

    share      = "ADMIN$"
    remote_dir = "Temp\\orca_vr"

    async def smb_put(smb, local_path, remote_name):
        with open(local_path, "rb") as f:
            data = f.read()
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.putFile(share, f"{remote_dir}\\{remote_name}", io.BytesIO(data).read)
        )

    async def smb_get(smb, remote_name, local_path):
        buf = io.BytesIO()
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.getFile(share, f"{remote_dir}\\{remote_name}", buf.write)
        )
        with open(local_path, "wb") as f:
            f.write(buf.getvalue())

    async def run_task(dce, task_name, cmd):
        xml = f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers><TimeTrigger><StartBoundary>2000-01-01T00:00:00</StartBoundary><Enabled>true</Enabled></TimeTrigger></Triggers>
  <Actions context="Author"><Exec><Command>cmd.exe</Command><Arguments>/c {cmd}</Arguments></Exec></Actions>
  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><ExecutionTimeLimit>PT1H</ExecutionTimeLimit><Priority>7</Priority></Settings>
</Task>"""
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: tsch.hSchRpcRegisterTask(dce, task_name, xml, tsch.TASK_CREATE_OR_UPDATE, None, tsch.TASK_LOGON_NONE)
        )
        await asyncio.get_event_loop().run_in_executor(None, lambda: tsch.hSchRpcRun(dce, task_name))
        for _ in range(60):
            await asyncio.sleep(1)
            try:
                info = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: tsch.hSchRpcGetLastRunInfo(dce, task_name)
                )
                if info["pLastRunInfo"]["hrLastRunResult"] != 0x00041301:
                    break
            except Exception:
                break
        await asyncio.get_event_loop().run_in_executor(None, lambda: tsch.hSchRpcDelete(dce, task_name))

    try:
        await q(_log(f"SMB_TASK: connecting to {ip}..."))
        smb = await asyncio.get_event_loop().run_in_executor(
            None, lambda: SMBConnection(ip, ip)
        )
        await asyncio.get_event_loop().run_in_executor(
            None, lambda: smb.login(username, password, domain or "")
        )
        await q(_log("SMB_TASK: authenticated"))

        try:
            await asyncio.get_event_loop().run_in_executor(
                None, lambda: smb.createDirectory(share, remote_dir)
            )
        except Exception:
            pass

        await q(_log("SMB_TASK: pushing velociraptor binary..."))
        await smb_put(smb, vr_exe, "velociraptor.exe")
        await q(_log("SMB_TASK: binary pushed"))

        string_binding = f"ncacn_np:{ip}[\\pipe\\atsvc]"
        rpctransport = dce_transport.DCERPCTransportFactory(string_binding)
        rpctransport.set_credentials(username, password, domain or "", "", "", None)
        dce = await asyncio.get_event_loop().run_in_executor(None, lambda: rpctransport.get_dce_rpc())
        await asyncio.get_event_loop().run_in_executor(None, dce.connect)
        await asyncio.get_event_loop().run_in_executor(None, lambda: dce.bind(tsch.MSRPC_UUID_TSCHS))

        # Emit QUEUED status for all techniques upfront
        for item in target_files:
            await q(_tech(item["t_code"], "QUEUED"))

        results = []
        for item in target_files:
            t_code          = item["t_code"]
            task_name       = f"\\orca_vr_{t_code.replace('.', '_')}"
            vql_name        = f"query_{t_code}.vql"
            out_name        = f"orca_{t_code}.jsonl"
            remote_vr_path  = f"C:\\Windows\\{remote_dir}\\velociraptor.exe"
            remote_vql_path = f"C:\\Windows\\{remote_dir}\\{vql_name}"
            remote_out_path = f"C:\\Windows\\{remote_dir}\\{out_name}"

            await smb_put(smb, item["local_vql"], vql_name)

            await q(_tech(t_code, "RUNNING"))
            cmd = f'"{remote_vr_path}" query -f "{remote_vql_path}" --format jsonl --output "{remote_out_path}"'
            await run_task(dce, task_name, cmd)

            local_out = os.path.join(local_output_dir, f"orca_{t_code}.jsonl")
            try:
                await smb_get(smb, out_name, local_out)
                row_count = _count_jsonl_rows(local_out)
                if row_count > 0:
                    await q(_tech(t_code, "COMPLETE", rows=row_count))
                    results.append((t_code, item["orca_name"], local_out, False))
                else:
                    if item.get("local_fallback"):
                        await q(_tech(t_code, "FALLBACK_RUNNING", rows=0,
                                      message="Primary query returned 0 hits — running broad collection for context"))
                        fb_task      = f"\\orca_fb_{t_code.replace('.', '_')}"
                        fb_vql_name  = f"fallback_{t_code}.vql"
                        fb_out_name  = f"orca_fallback_{t_code}.jsonl"
                        remote_fb_path     = f"C:\\Windows\\{remote_dir}\\{fb_vql_name}"
                        remote_fb_out_path = f"C:\\Windows\\{remote_dir}\\{fb_out_name}"
                        await smb_put(smb, item["local_fallback"], fb_vql_name)
                        cmd_fb = f'"{remote_vr_path}" query -f "{remote_fb_path}" --format jsonl --output "{remote_fb_out_path}"'
                        await run_task(dce, fb_task, cmd_fb)
                        local_fb_out = os.path.join(local_output_dir, f"orca_fallback_{t_code}.jsonl")
                        try:
                            await smb_get(smb, fb_out_name, local_fb_out)
                            fb_rows = _count_jsonl_rows(local_fb_out)
                            await q(_tech(t_code, "FALLBACK_COMPLETE", rows=fb_rows, fallback=True,
                                          message=f"Broad collection returned {fb_rows} rows"))
                            if fb_rows > 0:
                                results.append((t_code, item["orca_name"], local_fb_out, True))
                            else:
                                await q(_tech(t_code, "ZERO", rows=0))
                        except Exception:
                            await q(_tech(t_code, "ZERO", rows=0))
                    else:
                        await q(_tech(t_code, "ZERO", rows=0))
            except Exception:
                await q(_tech(t_code, "ERROR", message="Failed to pull result file"))

        dce.disconnect()

        # Normalize
        for t_code, orca_name, local_out, is_fallback in results:
            if os.path.exists(local_out) and os.path.getsize(local_out) > 0:
                await q(_log(f"Normalizing {t_code}{'(fallback)' if is_fallback else ''}..."))
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: evidence_normalizer.normalize_and_ingest(local_out, asset_id, t_code, orca_name)
                )

        if cleanup:
            await q(_log("SMB_TASK: cleaning up remote temp..."))
            smb.deleteDirectory(share, remote_dir)

        smb.logoff()
        await q(_done())

    except Exception as e:
        await q(_error(f"SMB_TASK_ERROR: {e}"))
        await q(_done("REMOTE_COLLECTION_FAILED"))


# ── Main dispatcher ───────────────────────────────────────────────────────────
async def run_remote_collection(
    asset_id: int,
    ip: str,
    transport: str,
    username: str,
    password: str,
    tsource: str,
    domain: str = None,
    cleanup: bool = True,
    remap_mounted: str = None,
    remap_original: str = None,
    vr_exe: str = None,
    data_root: str = None,
) -> AsyncGenerator[str, None]:
    """
    Main entry point. Yields SSE strings.
    Call from a FastAPI StreamingResponse.

    Technique list is derived from:
      asset → case → focus_country → threat_attribution → mitre_actors
      → mitre_relationships → mitre_techniques (platform-filtered to asset.os)
      → ref_artifact_library (must have custom_vql or surgical_yaml)

    This matches exactly what get_threat_profile returns for the same asset.
    """
    from core.database_manager import db
    from sqlalchemy import text

    queue = asyncio.Queue()

    async def generate():
        try:
            # ── Build technique list matching get_threat_profile exactly ──────
            with db.engine.connect() as conn:
                intel_rows = conn.execute(text("""
                    SELECT DISTINCT mt.t_code
                    FROM assets a
                    JOIN cases c ON c.name = a.case_name
                    JOIN threat_attribution ta ON UPPER(ta.attribution) = UPPER(c.focus_country)
                    JOIN mitre_actors ma ON ma.name = ta.group_name
                    JOIN mitre_relationships mr ON mr.source_ref = ma.stix_id
                    JOIN mitre_techniques mt ON mt.stix_id = mr.target_ref
                    JOIN ref_artifact_library ref ON ref.t_code = mt.t_code
                    WHERE a.id = :asset_id
                      AND mr.relationship_type = 'uses'
                      AND NOT COALESCE(mt.is_deprecated, FALSE)
                      AND NOT COALESCE(mt.is_revoked, FALSE)
                      AND (
                          mt.platforms IS NULL
                          OR mt.platforms = '[]'::jsonb
                          OR mt.platforms @> to_jsonb(ARRAY[a.os]::text[])
                      )
                      AND (ref.custom_vql IS NOT NULL OR ref.surgical_yaml IS NOT NULL)
                    ORDER BY mt.t_code
                """), {"asset_id": asset_id}).fetchall()

            if not intel_rows:
                yield _error(f"No techniques found for asset {asset_id} — check case country and asset OS")
                yield _done("REMOTE_COLLECTION_FAILED")
                return

            target_list = [{"t_code": r.t_code, "orca_name": r.t_code} for r in intel_rows]
            yield _log(f"Loaded {len(target_list)} techniques for asset {asset_id}")

            # ── Build local staging dir ───────────────────────────────────────
            with db.engine.connect() as conn:
                case_row = conn.execute(text(
                    "SELECT case_name FROM assets WHERE id = :id"
                ), {"id": asset_id}).fetchone()

            run_id           = datetime.now().strftime("%Y%m%d_%H%M%S")
            local_output_dir = os.path.join(
                data_root, case_row.case_name.replace(" ", "_"), f"remote_{run_id}"
            )
            os.makedirs(local_output_dir, exist_ok=True)

            with tempfile.TemporaryDirectory() as vql_staging:
                target_files = build_collection_files(
                    target_list, tsource, vql_staging,
                    remap_mounted, remap_original
                )

                task = asyncio.create_task(
                    _dispatch(transport, ip, username, password, domain,
                              vr_exe, target_files, local_output_dir,
                              asset_id, cleanup, queue)
                )

                while True:
                    try:
                        msg = await asyncio.wait_for(queue.get(), timeout=120.0)
                        yield msg
                        if '"type": "done"' in msg:
                            break
                    except asyncio.TimeoutError:
                        yield _error("TIMEOUT: no response from remote for 120s")
                        task.cancel()
                        break

                await task

        except Exception as e:
            yield _error(f"REMOTE_COLLECTION_ERROR: {e}")
            yield _done("REMOTE_COLLECTION_FAILED")

    async for chunk in generate():
        yield chunk


async def _dispatch(transport, ip, username, password, domain,
                    vr_exe, target_files, local_output_dir,
                    asset_id, cleanup, queue):
    t = transport.upper()
    if t == "SSH":
        await _collect_ssh(ip, username, password, vr_exe, target_files,
                           local_output_dir, asset_id, cleanup, queue)
    elif t == "WINRM":
        await _collect_winrm(ip, username, password, domain, vr_exe, target_files,
                             local_output_dir, asset_id, cleanup, queue)
    elif t == "SMB_PSEXEC":
        await _collect_smb_psexec(ip, username, password, domain, vr_exe, target_files,
                                  local_output_dir, asset_id, cleanup, queue)
    elif t == "SMB_TASK":
        await _collect_smb_task(ip, username, password, domain, vr_exe, target_files,
                                local_output_dir, asset_id, cleanup, queue)
    else:
        await queue.put(_error(f"Unknown transport: {transport}"))
        await queue.put(_done("REMOTE_COLLECTION_FAILED"))