import React, { useState, useEffect } from 'react';

// ─────────────────────────────────────────────────────────────────────────────
// VOLATILITY PLUGIN CATALOGUE (condensed from remora.py PLUGIN_MITRE_MAP)
// Grouped by category for the Memory Analysis tab
// ─────────────────────────────────────────────────────────────────────────────
const VOL_PLUGIN_GROUPS = {
  "Process Analysis": [
    "windows.pslist", "windows.psscan", "windows.pstree",
    "windows.cmdline", "windows.cmdscan", "windows.consoles",
  ],
  "Code Injection": [
    "windows.malfind", "windows.hollowprocesses", "windows.vadinfo",
    "windows.dlllist", "windows.ldrmodules",
  ],
  "Network": [
    "windows.netscan", "windows.netstat",
  ],
  "Registry": [
    "windows.registry.hivelist", "windows.registry.printkey",
    "windows.registry.userassist", "windows.registry.certificates",
  ],
  "Credentials": [
    "windows.hashdump", "windows.cachedump", "windows.lsadump",
  ],
  "Rootkit / Evasion": [
    "windows.ssdt", "windows.callbacks", "windows.modules",
    "windows.driverscan", "windows.modscan",
  ],
  "Files / MFT": [
    "windows.filescan", "windows.mftscan", "windows.dumpfiles",
  ],
  "Persistence": [
    "windows.svcscan", "windows.scheduled_tasks", "windows.amcache",
  ],
];

const VOL_BASE = "C:\\Users\\Sentinel\\Desktop\\Tests\\ORCAWEB\\backend\\bin\\remora\\volatility3";
const CLAM_BASE = "C:\\Users\\Sentinel\\Desktop\\Tests\\ORCAWEB\\backend\\bin\\clamav";

// ─────────────────────────────────────────────────────────────────────────────
// SUB-COMPONENT: ARTIFACT ANALYSIS TAB
// ─────────────────────────────────────────────────────────────────────────────
const ArtifactAnalysisTab = ({ assetId, assetName, tCode }) => {
  const [evidence, setEvidence] = useState([]);
  const [activeSource, setActiveSource] = useState(null);
  const [filterText, setFilterText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isCollecting, setIsCollecting] = useState(false);
  const [targetSource, setTargetSource] = useState("C:");

  const [contextMenu, setContextMenu] = useState({
    visible: false, x: 0, y: 0, selectedText: '', rowData: null
  });

  const getAuthHeaders = () => ({
    'Authorization': `Bearer ${localStorage.getItem('orca_token')}`,
    'Content-Type': 'application/json'
  });

  useEffect(() => {
    if (assetId && tCode) fetchEvidence();
  }, [assetId, tCode]);

  useEffect(() => {
    const closeMenu = () => setContextMenu(prev => ({ ...prev, visible: false }));
    window.addEventListener('click', closeMenu);
    return () => window.removeEventListener('click', closeMenu);
  }, []);

  const handleRunCollection = async () => {
    setIsCollecting(true);
    try {
      const response = await fetch('http://localhost:8000/api/assets/execute', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          action: "Surgical Collection",
          asset_id: assetId,
          tsource: targetSource
        })
      });
      const data = await response.json();
      if (response.ok && data.status === "initiated") {
        alert(`COLLECTION_STARTED: Surgical VQL acquisition initialized.\nSource: ${targetSource}\nTechniques: ${data.target_count}`);
      } else {
        alert("EXECUTION_ERROR: " + (data.detail || "Failed to initiate background task."));
      }
    } catch (err) {
      alert("CRITICAL: Failed to connect to backend service.");
    } finally {
      setIsCollecting(false);
    }
  };

  const handleContextMenu = (e, item) => {
    const selection = window.getSelection().toString().trim();
    if (!selection) return;
    e.preventDefault();
    setContextMenu({ visible: true, x: e.pageX, y: e.pageY, selectedText: selection, rowData: item });
  };

  const getVTUrl = (obs) => {
    const isIP = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(obs);
    return isIP ? `https://www.virustotal.com/gui/ip-address/${obs}` : `https://www.virustotal.com/gui/search/${obs}`;
  };

  const getOTXUrl = (obs) => {
    if (/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(obs)) return `https://otx.alienvault.com/indicator/ip/${obs}`;
    if (/^[a-fA-F0-9]{32,64}$/.test(obs)) return `https://otx.alienvault.com/indicator/file/${obs}`;
    if (obs.includes('.') && !obs.startsWith('http')) return `https://otx.alienvault.com/indicator/domain/${obs}`;
    return `https://otx.alienvault.com/browse/indicators?q=${obs}`;
  };

  const promoteToIOC = async () => {
    const { selectedText, rowData } = contextMenu;
    const hostname = rowData?.Hostname || rowData?.ComputerName || "Unknown_Asset";
    const caseName = rowData?.CaseName || "Current_Investigation";
    try {
      await fetch('http://localhost:8000/api/ioc/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: selectedText, ioc_type: "Manual_Highlight", case_name: caseName, hostname, t_code: tCode })
      });
    } catch (err) { console.error("IOC_PROMOTION_FAILED", err); }
    setContextMenu(prev => ({ ...prev, visible: false }));
  };

  const fetchEvidence = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`http://localhost:8000/api/mitre/evidence/${assetId}/${tCode}`);
      const data = await res.json();
      let content = data.rows || data;
      if (Array.isArray(content) && content.length > 0 && content[0].VQLSource) {
        const grouped = content.reduce((acc, row) => {
          const sourceName = (row.VQLSource || "General_Output").split('/').pop();
          if (!acc[sourceName]) acc[sourceName] = [];
          acc[sourceName].push(row);
          return acc;
        }, {});
        content = grouped;
      }
      setEvidence(content);
      if (content && !Array.isArray(content) && typeof content === 'object') {
        const sources = Object.keys(content);
        if (sources.length > 0) setActiveSource(sources[0]);
      }
    } catch (err) {
      setEvidence([]);
    } finally {
      setIsLoading(false);
    }
  };

  const getVisibleEvidence = () => {
    if (Array.isArray(evidence)) return evidence;
    if (evidence && activeSource) return evidence[activeSource] || [];
    return [];
  };

  const filteredEvidence = getVisibleEvidence().filter(item =>
    Object.values(item).some(val => val?.toString().toLowerCase().includes(filterText.toLowerCase()))
  );

  const formatValue = (key, value) => {
    if (!value) return '---';
    const normalizedKey = key.toUpperCase().replace(/\s/g, '');
    if (['DIRECTORIES', 'FILESLOADED', 'FILES LOADED'].includes(normalizedKey) && typeof value === 'string') {
      return (
        <div style={ListStyle}>
          {value.split(',').map((item, i) => (
            <div key={i} style={ListItemStyle}>{i + 1}. {item.trim()}</div>
          ))}
        </div>
      );
    }
    return typeof value === 'object' ? JSON.stringify(value) : value.toString();
  };

  const isYamlMode = !Array.isArray(evidence) && typeof evidence === 'object';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* COLLECTION HEADER */}
      <div style={CollectionHeader}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
          <span style={{ color: '#00ff41', fontSize: '11px', fontWeight: 'bold', whiteSpace: 'nowrap' }}>
            RUN COLLECTION FOR {(assetName || `ASSET_${assetId}`).toUpperCase()}
          </span>
          <input
            value={targetSource}
            onChange={(e) => setTargetSource(e.target.value)}
            placeholder="C:"
            style={SmallInput}
            title="--tsource (System Drive)"
          />
          <button
            onClick={handleRunCollection}
            disabled={isCollecting}
            style={{ ...SmallBtn, opacity: isCollecting ? 0.5 : 1 }}
          >
            {isCollecting ? "RUNNING..." : "EXECUTE"}
          </button>
        </div>
        <input
          type="text"
          placeholder="FILTER_RESULTS..."
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          style={SearchInputStyle}
        />
      </div>

      {/* SOURCE TABS */}
      {isYamlMode && (
        <div style={TabBar}>
          {Object.keys(evidence).map(source => (
            <button
              key={source}
              onClick={() => setActiveSource(source)}
              style={{
                ...SubTabStyle,
                borderColor: activeSource === source ? '#00ff41' : '#222',
                color: activeSource === source ? '#00ff41' : '#666',
                backgroundColor: activeSource === source ? 'rgba(0, 255, 65, 0.05)' : '#000'
              }}
            >
              {source.replace(/_/g, ' ').toUpperCase()}
            </button>
          ))}
        </div>
      )}

      {/* CONTEXT MENU */}
      {contextMenu.visible && (
        <div style={{ ...ContextMenuStyle, top: contextMenu.y, left: contextMenu.x }}>
          <div style={MenuHeader}>INTEL_ACTIONS: "{contextMenu.selectedText}"</div>
          <div style={MenuItem} onClick={() => window.open(getOTXUrl(contextMenu.selectedText))}>LOOKUP_ON_OTX</div>
          <div style={MenuItem} onClick={() => window.open(getVTUrl(contextMenu.selectedText))}>LOOKUP_ON_VIRUSTOTAL</div>
          <div style={{ ...MenuItem, borderTop: '1px solid #222', color: '#ffea00' }} onClick={promoteToIOC}>PROMOTE_TO_IOC</div>
        </div>
      )}

      {/* EVIDENCE LIST */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '15px' }}>
        {isLoading ? (
          <div style={{ color: '#00ff41', padding: '20px' }}>DECRYPTING_STORAGE_BLOCKS...</div>
        ) : filteredEvidence.length === 0 ? (
          <div style={{ color: '#333', padding: '20px', fontSize: '11px' }}>
            {tCode ? `NO_EVIDENCE_INDEXED FOR ${tCode}` : 'SELECT A TECHNIQUE TO VIEW EVIDENCE'}
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {filteredEvidence.map((item, idx) => (
              <div key={idx} style={ArtifactCard} onContextMenu={(e) => handleContextMenu(e, item)}>
                <div style={CardBadge}>INDEX_{idx.toString().padStart(3, '0')}</div>
                {Object.entries(item).map(([key, value]) => {
                  if (key === 'VQLSource' || key === '_Source') return null;
                  return (
                    <div key={key} style={DataRow}>
                      <div style={LabelStyle}>{key.toUpperCase()}:</div>
                      <div style={ValueStyle}>{formatValue(key, value)}</div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// SUB-COMPONENT: MEMORY ANALYSIS TAB (Volatility3 / Remora React UI)
// ─────────────────────────────────────────────────────────────────────────────
const MemoryAnalysisTab = ({ assetId }) => {
  const [imagePath, setImagePath] = useState("");
  const [symbolPaths, setSymbolPaths] = useState("");
  const [selectedPlugin, setSelectedPlugin] = useState("windows.pslist");
  const [pluginArgs, setPluginArgs] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [output, setOutput] = useState(null);  // { columns: [], rows: [] } or { raw: "" }
  const [logs, setLogs] = useState([]);
  const [activeGroup, setActiveGroup] = useState(Object.keys(VOL_PLUGIN_GROUPS)[0]);
  const [filterText, setFilterText] = useState("");

  const addLog = (msg, type = "info") => {
    const ts = new Date().toLocaleTimeString([], { hour12: false });
    setLogs(prev => [{ ts, msg, type }, ...prev].slice(0, 100));
  };

  const handleRunPlugin = async () => {
    if (!imagePath.trim()) {
      addLog("CRITICAL: Memory image path is required.", "error");
      return;
    }
    setIsRunning(true);
    setOutput(null);
    addLog(`Executing: ${selectedPlugin} on ${imagePath}`, "info");

    try {
      const getAuthHeaders = () => ({
        'Authorization': `Bearer ${localStorage.getItem('orca_token')}`,
        'Content-Type': 'application/json'
      });

      const response = await fetch('http://localhost:8000/api/memory/run', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          asset_id: assetId,
          image_path: imagePath,
          plugin: selectedPlugin,
          args: pluginArgs,
          symbol_paths: symbolPaths,
          vol3_base: VOL_BASE
        })
      });

      const data = await response.json();
      if (response.ok) {
        setOutput(data);
        addLog(`Plugin completed. ${data.rows?.length || 0} rows returned.`, "success");
      } else {
        addLog("PLUGIN_ERROR: " + (data.detail || "Execution failed."), "error");
      }
    } catch (err) {
      addLog("UPLINK_FAILURE: Could not reach backend service.", "error");
    } finally {
      setIsRunning(false);
    }
  };

  const filteredRows = output?.rows?.filter(row =>
    Object.values(row).some(v => v?.toString().toLowerCase().includes(filterText.toLowerCase()))
  ) || [];

  return (
    <div style={{ display: 'flex', height: '100%', gap: '0' }}>

      {/* LEFT PANEL: PLUGIN BROWSER */}
      <div style={MemSidebar}>
        <div style={MemSidebarHeader}>PLUGIN_LIBRARY</div>
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {Object.entries(VOL_PLUGIN_GROUPS).map(([group, plugins]) => (
            <div key={group}>
              <div
                onClick={() => setActiveGroup(activeGroup === group ? null : group)}
                style={PluginGroupHeader}
              >
                {activeGroup === group ? '▼' : '▶'} {group.toUpperCase()}
              </div>
              {activeGroup === group && plugins.map(p => (
                <div
                  key={p}
                  onClick={() => setSelectedPlugin(p)}
                  style={{
                    ...PluginItem,
                    color: selectedPlugin === p ? '#00ff41' : '#666',
                    background: selectedPlugin === p ? 'rgba(0,255,65,0.05)' : 'transparent',
                    borderLeftColor: selectedPlugin === p ? '#00ff41' : 'transparent'
                  }}
                >
                  {p.split('.').pop()}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* MAIN PANEL */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* CONFIG BAR */}
        <div style={MemConfigBar}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1 }}>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <span style={MemLabel}>MEMORY_IMAGE:</span>
              <input
                value={imagePath}
                onChange={e => setImagePath(e.target.value)}
                placeholder="C:\path\to\memory.raw"
                style={{ ...MemInput, flex: 1 }}
              />
            </div>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <span style={MemLabel}>SYMBOL_PATHS:</span>
              <input
                value={symbolPaths}
                onChange={e => setSymbolPaths(e.target.value)}
                placeholder="C:\symbols\ (optional)"
                style={{ ...MemInput, flex: 1 }}
              />
            </div>
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <span style={MemLabel}>PLUGIN_ARGS:</span>
              <input
                value={pluginArgs}
                onChange={e => setPluginArgs(e.target.value)}
                placeholder="--pid 1234 (optional)"
                style={{ ...MemInput, flex: 1 }}
              />
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'flex-end', justifyContent: 'center' }}>
            <div style={{ color: '#00ff41', fontSize: '12px', fontWeight: 'bold' }}>{selectedPlugin}</div>
            <button
              onClick={handleRunPlugin}
              disabled={isRunning}
              style={{ ...MemRunBtn, opacity: isRunning ? 0.5 : 1 }}
            >
              {isRunning ? "RUNNING..." : "▶ EXECUTE_PLUGIN"}
            </button>
          </div>
        </div>

        {/* RESULTS AREA */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {output?.columns ? (
            <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
              <div style={{ padding: '8px 15px', borderBottom: '1px solid #111', display: 'flex', gap: '10px', alignItems: 'center', background: '#000' }}>
                <span style={{ color: '#666', fontSize: '10px' }}>{filteredRows.length} ROWS</span>
                <input
                  value={filterText}
                  onChange={e => setFilterText(e.target.value)}
                  placeholder="FILTER..."
                  style={{ ...MemInput, width: '220px' }}
                />
              </div>
              <div style={{ flex: 1, overflowY: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', fontFamily: 'monospace' }}>
                  <thead>
                    <tr style={{ background: '#111' }}>
                      {output.columns.map(col => (
                        <th key={col} style={TableHeader}>{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRows.map((row, i) => (
                      <tr key={i} style={{ background: i % 2 === 0 ? '#050505' : '#000', borderBottom: '1px solid #0a0a0a' }}>
                        {output.columns.map(col => (
                          <td key={col} style={TableCell}>{row[col] ?? '---'}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : output?.raw ? (
            <div style={{ flex: 1, overflowY: 'auto', padding: '15px', background: '#000' }}>
              <pre style={{ color: '#aaa', fontSize: '11px', lineHeight: '1.5', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                {output.raw}
              </pre>
            </div>
          ) : (
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
              <div style={{ color: '#333', fontSize: '11px', marginBottom: '15px' }}>
                AWAITING_PLUGIN_EXECUTION // {selectedPlugin}
              </div>
              {/* LOG PANEL */}
              {logs.length > 0 && (
                <div style={{ border: '1px solid #111', background: '#000' }}>
                  <div style={{ padding: '5px 10px', background: '#0a0a0a', fontSize: '9px', color: '#444' }}>EXECUTION_LOG</div>
                  {logs.map((l, i) => (
                    <div key={i} style={{ padding: '4px 10px', fontSize: '10px', fontFamily: 'monospace', color: l.type === 'error' ? '#ff4444' : l.type === 'success' ? '#00ff41' : '#666', borderBottom: '1px solid #0a0a0a' }}>
                      <span style={{ opacity: 0.5, marginRight: '8px' }}>[{l.ts}]</span>{l.msg}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// SUB-COMPONENT: KNOWN MALWARE SIGNATURES TAB (ClamAV GUI)
// ─────────────────────────────────────────────────────────────────────────────
const MalwareSignaturesTab = ({ assetId }) => {
  const [scanPath, setScanPath] = useState("C:\\");
  const [recursive, setRecursive] = useState(true);
  const [removeThreats, setRemoveThreats] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState(null);
  const [logs, setLogs] = useState([]);
  const [filterText, setFilterText] = useState("");

  const addLog = (msg, type = "info") => {
    const ts = new Date().toLocaleTimeString([], { hour12: false });
    setLogs(prev => [{ ts, msg, type }, ...prev].slice(0, 200));
  };

  const handleScan = async () => {
    if (!scanPath.trim()) {
      addLog("CRITICAL: Scan target path is required.", "error");
      return;
    }
    setIsScanning(true);
    setScanResults(null);
    setLogs([]);
    addLog(`Initiating ClamAV scan on: ${scanPath}`, "info");
    addLog(`Options: recursive=${recursive}, remove=${removeThreats}`, "info");

    try {
      const getAuthHeaders = () => ({
        'Authorization': `Bearer ${localStorage.getItem('orca_token')}`,
        'Content-Type': 'application/json'
      });

      const response = await fetch('http://localhost:8000/api/scan/clam', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          asset_id: assetId,
          scan_path: scanPath,
          recursive,
          remove: removeThreats,
          clam_base: CLAM_BASE
        })
      });

      const data = await response.json();
      if (response.ok) {
        setScanResults(data);
        addLog(`Scan complete. Scanned: ${data.scanned_files || 0} files. Threats: ${data.infected_files || 0}`, data.infected_files > 0 ? "error" : "success");
      } else {
        addLog("SCAN_ERROR: " + (data.detail || "ClamAV execution failed."), "error");
      }
    } catch (err) {
      addLog("UPLINK_FAILURE: Could not reach backend service.", "error");
    } finally {
      setIsScanning(false);
    }
  };

  const filteredThreats = (scanResults?.threats || []).filter(t =>
    t.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* CONFIG PANEL */}
      <div style={ClamConfigPanel}>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flex: 1 }}>
          <span style={MemLabel}>SCAN_TARGET:</span>
          <input
            value={scanPath}
            onChange={e => setScanPath(e.target.value)}
            placeholder="C:\Users\ or C:\Windows\System32"
            style={{ ...MemInput, flex: 1 }}
          />
        </div>
        <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
          <label style={CheckLabel}>
            <input type="checkbox" checked={recursive} onChange={e => setRecursive(e.target.checked)} style={{ marginRight: '5px' }} />
            RECURSIVE
          </label>
          <label style={{ ...CheckLabel, color: removeThreats ? '#ff4444' : '#444' }}>
            <input type="checkbox" checked={removeThreats} onChange={e => setRemoveThreats(e.target.checked)} style={{ marginRight: '5px' }} />
            REMOVE_THREATS
          </label>
          <button
            onClick={handleScan}
            disabled={isScanning}
            style={{ ...MemRunBtn, opacity: isScanning ? 0.5 : 1 }}
          >
            {isScanning ? "SCANNING..." : "▶ RUN_CLAMSCAN"}
          </button>
        </div>
      </div>

      {/* SUMMARY STRIP */}
      {scanResults && (
        <div style={ClamSummaryBar}>
          <div style={ClamStat}>
            <span style={{ color: '#666', fontSize: '9px' }}>SCANNED_FILES</span>
            <span style={{ color: '#fff', fontSize: '18px', fontWeight: 'bold' }}>{scanResults.scanned_files || 0}</span>
          </div>
          <div style={ClamStat}>
            <span style={{ color: '#666', fontSize: '9px' }}>INFECTED</span>
            <span style={{ color: scanResults.infected_files > 0 ? '#ff4444' : '#00ff41', fontSize: '18px', fontWeight: 'bold' }}>
              {scanResults.infected_files || 0}
            </span>
          </div>
          <div style={ClamStat}>
            <span style={{ color: '#666', fontSize: '9px' }}>ENGINE_VERSION</span>
            <span style={{ color: '#aaa', fontSize: '12px' }}>{scanResults.engine_version || '---'}</span>
          </div>
          <div style={{ ...ClamStat, color: scanResults.infected_files > 0 ? '#ff4444' : '#00ff41', fontSize: '11px', fontWeight: 'bold' }}>
            {scanResults.infected_files > 0 ? '⚠ THREATS_DETECTED' : '✓ CLEAN'}
          </div>
        </div>
      )}

      {/* THREATS / LOG SPLIT */}
      <div style={{ flex: 1, display: 'flex', gap: '0', overflow: 'hidden' }}>

        {/* THREATS LIST */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', borderRight: '1px solid #111' }}>
          <div style={{ padding: '8px 15px', background: '#0a0a0a', borderBottom: '1px solid #111', display: 'flex', gap: '10px', alignItems: 'center' }}>
            <span style={{ color: '#666', fontSize: '10px' }}>THREAT_SIGNATURES</span>
            {scanResults && (
              <input
                value={filterText}
                onChange={e => setFilterText(e.target.value)}
                placeholder="FILTER..."
                style={{ ...MemInput, width: '180px' }}
              />
            )}
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '10px' }}>
            {filteredThreats.length === 0 && !isScanning && (
              <div style={{ color: '#222', fontSize: '11px', padding: '10px' }}>
                {scanResults ? 'NO_THREATS_DETECTED' : 'AWAITING_SCAN_EXECUTION'}
              </div>
            )}
            {filteredThreats.map((t, i) => (
              <div key={i} style={ThreatRow}>
                <span style={{ color: '#ff4444', marginRight: '10px', fontSize: '10px' }}>⚠</span>
                <span style={{ color: '#ffaa00', fontSize: '11px', wordBreak: 'break-all' }}>{t}</span>
              </div>
            ))}
          </div>
        </div>

        {/* LOG PANEL */}
        <div style={{ width: '320px', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '8px 15px', background: '#0a0a0a', borderBottom: '1px solid #111' }}>
            <span style={{ color: '#666', fontSize: '10px' }}>EXECUTION_LOG</span>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '8px' }}>
            {logs.map((l, i) => (
              <div key={i} style={{ padding: '3px 8px', fontSize: '10px', fontFamily: 'monospace', color: l.type === 'error' ? '#ff4444' : l.type === 'success' ? '#00ff41' : '#555', borderBottom: '1px solid #0a0a0a' }}>
                <span style={{ opacity: 0.5, marginRight: '6px' }}>[{l.ts}]</span>{l.msg}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// SUB-COMPONENT: OVERVIEW TAB
// ─────────────────────────────────────────────────────────────────────────────
const OverviewTab = ({ assetId, tacticList }) => {
  const total = tacticList?.length || 0;
  const withEvidence = tacticList?.filter(t => t.evidence_imported)?.length || 0;
  const coveragePct = total > 0 ? Math.round((withEvidence / total) * 100) : 0;

  const verdictCounts = (tacticList || []).reduce((acc, t) => {
    const v = (t.verdict || 'UNDETERMINED').toUpperCase();
    acc[v] = (acc[v] || 0) + 1;
    return acc;
  }, {});

  const verdictColors = {
    MALICIOUS: '#ff4444',
    'NON-MALICIOUS': '#00ff41',
    UNDETERMINED: '#444',
  };

  return (
    <div style={{ padding: '25px', display: 'flex', flexDirection: 'column', gap: '20px', overflowY: 'auto', height: '100%' }}>

      {/* COLLECTION PROGRESS */}
      <div style={OverviewCard}>
        <div style={OverviewCardHeader}>COLLECTION_PROGRESS</div>
        <div style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ color: '#aaa', fontSize: '12px' }}>
              Evidence collected for <span style={{ color: '#00ff41', fontWeight: 'bold' }}>{withEvidence}</span> out of <span style={{ color: '#fff', fontWeight: 'bold' }}>{total}</span> techniques / sub-techniques
            </span>
            <span style={{ color: '#00ff41', fontWeight: 'bold', fontSize: '14px' }}>{coveragePct}%</span>
          </div>
          <div style={{ background: '#111', height: '8px', borderRadius: '2px', overflow: 'hidden' }}>
            <div style={{ background: '#00ff41', height: '100%', width: `${coveragePct}%`, transition: 'width 0.5s ease' }} />
          </div>
        </div>
      </div>

      {/* VERDICT ANALYSIS */}
      <div style={OverviewCard}>
        <div style={OverviewCardHeader}>VERDICT_ANALYSIS</div>
        <div style={{ padding: '20px', display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          {Object.entries(verdictCounts).map(([verdict, count]) => (
            <div key={verdict} style={{ ...VerdictTile, borderColor: verdictColors[verdict] || '#444' }}>
              <div style={{ color: verdictColors[verdict] || '#aaa', fontSize: '20px', fontWeight: 'bold' }}>{count}</div>
              <div style={{ color: verdictColors[verdict] || '#666', fontSize: '9px', letterSpacing: '1px', marginTop: '4px' }}>{verdict}</div>
            </div>
          ))}
        </div>
      </div>

      {/* TECHNIQUE QUICK-VIEW */}
      <div style={OverviewCard}>
        <div style={OverviewCardHeader}>TECHNIQUE_SUMMARY</div>
        <div style={{ padding: '10px', maxHeight: '200px', overflowY: 'auto' }}>
          {total === 0 ? (
            <div style={{ color: '#333', fontSize: '11px', padding: '10px' }}>NO_TECHNIQUES_LOADED</div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', fontFamily: 'monospace' }}>
              <thead>
                <tr style={{ background: '#0a0a0a' }}>
                  <th style={TableHeader}>T_CODE</th>
                  <th style={TableHeader}>TECHNIQUE</th>
                  <th style={TableHeader}>EVIDENCE</th>
                  <th style={TableHeader}>VERDICT</th>
                </tr>
              </thead>
              <tbody>
                {tacticList.map((t, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #0a0a0a' }}>
                    <td style={{ ...TableCell, color: '#00ff41' }}>{t.t_code}</td>
                    <td style={{ ...TableCell, color: '#aaa' }}>{t.technique_name || t.name}</td>
                    <td style={{ ...TableCell, color: t.evidence_imported ? '#7b2cbf' : '#333' }}>
                      {t.evidence_imported ? '✓ IMPORTED' : '—'}
                    </td>
                    <td style={{ ...TableCell, color: verdictColors[(t.verdict || 'UNDETERMINED').toUpperCase()] || '#444' }}>
                      {(t.verdict || 'UNDETERMINED').toUpperCase()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

    </div>
  );
};


// ─────────────────────────────────────────────────────────────────────────────
// MAIN: EVIDENCE WINDOW
// ─────────────────────────────────────────────────────────────────────────────
const EvidenceWindow = ({ assetId, assetName, tCode, isOpen, onClose, tacticList }) => {
  const [activeMainTab, setActiveMainTab] = useState("OVERVIEW");

  useEffect(() => {
    if (isOpen) setActiveMainTab("OVERVIEW");
  }, [isOpen]);

  if (!isOpen) return null;

  const MAIN_TABS = ["OVERVIEW", "ARTIFACT_ANALYSIS", "MEMORY_ANALYSIS", "KNOWN_MALWARE_SIGNATURES"];

  return (
    <div style={ModalOverlay}>
      <div style={ModalContent}>

        {/* TOP BAR */}
        <div style={ModalHeader}>
          <div style={{ color: '#00ff41', fontWeight: 'bold', fontSize: '13px' }}>
            [INVESTIGATION_WORKSPACE]: {(assetName || `ASSET_${assetId}`).toUpperCase()}
          </div>
          <button onClick={onClose} style={CloseBtn}>[ X ]</button>
        </div>

        {/* MAIN TAB BAR */}
        <div style={MainTabBar}>
          {MAIN_TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveMainTab(tab)}
              style={{
                ...MainTabBtn,
                borderBottom: activeMainTab === tab ? '2px solid #00ff41' : '2px solid transparent',
                color: activeMainTab === tab ? '#00ff41' : '#444',
                background: activeMainTab === tab ? 'rgba(0,255,65,0.04)' : 'transparent'
              }}
            >
              {tab.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {/* TAB CONTENT */}
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {activeMainTab === "OVERVIEW" && (
            <OverviewTab assetId={assetId} tacticList={tacticList || []} />
          )}
          {activeMainTab === "ARTIFACT_ANALYSIS" && (
            <ArtifactAnalysisTab assetId={assetId} assetName={assetName} tCode={tCode} />
          )}
          {activeMainTab === "MEMORY_ANALYSIS" && (
            <MemoryAnalysisTab assetId={assetId} />
          )}
          {activeMainTab === "KNOWN_MALWARE_SIGNATURES" && (
            <MalwareSignaturesTab assetId={assetId} />
          )}
        </div>

      </div>
    </div>
  );
};

export default EvidenceWindow;


// ─────────────────────────────────────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────────────────────────────────────

// Shared
const ModalOverlay = { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.95)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 };
const ModalContent = { width: '90%', height: '90%', background: '#050505', border: '1px solid #00ff41', display: 'flex', flexDirection: 'column', fontFamily: 'monospace', overflow: 'hidden' };
const ModalHeader = { padding: '12px 20px', borderBottom: '1px solid #222', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#000', flexShrink: 0 };
const CloseBtn = { background: 'none', border: 'none', color: '#ff4444', cursor: 'pointer', fontWeight: 'bold', fontSize: '16px' };

// Main tabs
const MainTabBar = { display: 'flex', background: '#000', borderBottom: '1px solid #1a1a1a', flexShrink: 0 };
const MainTabBtn = { padding: '10px 20px', border: 'none', cursor: 'pointer', fontSize: '10px', fontFamily: 'monospace', fontWeight: 'bold', letterSpacing: '1px', transition: '0.15s' };

// Artifact Analysis
const CollectionHeader = { display: 'flex', gap: '15px', alignItems: 'center', padding: '10px 15px', background: '#000', borderBottom: '1px solid #1a1a1a', flexShrink: 0, flexWrap: 'wrap' };
const SmallInput = { background: '#000', border: '1px solid #222', color: '#00ff41', padding: '5px 8px', fontSize: '11px', fontFamily: 'monospace', outline: 'none', width: '60px' };
const SmallBtn = { padding: '5px 12px', background: '#00ff41', color: '#000', border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: '10px', fontFamily: 'monospace' };
const SearchInputStyle = { background: '#000', border: '1px solid #333', color: '#00ff41', fontFamily: 'monospace', padding: '5px 10px', outline: 'none', width: '180px', fontSize: '11px' };
const TabBar = { display: 'flex', gap: '5px', padding: '8px 15px', background: '#080808', borderBottom: '1px solid #111', overflowX: 'auto', flexShrink: 0 };
const SubTabStyle = { background: '#000', border: '1px solid', padding: '4px 12px', fontSize: '10px', fontFamily: 'monospace', cursor: 'pointer', whiteSpace: 'nowrap' };
const ArtifactCard = { background: '#0a0a0a', border: '1px solid #1a1a1a', padding: '15px', position: 'relative', borderRadius: '2px', cursor: 'text' };
const CardBadge = { position: 'absolute', top: '-10px', right: '10px', background: '#00ff41', color: '#000', fontSize: '9px', padding: '2px 6px', fontWeight: 'bold' };
const DataRow = { display: 'flex', marginBottom: '8px', borderBottom: '1px solid #111', paddingBottom: '6px', alignItems: 'flex-start' };
const LabelStyle = { color: '#00ff41', minWidth: '180px', fontSize: '11px', flexShrink: 0, fontWeight: 'bold' };
const ValueStyle = { color: '#ccc', fontSize: '11px', lineHeight: '1.4', width: '100%' };
const ListStyle = { display: 'flex', flexDirection: 'column', gap: '4px', marginTop: '4px', maxHeight: '400px', overflowY: 'auto', background: '#000', padding: '8px', border: '1px solid #111' };
const ListItemStyle = { borderBottom: '1px solid #111', paddingBottom: '2px', wordBreak: 'break-all', color: '#aaa' };
const ContextMenuStyle = { position: 'fixed', zIndex: 2000, background: '#050505', border: '1px solid #00ff41', minWidth: '200px', boxShadow: '0 0 15px rgba(0,255,65,0.3)' };
const MenuHeader = { padding: '8px 12px', fontSize: '9px', color: '#666', borderBottom: '1px solid #222', background: '#000', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '250px' };
const MenuItem = { padding: '10px 12px', fontSize: '11px', color: '#00ff41', cursor: 'pointer', borderBottom: '1px solid #111', fontFamily: 'monospace' };

// Memory Analysis
const MemSidebar = { width: '180px', background: '#000', borderRight: '1px solid #111', display: 'flex', flexDirection: 'column', overflow: 'hidden' };
const MemSidebarHeader = { padding: '10px 12px', fontSize: '9px', color: '#444', borderBottom: '1px solid #111', letterSpacing: '1px', fontWeight: 'bold' };
const PluginGroupHeader = { padding: '8px 12px', fontSize: '9px', color: '#555', cursor: 'pointer', borderBottom: '1px solid #0a0a0a', fontWeight: 'bold', letterSpacing: '1px' };
const PluginItem = { padding: '6px 12px 6px 20px', fontSize: '10px', cursor: 'pointer', borderLeft: '2px solid transparent', borderBottom: '1px solid #0a0a0a' };
const MemConfigBar = { display: 'flex', gap: '15px', alignItems: 'flex-start', padding: '12px 15px', background: '#000', borderBottom: '1px solid #111', flexShrink: 0 };
const MemLabel = { color: '#444', fontSize: '10px', minWidth: '110px', paddingTop: '2px' };
const MemInput = { background: '#000', border: '1px solid #222', color: '#aaa', padding: '5px 8px', fontSize: '11px', fontFamily: 'monospace', outline: 'none' };
const MemRunBtn = { padding: '8px 16px', background: '#00ff41', color: '#000', border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: '11px', fontFamily: 'monospace', whiteSpace: 'nowrap' };
const TableHeader = { padding: '8px 10px', textAlign: 'left', fontSize: '10px', color: '#555', fontFamily: 'monospace', borderBottom: '1px solid #111', fontWeight: 'bold' };
const TableCell = { padding: '6px 10px', fontSize: '11px', color: '#aaa', fontFamily: 'monospace', verticalAlign: 'top' };

// ClamAV
const ClamConfigPanel = { display: 'flex', gap: '15px', alignItems: 'center', padding: '12px 15px', background: '#000', borderBottom: '1px solid #111', flexShrink: 0, flexWrap: 'wrap' };
const ClamSummaryBar = { display: 'flex', gap: '0', background: '#0a0a0a', borderBottom: '1px solid #111', flexShrink: 0 };
const ClamStat = { display: 'flex', flexDirection: 'column', gap: '2px', padding: '12px 25px', borderRight: '1px solid #111', alignItems: 'center' };
const CheckLabel = { color: '#444', fontSize: '10px', cursor: 'pointer', display: 'flex', alignItems: 'center', fontFamily: 'monospace' };
const ThreatRow = { padding: '8px 10px', borderBottom: '1px solid #0a0a0a', display: 'flex', alignItems: 'flex-start' };

// Overview
const OverviewCard = { border: '1px solid #111', background: '#000' };
const OverviewCardHeader = { padding: '6px 15px', background: '#0a0a0a', borderBottom: '1px solid #111', fontSize: '10px', color: '#555', fontWeight: 'bold', letterSpacing: '1px' };
const VerdictTile = { border: '1px solid', padding: '15px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: '100px' };
