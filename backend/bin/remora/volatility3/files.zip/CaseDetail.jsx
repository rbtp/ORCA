import React, { useState, useEffect } from 'react';
import NetworkMap from './NetworkMap';
import AssetActionTab from './AssetActionTab';
import EvidenceWindow from './EvidenceWindow';

export default function CaseDetail({ caseData, onBack, onRefresh }) {
  const [activeTab, setActiveTab] = useState('OVERVIEW');
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [showAssetModal, setShowAssetModal] = useState(false);
  
  const [editingConfig, setEditingConfig] = useState(null); 
  const [configBuffer, setConfigBuffer] = useState("");     
  
  // --- INVESTIGATION / EVIDENCE WINDOW STATE ---
  const [investigatingAssetId, setInvestigatingAssetId] = useState(null);
  const [isEvidenceWindowOpen, setIsEvidenceWindowOpen] = useState(false);
  const [evidenceTacticList, setEvidenceTacticList] = useState([]);
  const [isFetchingTactics, setIsFetchingTactics] = useState(false);

  const [activeNodes, setActiveNodes] = useState([]);
  const [activeLinks, setActiveLinks] = useState([]); 
  const [isMaximized, setIsMaximized] = useState(false);
  const [saveStatus, setSaveStatus] = useState("READY");
  const [linkForm, setLinkForm] = useState(null);

  const API_BASE = 'http://localhost:8000/api/mitre';

  const getAuthHeaders = () => ({
    "Authorization": `Bearer ${localStorage.getItem('orca_token')}`,
    "Content-Type": "application/json"
  });

  // Find the asset object for the evidence window
  const currentAsset = caseData.assets?.find(a => String(a.id) === String(investigatingAssetId));

  // --- OPEN EVIDENCE WINDOW: fetch tactic list for the asset first ---
  useEffect(() => {
    if (!investigatingAssetId || !currentAsset) return;

    const searchIdentifier = caseData.name || caseData.country;
    if (!searchIdentifier) {
      setEvidenceTacticList([]);
      setIsEvidenceWindowOpen(true);
      return;
    }

    setIsFetchingTactics(true);
    fetch(`${API_BASE}/threat-profile/${searchIdentifier}?asset_id=${investigatingAssetId}`, {
      headers: getAuthHeaders()
    })
      .then(res => res.json())
      .then(data => {
        setEvidenceTacticList(Array.isArray(data) ? data : []);
        setIsEvidenceWindowOpen(true);
      })
      .catch(() => {
        setEvidenceTacticList([]);
        setIsEvidenceWindowOpen(true);
      })
      .finally(() => setIsFetchingTactics(false));
  }, [investigatingAssetId]);

  // --- PERSISTENCE: LOAD DATA ---
  useEffect(() => {
    const rawMap = caseData.mapData || caseData.map_data;
    if (rawMap) {
      try {
        const parsedMap = typeof rawMap === 'string' ? JSON.parse(rawMap) : rawMap;
        if (parsedMap && parsedMap.nodes) {
          setActiveNodes(parsedMap.nodes || []);
          setActiveLinks(parsedMap.links || []);
        } else if (Array.isArray(parsedMap)) {
          setActiveNodes(parsedMap);
          setActiveLinks([]);
        }
      } catch (e) { console.error("MAP_REHYDRATION_ERROR:", e); }
    }
  }, [caseData]);

  // --- PERSISTENCE: SAVE DATA ---
  const saveMapLayout = async () => {
    setSaveStatus("SAVING...");
    const payload = { nodes: activeNodes || [], links: activeLinks || [] };
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseData.name)}/map-sync`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        setSaveStatus("SAVED_SUCCESSFULLY");
        setTimeout(() => setSaveStatus("READY"), 2000);
      } else { setSaveStatus("ERROR"); }
    } catch (err) { setSaveStatus("ERROR"); }
  };

  const OS_VERSIONS = {
    "Windows": ["11", "10", "7", "XP", "Server 2022", "Server 2019"],
    "Linux": ["Ubuntu 22.04", "RHEL 9", "Kali", "Debian", "CentOS"],
    "MacOS": ["Sonoma", "Ventura", "Monterey", "Big Sur"],
    "Android/iOS": ["Latest", "Legacy"]
  };

  const [assetForm, setAssetForm] = useState({
    hostname: '', ip: '', subnet: '255.255.255.0', gateway: '', mac: '',
    type: 'Workstation', os: 'Windows', version: '10', 
    formFactor: 'Laptop', assetNotes: ''
  });

  useEffect(() => {
    fetch(`${API_BASE}/cases/${encodeURIComponent(caseData.name)}/notes`, {
      headers: getAuthHeaders()
    })
      .then(res => res.json())
      .then(data => setNotes(data))
      .catch(() => setNotes([]));
  }, [caseData.name]);

  const handleAddNote = async () => {
    if (!newNote.trim()) return;
    const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseData.name)}/notes`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ text: newNote }),
    });
    if (res.ok) {
      setNotes([{ text: newNote, time: new Date().toISOString().substring(0, 16).replace('T', ' ') }, ...notes]);
      setNewNote("");
    }
  };

  const handleRegisterAsset = async () => {
    try {
      const res = await fetch(`${API_BASE}/cases/${encodeURIComponent(caseData.name)}/assets`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(assetForm),
      });
      if (res.ok) { 
        setShowAssetModal(false); 
        if (onRefresh) onRefresh();
      }
    } catch (err) { console.error(err); }
  };

  const deployToMap = (asset) => {
    if (!activeNodes.find(n => n.hostname === asset.hostname)) {
      setActiveNodes([...activeNodes, {
        hostname: asset.hostname, ip: asset.ip, mac: asset.mac_address,
        os: asset.os, version: asset.os_version, type: asset.form_factor,
        config: '', nodeNote: '', x: 400, y: 250
      }]);
    }
  };

  const handleInitiateLink = (source, target) => {
    setLinkForm({
      id: `link-${Date.now()}`, source: source.hostname, target: target.hostname,
      link_type: 'WIRED', interface_src: '', interface_dst: '',
      ip_src: source.ip || '', ip_dst: target.ip || '', vlan: '1'
    });
  };

  const handleConfirmLink = () => {
    setActiveLinks(prev => [...prev, linkForm]);
    setLinkForm(null);
  };

  const handleDeleteNode = (nodeToDelete) => {
    if (window.confirm(`REMOVE ${nodeToDelete.hostname} FROM WORKSPACE?`)) {
      setActiveNodes(prev => prev.filter(n => n.hostname !== nodeToDelete.hostname));
      setActiveLinks(prev => prev.filter(l => l.source !== nodeToDelete.hostname && l.target !== nodeToDelete.hostname));
    }
  };

  const addInfrastructure = (type) => {
    const id = Math.floor(Math.random() * 999);
    setActiveNodes([...activeNodes, {
      hostname: `${type}_${id}`, ip: '0.0.0.0', mac: 'AUTO_GEN',
      type: type, os: 'Firmware_v1.0', config: '', nodeNote: '', x: 450, y: 250
    }]);
  };

  const handleUpdateNode = (node, action, data) => {
    if (action === 'COORD_UPDATE') {
      setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, x: data.x, y: data.y } : n));
      return; 
    }
    if (action === 'CONFIG') {
      if (['SWITCH', 'ROUTER', 'FIREWALL'].includes(node.type?.toUpperCase())) {
        setEditingConfig(node); setConfigBuffer(node.config || "");
      } else {
        const val = prompt(`ENTER SYSTEM NOTES FOR ${node.hostname}:`, node.nodeNote || "");
        if (val !== null) setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, nodeNote: val } : n));
      }
      return;
    }
    const fieldMap = { 'IP': 'ip', 'NOTE': 'nodeNote' };
    const field = fieldMap[action];
    if (field) {
      const val = prompt(`ENTER ${action} FOR ${node.hostname}:`, node[field] || "");
      if (val !== null) setActiveNodes(prev => prev.map(n => n.hostname === node.hostname ? { ...n, [field]: val } : n));
    }
  };

  const handleCloseEvidenceWindow = () => {
    setIsEvidenceWindowOpen(false);
    setInvestigatingAssetId(null);
    setEvidenceTacticList([]);
  };

  return (
    <div style={{ animation: 'fadeIn 0.3s ease', color: '#fff', fontFamily: 'monospace' }}>
      <button onClick={onBack} style={{ background: 'none', border: 'none', color: '#00ff41', cursor: 'pointer', fontSize: '10px', marginBottom: '20px' }}>
        [ BACK_TO_GALLERY ]
      </button>

      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '42px', fontWeight: 900, margin: '0' }}>{caseData.name}</h1>
        <div style={{ color: '#444', fontSize: '10px', marginTop: '5px' }}>CASE_REF: {caseData.country?.toUpperCase()}_INTEL_PRIORITY_1</div>
      </div>

      <div style={{ display: 'flex', gap: '30px', marginBottom: '30px', borderBottom: '1px solid #111' }}>
        {['OVERVIEW', 'ASSETS', 'NETWORK_MAP'].map(tab => (
          <div key={tab} onClick={() => setActiveTab(tab)} style={{ 
            fontSize: '11px', letterSpacing: '2px', cursor: 'pointer', 
            color: activeTab === tab ? '#00ff41' : '#444', 
            borderBottom: activeTab === tab ? '2px solid #00ff41' : '2px solid transparent', 
            paddingBottom: '10px' 
          }}>{tab}</div>
        ))}
      </div>

      <div style={{ minHeight: '500px' }}>
        {activeTab === 'OVERVIEW' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '40px' }}>
            <div style={{ animation: 'fadeIn 0.5s ease' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginBottom: '40px' }}>
                  <StatTile label="LEAD" val={caseData.missionLead} />
                  <StatTile label="TEAM" val={caseData.teamName} />
                  <StatTile label="UNIT" val={caseData.support} />
                  <StatTile label="OPS" val={caseData.personnel} />
              </div>
              <div style={{ borderTop: '1px solid #111', paddingTop: '30px' }}>
                  <div style={{ color: '#444', fontSize: '10px', marginBottom: '15px' }}>MISSION_TIMELINE_LOG</div>
                  <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                      <input value={newNote} onChange={(e) => setNewNote(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAddNote()} placeholder="APPEND_LOG_DATA..." style={InputStyle} />
                      <button onClick={handleAddNote} style={BtnStyle}>COMMIT</button>
                  </div>
                  <div style={{ maxHeight: '300px', overflowY: 'auto', background: 'rgba(0,0,0,0.2)', padding: '15px', border: '1px solid #0a0a0a' }}>
                      {notes.map((n, i) => (
                          <div key={i} style={{ fontSize: '11px', marginBottom: '12px', borderLeft: '2px solid #333', paddingLeft: '15px' }}>
                              <span style={{ color: '#00ff41', marginRight: '10px' }}>[{n.time}]</span>
                              <span style={{ color: '#aaa' }}>{n.text}</span>
                          </div>
                      ))}
                  </div>
              </div>
            </div>
            <aside style={{ borderLeft: '1px solid #111', paddingLeft: '40px' }}>
                <div style={{ color: '#444', fontSize: '9px', marginBottom: '15px' }}>GEOPOLITICAL_CONTEXT</div>
                <div style={{ fontSize: '12px', color: '#888', lineHeight: '1.6' }}>Operational environment confirmed as {caseData.country}. Priority assessment is high.</div>
            </aside>
          </div>
        )}

        {activeTab === 'ASSETS' && (
          <div style={{ animation: 'fadeIn 0.4s ease' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
              <h3 style={{ fontSize: '11px', color: '#444' }}>SYSTEM_INVENTORY</h3>
              <button onClick={() => setShowAssetModal(true)} style={BtnStyle}>+ REGISTER_NEW_ASSET</button>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px' }}>
              <thead style={{ color: '#333', textAlign: 'left', borderBottom: '1px solid #111' }}>
                <tr>
                  <th style={{ padding: '10px' }}>HOSTNAME</th>
                  <th>NETWORK_ADDRESSING</th>
                  <th>OS_SPECIFICATION</th>
                  <th>FORM_FACTOR</th>
                  <th style={{ width: '220px', textAlign: 'left', paddingLeft: '20px' }}>ACTION</th> 
                </tr>
              </thead>
              <tbody>
                {caseData.assets?.map((a, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #0a0a0a' }}>
                    <td style={{ padding: '15px 10px', color: '#00ff41', fontWeight: 'bold' }}>{a.hostname}</td>
                    <td style={{ color: '#888' }}>IP: {a.ip}<br/><span style={{fontSize:'9px', color:'#333'}}>MAC: {a.mac_address}</span></td>
                    <td>{a.os} {a.os_version}</td>
                    <td>{a.form_factor}</td>
                    <td style={{ width: '220px', textAlign: 'left', padding: '15px 0 15px 20px' }}>
                      {/* Show loading indicator while fetching tactics for this asset */}
                      {isFetchingTactics && String(investigatingAssetId) === String(a.id) ? (
                        <span style={{ color: '#666', fontSize: '10px', fontFamily: 'monospace' }}>LOADING...</span>
                      ) : (
                        <AssetActionTab
                          assetId={a.id}
                          assetName={a.hostname}
                          setInvestigatingAsset={setInvestigatingAssetId}
                        />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'NETWORK_MAP' && (
          <div style={{ 
            position: isMaximized ? 'fixed' : 'relative', top: isMaximized ? 0 : 'auto', left: isMaximized ? 0 : 'auto',
            width: isMaximized ? '100vw' : '100%', height: isMaximized ? '100vh' : '650px',
            zIndex: isMaximized ? 2000 : 1, display: 'grid', 
            gridTemplateColumns: isMaximized ? '1fr 350px' : '1fr 300px', 
            background: '#111', border: '1px solid #111' 
          }}>
            <div style={{ background: '#000', overflow: 'hidden', position: 'relative' }}>
              <button onClick={() => setIsMaximized(!isMaximized)} style={MaxBtnStyle}>
                {isMaximized ? '[ EXIT_FULLSCREEN ]' : '[ MAXIMIZE_MAP ]'}
              </button>
              <NetworkMap activeNodes={activeNodes} activeLinks={activeLinks} updateNodeData={handleUpdateNode} onInitiateLink={handleInitiateLink} onDeleteNode={handleDeleteNode} />
            </div>
            <div style={{ background: '#080808', padding: '20px', borderLeft: '1px solid #111', overflowY: 'auto' }}>
              <button onClick={saveMapLayout} style={{ ...BtnStyle, width: '100%', marginBottom: '20px' }}>
                {saveStatus === 'READY' ? '[ COMMIT_MAP_TO_DATABASE ]' : `[ ${saveStatus} ]`}
              </button>
              <div style={{ color: '#444', fontSize: '9px', marginBottom: '15px' }}>INFRASTRUCTURE_TEMPLATES</div>
              {['SWITCH', 'ROUTER', 'FIREWALL'].map(type => (
                <button key={type} onClick={() => addInfrastructure(type)} style={TempBtnStyle}>+ ADD_{type}</button>
              ))}
              <div style={{ color: '#444', fontSize: '9px', margin: '20px 0 15px' }}>AVAILABLE_ASSETS</div>
              {caseData.assets?.map((asset, i) => (
                <div key={i} onDoubleClick={() => deployToMap(asset)} style={AssetCardStyle}>
                  <div style={{ color: '#00ff41' }}>{asset.hostname}</div>
                  <div style={{ color: '#444', fontSize: '10px' }}>{asset.ip}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* --- EVIDENCE WINDOW (replaces old investigation modal) --- */}
      <EvidenceWindow
        assetId={investigatingAssetId}
        assetName={currentAsset?.hostname}
        tCode={null}
        isOpen={isEvidenceWindowOpen}
        onClose={handleCloseEvidenceWindow}
        tacticList={evidenceTacticList}
      />

      {/* --- LINK MODAL --- */}
      {linkForm && (
        <div style={ModalOverlay}>
          <div style={ModalContent}>
            <h2 style={{ color: '#00ff41', fontSize: '12px', marginBottom: '20px' }}>[ ESTABLISH_LINK ]: {linkForm.source} ↔ {linkForm.target}</h2>
            <div style={{ display: 'grid', gap: '15px' }}>
              <select style={InputStyle} value={linkForm.link_type} onChange={e => setLinkForm({...linkForm, link_type: e.target.value})}>
                <option value="WIRED">WIRED</option><option value="WIRELESS">WIRELESS</option><option value="VPN">VPN</option>
              </select>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <input style={InputStyle} value={linkForm.ip_src} onChange={e => setLinkForm({...linkForm, ip_src: e.target.value})} placeholder="SRC IP" />
                <input style={InputStyle} value={linkForm.interface_src} onChange={e => setLinkForm({...linkForm, interface_src: e.target.value})} placeholder="eth0" />
              </div>
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button onClick={handleConfirmLink} style={BtnStyle}>INITIATE_UPLINK</button>
                <button onClick={() => setLinkForm(null)} style={{ ...BtnStyle, background: 'transparent', color: '#444', border: '1px solid #222' }}>ABORT</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- CONFIG EDITOR MODAL --- */}
      {editingConfig && (
        <div style={ModalOverlay}>
          <div style={{ width: '90%', height: '85%', background: '#050505', border: '1px solid #00ff41', display: 'flex', flexDirection: 'column', padding: '20px' }}>
            <div style={{ color: '#00ff41', fontSize: '12px', marginBottom: '15px' }}>[TERMINAL_EDITOR]: {editingConfig.hostname.toUpperCase()}_CONFIG</div>
            <textarea autoFocus value={configBuffer} onChange={(e) => setConfigBuffer(e.target.value)} style={TextareaStyle} />
            <div style={{ display: 'flex', gap: '15px', marginTop: '20px' }}>
              <button onClick={() => { setActiveNodes(prev => prev.map(n => n.hostname === editingConfig.hostname ? { ...n, config: configBuffer } : n)); setEditingConfig(null); }} style={BtnStyle}>COMMIT_TO_MEMORY</button>
              <button onClick={() => setEditingConfig(null)} style={{ ...BtnStyle, background: 'transparent', color: '#444', border: '1px solid #222' }}>ABORT</button>
            </div>
          </div>
        </div>
      )}

      {/* --- ASSET REGISTRATION MODAL --- */}
      {showAssetModal && (
        <div style={ModalOverlay}>
          <div style={ModalContent}>
            <h2 style={{ color: '#00ff41', fontSize: '14px', marginBottom: '20px' }}>NEW_ASSET_SPECIFICATION</h2>
            <div style={{ display: 'grid', gap: '10px' }}>
                <input style={InputStyle} placeholder="HOSTNAME" value={assetForm.hostname} onChange={e => setAssetForm({...assetForm, hostname: e.target.value})} />
                <input style={InputStyle} placeholder="IP_ADDRESS" value={assetForm.ip} onChange={e => setAssetForm({...assetForm, ip: e.target.value})} />
                <button onClick={handleRegisterAsset} style={BtnStyle}>SAVE_ASSET</button>
                <button onClick={() => setShowAssetModal(false)} style={{ background: '#111', border: 'none', color: '#444', padding: '10px', cursor: 'pointer' }}>CANCEL</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const StatTile = ({ label, val }) => (
    <div style={{ border: '1px solid #111', padding: '12px' }}>
        <div style={{ fontSize: '8px', color: '#333', marginBottom: '5px' }}>{label}</div>
        <div style={{ fontSize: '12px', color: '#eee' }}>{val || '---'}</div>
    </div>
);

const AssetCardStyle = { padding: '10px', border: '1px solid #111', marginBottom: '8px', cursor: 'grab', fontSize: '11px' };
const TempBtnStyle = { background: '#111', color: '#00ff41', border: '1px solid #222', textAlign: 'left', width: '100%', padding: '10px', marginBottom: '8px', cursor: 'pointer', fontSize: '10px', fontFamily: 'monospace' };
const MaxBtnStyle = { position: 'absolute', top: '15px', right: '15px', zIndex: 10, background: '#00ff41', color: '#000', border: 'none', padding: '6px 12px', fontSize: '9px', fontWeight: 'bold', cursor: 'pointer', fontFamily: 'monospace' };
const InputStyle = { background: '#000', border: '1px solid #1a1a1a', padding: '10px', color: '#00ff41', fontSize: '11px', width: '100%', outline: 'none', fontFamily: 'monospace' };
const TextareaStyle = { flex: 1, background: '#000', color: '#00ff41', border: '1px solid #111', fontFamily: 'monospace', fontSize: '13px', padding: '20px', outline: 'none' };
const BtnStyle = { background: '#00ff41', color: '#000', border: 'none', padding: '10px 20px', fontWeight: 'bold', cursor: 'pointer', fontSize: '10px', fontFamily: 'monospace' };
const ModalOverlay = { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0,0,0,0.95)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 };
const ModalContent = { background: '#050505', border: '1px solid #00ff41', padding: '40px', width: '420px' };
